package com.orchestrator.routes;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.orchestrator.config.ApiLoggingInterceptor;
import com.orchestrator.config.ResponseLoggingInterceptor;
import com.orchestrator.config.SslPropertyConfig;
import com.orchestrator.exception.GlobalExceptionHandler;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.camel.LoggingLevel;
import org.apache.camel.builder.RouteBuilder;
import org.springframework.stereotype.Component;

import java.util.Base64;
import java.util.HashMap;
import java.util.Map;

/**
* Document Download API
* POST /api/download
* 
* Downloads a document from OTCS and returns base64-encoded content
* Accepts JSON body with DocumentId
*/
@Component
@RequiredArgsConstructor
@Slf4j
public class DownloadDocumentRoute extends RouteBuilder {

    private final ObjectMapper objectMapper;
    private final SslPropertyConfig sslPropertyConfig;
    private final GlobalExceptionHandler globalExceptionHandler;
    private final ApiLoggingInterceptor apiLoggingInterceptor;
    private final ResponseLoggingInterceptor responseLoggingInterceptor;

    @Override
    public void configure() throws Exception {

        // Global exception handling for all routes
        onException(Exception.class)
            .handled(true)
            .process(globalExceptionHandler)
            .stop();

        // Main download endpoint - Changed to POST with JSON body
        from("netty-http:http://{{app.NETTY_MOCK_HOST}}:{{app.NETTY_MOCK_PORT}}/api/v1/DownloadDocument"
                + "?httpMethodRestrict=POST"
                + "&chunked=true"
                + "&chunkedMaxContentLength=2147483647")
            .routeId("download-document-api")
            .process(exchange -> exchange.setProperty("EXPOSED_API_ENDPOINT", "POST /api/v1/DownloadDocument"))
            .log(LoggingLevel.INFO, "[DOWNLOAD-API] ========== Download Request Received ==========")
            .log(LoggingLevel.DEBUG, "[DOWNLOAD-API] Request body: ${body}")

            // Step 0: Validate request schema
            .to("json-validator:schemas/request-schema.json")
            .log(LoggingLevel.INFO, "[DOWNLOAD-API] Request validation successful")

            // Parse JSON body to extract DocumentId
            .to("direct:parse-download-request")

            .log(LoggingLevel.INFO, "[DOWNLOAD-API] Document ID: ${exchangeProperty.documentId}")

            // Step 1: Authenticate with OTCS
            .log(LoggingLevel.INFO, "[DOWNLOAD-API] Step 1: Authenticating with OTCS")
            .to("direct:authenticate-otcs")

            // Step 2: Get document metadata (name)
            .log(LoggingLevel.INFO, "[DOWNLOAD-API] Step 2: Getting document metadata")
            .to("direct:get-document-metadata")

            // Step 3: Download document content
            .log(LoggingLevel.INFO, "[DOWNLOAD-API] Step 3: Downloading document content")
            .to("direct:download-document-content")

            // Step 4: Build response JSON
            .log(LoggingLevel.INFO, "[DOWNLOAD-API] Step 4: Building response")
            .to("direct:build-download-response")

            .log(LoggingLevel.INFO, "[DOWNLOAD-API] Download completed for document ID: ${exchangeProperty.documentId}")

            .process(responseLoggingInterceptor)
            // Set response headers
            .setHeader(Exchange.HTTP_RESPONSE_CODE, constant(200))
            .setHeader(Exchange.CONTENT_TYPE, constant("application/json"));


        // Parse JSON request body
        from("direct:parse-download-request")
            .routeId("parse-download-request")
            .process(exchange -> {
                String body = exchange.getIn().getBody(String.class);
                log.info("[DOWNLOAD-PARSE] Parsing JSON request body");
                log.debug("[DOWNLOAD-PARSE] Raw body: {}", body);

                // Parse JSON
                @SuppressWarnings("unchecked")
                Map<String, Object> requestJson = objectMapper.readValue(body, Map.class);
                @SuppressWarnings("unchecked")
                Map<String, Object> document = (Map<String, Object>) requestJson.get("Document");

                // Extract fields
                String applicationName = (String) document.get("ApplicationName");
                String workspaceType = (String) document.get("WorkspaceType");
                String source = (String) document.get("Source");
                String documentId = String.valueOf(document.get("DocumentId"));

                log.info("[DOWNLOAD-PARSE] ApplicationName: {}", applicationName);
                log.info("[DOWNLOAD-PARSE] WorkspaceType: {}", workspaceType);
                log.info("[DOWNLOAD-PARSE] Source: {}", source);
                log.info("[DOWNLOAD-PARSE] DocumentId: {}", documentId);

                // Store in exchange properties
                exchange.setProperty("requestBody", body);
                exchange.setProperty("applicationName", applicationName);
                exchange.setProperty("workspaceType", workspaceType);
                exchange.setProperty("source", source);
                exchange.setProperty("documentId", documentId);

                log.info("[DOWNLOAD-PARSE] Request parsed successfully");
            });


        // Get document metadata (name, type, etc.)
        from("direct:get-document-metadata")
            .routeId("get-document-metadata")
            .process(exchange -> {
                String documentId = exchange.getProperty("documentId", String.class);
                log.info("[DOWNLOAD-METADATA] Getting metadata for document ID: {}", documentId);
            })

            // Set headers for metadata call
            .setHeader(Exchange.HTTP_METHOD, constant("GET"))
            .setHeader("Accept", constant("application/json"))
            .setHeader("OTCSTicket", exchangeProperty("otcsTicket"))

            // Call GET /api/v2/nodes/{id}
            .process(exchange -> {
                exchange.setProperty("API_START_TIME", System.currentTimeMillis());
                exchange.setProperty("API_ENDPOINT", "GET /api/v2/nodes/" + exchange.getProperty("documentId"));
            })
            .toD("{{app.OTCS_BASE_URL}}/api/v2/nodes/${exchangeProperty.documentId}?bridgeEndpoint=true&throwExceptionOnFailure=false" + sslPropertyConfig.getSslParam())
            .process(apiLoggingInterceptor)

            .process(exchange -> {
                Integer statusCode = exchange.getIn().getHeader(Exchange.HTTP_RESPONSE_CODE, Integer.class);
                String responseBody = exchange.getIn().getBody(String.class);

                log.debug("[DOWNLOAD-METADATA] Response status: {}", statusCode);
                log.debug("[DOWNLOAD-METADATA] Response body: {}", responseBody);

                if (statusCode != 200) {
                    throw new RuntimeException("Failed to get document metadata. Status: " + statusCode);
                }

                // Parse response to extract document name
                @SuppressWarnings("unchecked")
                Map<String, Object> response = objectMapper.readValue(responseBody, Map.class);
                @SuppressWarnings("unchecked")
                Map<String, Object> results = (Map<String, Object>) response.get("results");
                @SuppressWarnings("unchecked")
                Map<String, Object> data = (Map<String, Object>) results.get("data");
                @SuppressWarnings("unchecked")
                Map<String, Object> properties = (Map<String, Object>) data.get("properties");

                String documentName = (String) properties.get("name");
                log.info("[DOWNLOAD-METADATA] Document name: {}", documentName);

                // Store in exchange property
                exchange.setProperty("documentName", documentName);
            });


        // Download document content
        from("direct:download-document-content")
            .routeId("download-document-content")
            .process(exchange -> {
                String documentId = exchange.getProperty("documentId", String.class);
                log.info("[DOWNLOAD-CONTENT] Downloading content for document ID: {}", documentId);
            })

            // Set headers for content download
            .setHeader(Exchange.HTTP_METHOD, constant("GET"))
            .setHeader("Accept", constant("*/*"))
            .setHeader("OTCSTicket", exchangeProperty("otcsTicket"))

            // Call GET /api/v1/nodes/{id}/content
            .process(exchange -> {
                exchange.setProperty("API_START_TIME", System.currentTimeMillis());
                exchange.setProperty("API_ENDPOINT", "GET /api/v1/nodes/" + exchange.getProperty("documentId") + "/content");
            })
            .toD("{{app.OTCS_BASE_URL}}/api/v1/nodes/${exchangeProperty.documentId}/content?bridgeEndpoint=true&throwExceptionOnFailure=false" + sslPropertyConfig.getSslParam())
            .process(apiLoggingInterceptor)

            .process(exchange -> {
                Integer statusCode = exchange.getIn().getHeader(Exchange.HTTP_RESPONSE_CODE, Integer.class);

                log.debug("[DOWNLOAD-CONTENT] Response status: {}", statusCode);

                if (statusCode != 200) {
                    String responseBody = exchange.getIn().getBody(String.class);
                    log.error("[DOWNLOAD-CONTENT] Failed to download content: {}", responseBody);
                    throw new RuntimeException("Failed to download document content. Status: " + statusCode);
                }

                // Get binary content and encode to base64
                byte[] content = exchange.getIn().getBody(byte[].class);
                String base64Content = Base64.getEncoder().encodeToString(content);

                log.info("[DOWNLOAD-CONTENT] Content downloaded successfully, size: {} bytes", content.length);
                log.debug("[DOWNLOAD-CONTENT] Base64 length: {} characters", base64Content.length());

                // Store in exchange property
                exchange.setProperty("base64Content", base64Content);
            });


        // Build final response JSON
        from("direct:build-download-response")
            .routeId("build-download-response")
            .process(exchange -> {
                String documentId = exchange.getProperty("documentId", String.class);
                String documentName = exchange.getProperty("documentName", String.class);
                String base64Content = exchange.getProperty("base64Content", String.class);

                log.info("[DOWNLOAD-RESPONSE] Building response for document: {} ({})", documentName, documentId);

                // Build response structure
                Map<String, Object> response = new HashMap<>();
                Map<String, Object> document = new HashMap<>();
                Map<String, Object> data = new HashMap<>();

                data.put("DocumentId", documentId);
                data.put("name", documentName);
                data.put("file", base64Content);

                document.put("Data", data);
                response.put("Document", document);

                // Convert to JSON
                String jsonResponse = objectMapper.writeValueAsString(response);
                exchange.getIn().setBody(jsonResponse);

                log.debug("[DOWNLOAD-RESPONSE] Response built successfully");
            });
    }
}