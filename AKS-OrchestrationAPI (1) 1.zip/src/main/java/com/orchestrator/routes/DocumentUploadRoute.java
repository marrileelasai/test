package com.orchestrator.routes;

import com.orchestrator.config.ApiLoggingInterceptor;
import com.orchestrator.config.ResponseLoggingInterceptor;
import com.orchestrator.config.SslPropertyConfig;
import com.orchestrator.exception.GlobalExceptionHandler;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.camel.LoggingLevel;
import org.apache.camel.builder.RouteBuilder;
import org.springframework.stereotype.Component;

/**
 * Document Upload API - JSON with Base64
 * 
 * Endpoint: POST /api/v1/UploadDocument
 * Content-Type: application/json
 * 
 * Body: JSON with base64 encoded file in $.Document.documentMetadata.file_content_base64
 * 
 * Flow:
 * 1. save-file-to-disk: Decode base64 and save to disk
 * 2. authenticate-otcs: Get auth ticket
 * 3. get-business-workspace-id: Lookup or create workspace
 * 4. streamingFileUploadProcessor: Build multipart and upload to OTCS /v2/nodes (streams from disk, gets cached mappings directly)
 * 
 * Output: Multipart to OTCS (all clients send multipart to /v2/nodes)
 */
@Component
@RequiredArgsConstructor
@Slf4j
public class DocumentUploadRoute extends RouteBuilder {

    private final GlobalExceptionHandler globalExceptionHandler;
    private final SslPropertyConfig sslPropertyConfig;
    private final ApiLoggingInterceptor apiLoggingInterceptor;
    private final ResponseLoggingInterceptor responseLoggingInterceptor;

    @Override
    public void configure() throws Exception {

        // Global exception handling
        onException(Exception.class)
            .handled(true)
            .process(globalExceptionHandler)
            .log(LoggingLevel.ERROR, "[UPLOAD-API] Exception processed by GlobalExceptionHandler");

        // Direct Netty HTTP endpoint for JSON + base64 (pure Netty, no servlet)
        from("netty-http:http://{{app.NETTY_MOCK_HOST}}:{{app.NETTY_MOCK_PORT}}/api/v1/UploadDocument"
                + "?matchOnUriPrefix=false"
                + "&chunkedMaxContentLength=2147483647")
            .routeId("document-upload-api")
            .process(exchange -> exchange.setProperty("EXPOSED_API_ENDPOINT", "POST /api/v1/UploadDocument"))
            .log(LoggingLevel.INFO, "[UPLOAD] ========== Document Upload Request Received (JSON + Base64) ==========")
            // CRITICAL: Do NOT log body! It will buffer everything
            
            // Step 0: Validate request schema
            .to("json-validator:schemas/request-schema.json")
            .log(LoggingLevel.INFO, "[UPLOAD] Request validation successful")
            
            // Step 1: Decode base64 and save to disk
            .to("direct:save-file-to-disk")
            .log(LoggingLevel.INFO, "[UPLOAD] File saved to disk - Transaction: ${exchangeProperty.transactionNumber}, File: ${exchangeProperty.fileName}")
            
            // Step 2: Authenticate with OTCS
            .log(LoggingLevel.INFO, "[UPLOAD] Step 2: Authenticating with OTCS")
            .to("direct:authenticate-otcs")
            .log(LoggingLevel.INFO, "[UPLOAD] Authentication successful")
            
            // Step 3: Get workspace ID (sets bwExists property)
            .to("direct:get-business-workspace-id")
            
            // Step 4: Create workspace if needed
            .choice()
                .when(exchangeProperty("bwExists").isEqualTo(false))
                    .log(LoggingLevel.WARN, "[UPLOAD] Workspace not found, creating...")
                    // Set requestBody property for CreateBusinessWorkspaceRoute
                    .process(exchange -> {
                        String payload = exchange.getProperty("payload", String.class);
                        exchange.setProperty("requestBody", payload);
                    })
                    .to("direct:create-bw-for-upload")
                .otherwise()
                    .log(LoggingLevel.INFO, "[UPLOAD] Workspace exists: ${exchangeProperty.bwId}")
            .end()
            
            // Step 5: Build multipart body
            .process("streamingFileUploadProcessor")
            
            // Step 6: Upload to OTCS /v2/nodes
            .log(LoggingLevel.INFO, "[UPLOAD] Uploading to OTCS /v2/nodes")
            .process(exchange -> {
                exchange.setProperty("API_START_TIME", System.currentTimeMillis());
                exchange.setProperty("API_ENDPOINT", "POST /api/v2/nodes");
            })
            .setHeader("OTCSTicket", exchangeProperty("otcsTicket"))
            .toD("{{app.OTCS_BASE_URL}}/api/v2/nodes?bridgeEndpoint=true&throwExceptionOnFailure=false" + sslPropertyConfig.getSslParam())
            .process(apiLoggingInterceptor)
            .log(LoggingLevel.INFO, "[UPLOAD] Upload response status: ${header.CamelHttpResponseCode}")
            
            // Step 7: Transform response to simplified format
            .to("direct:upload-api-response")
            
            .process(responseLoggingInterceptor)
            .log(LoggingLevel.INFO, "[UPLOAD] ========== Upload Complete ==========");
    }
}
 