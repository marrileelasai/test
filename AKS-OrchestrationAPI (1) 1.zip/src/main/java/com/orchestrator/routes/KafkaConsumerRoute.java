package com.orchestrator.routes;

import org.apache.camel.LoggingLevel;
import org.apache.camel.builder.RouteBuilder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class KafkaConsumerRoute extends RouteBuilder {

    @Value("${app.KAFKA_THREAD_POOL_MIN}")
    private int threadPoolMin;
    
    @Value("${app.KAFKA_THREAD_POOL_MAX}")
    private int threadPoolMax;

    @Override
    public void configure() {

        // Temporary Netty HTTP endpoint - accepts POST with JSON body
   /*from("netty-http:http://{{app.NETTY_MOCK_HOST}}:{{app.NETTY_MOCK_PORT}}/api/kafka-simulator/submission"
                + "?httpMethodRestrict=POST"
                + "&chunked=true"
                + "&chunkedMaxContentLength=2147483647"
                + "&maxContentLength=2147483647")
            .routeId("mock-kafka-submission")
            .log(LoggingLevel.INFO, "[KAFKA-MOCK] ========== Received ESCAPE Submission Request ==========")
            .log(LoggingLevel.DEBUG, "[KAFKA-MOCK] Received payload: ${body}")
            .log(LoggingLevel.INFO, "[KAFKA-MOCK] Triggering Business Workspace orchestration")
            
            // Trigger orchestration with the received body
            .to("direct:orchestrate-business-workspace");*/
            
          //.log(LoggingLevel.INFO, "[KAFKA-MOCK] Orchestration completed, returning response")
           //.setHeader(Exchange.CONTENT_TYPE, constant("application/json"));

        //Real Kafka consumer - uncomment when Kafka is ready

        
    from("kafka:{{app.KAFKA_SUBMISSION_TOPIC}}")
                .routeId("kafka-to-OT")
                .threads(threadPoolMin, threadPoolMax, "escape-to-OT-threadPool")
                .log(LoggingLevel.INFO, "Step 1: Kafka received payload: ${body}")
               .to("direct:orchestrate-business-workspace");
        
    }
}