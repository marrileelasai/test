package com.orchestrator.config;

import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.springframework.stereotype.Component;

/**
 * API Logging Interceptor
 * Logs response time for all OTCS API calls and response for all exposed APIs
 */
@Slf4j
@Component
public class ApiLoggingInterceptor implements Processor {

    @Override
    public void process(Exchange exchange) throws Exception {
        String routeId = exchange.getFromRouteId();
        Long startTime = exchange.getProperty("API_START_TIME", Long.class);
        
        if (startTime != null) {
            long responseTime = System.currentTimeMillis() - startTime;
            Integer httpStatus = exchange.getIn().getHeader(Exchange.HTTP_RESPONSE_CODE, Integer.class);
            String endpoint = exchange.getProperty("API_ENDPOINT", String.class);
            
            log.info("╔══════════════════════════════════════════════════════════════╗");
            log.info("║ OTCS API RESPONSE METRICS                                    ║");
            log.info("╠══════════════════════════════════════════════════════════════╣");
            log.info("║ Endpoint      : {}", endpoint);
            log.info("║ Route ID      : {}", routeId);
            log.info("║ HTTP Status   : {}", httpStatus);
            log.info("║ Response Time : {} ms", responseTime);
            log.info("╚══════════════════════════════════════════════════════════════╝");
            
            // Clean up
            exchange.removeProperty("API_START_TIME");
            exchange.removeProperty("API_ENDPOINT");
        }
    }
}
