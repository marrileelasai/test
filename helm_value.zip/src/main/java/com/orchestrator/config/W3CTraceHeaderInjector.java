package com.orchestrator.config;

import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.springframework.stereotype.Component;

/**
 * W3C Trace Header Injector
 *
 * Reads the W3C traceparent (and tracestate) stored as exchange properties
 * by {@link W3CTracePropagationFilter} and sets them as HTTP headers on the
 * CURRENT exchange so that the next outbound HTTP call carries them.
 *
 * Usage: Place .process(w3cTraceHeaderInjector) IMMEDIATELY BEFORE every
 *        .to() / .toD() call that goes to an external HTTP service.
 *
 * Example in a route:
 *
 *   .process(w3cTraceHeaderInjector)          // inject traceparent header
 *   .toD("{{app.OTCS_BASE_URL}}/api/v1/auth?bridgeEndpoint=true")
 */
@Slf4j
@Component
public class W3CTraceHeaderInjector implements Processor {

    @Override
    public void process(Exchange exchange) throws Exception {

        String traceparent = exchange.getProperty(
                W3CTracePropagationFilter.PROP_TRACEPARENT, String.class);
        String tracestate  = exchange.getProperty(
                W3CTracePropagationFilter.PROP_TRACESTATE,  String.class);

        if (traceparent != null && !traceparent.isBlank()) {
            exchange.getIn().setHeader(W3CTracePropagationFilter.TRACEPARENT_HEADER, traceparent);
            log.debug("[W3C-TRACE] Injected traceparent into outbound call: {}", traceparent);

            if (tracestate != null && !tracestate.isBlank()) {
                exchange.getIn().setHeader(W3CTracePropagationFilter.TRACESTATE_HEADER, tracestate);
                log.debug("[W3C-TRACE] Injected tracestate into outbound call: {}", tracestate);
            }
        } else {
            log.debug("[W3C-TRACE] No traceparent property found — outbound call will not carry W3C trace context.");
        }
    }
}
