package com.orchestrator.config;

import org.springframework.context.annotation.Configuration;

/**
 * Application configuration beans
 */
@Configuration
public class AppConfig {
    // Configuration moved to application.yml
}
