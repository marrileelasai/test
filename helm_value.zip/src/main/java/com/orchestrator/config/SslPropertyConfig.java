package com.orchestrator.config;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

import jakarta.annotation.PostConstruct;

/**
 * Sets SSL query-string parameter for OTCS route calls based on environment.
 * 
 * Logic:
 * - If allowAllSSLContextParameters bean exists (local dev): sslParam = &sslContextParameters=#allowAllSSLContextParameters
 * - If bean doesn't exist (production pod): sslParam = "" (use default SSL validation)
 * 
 * Routes can access via constructor injection with SslPropertyConfig and use getSslParam()
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class SslPropertyConfig {

	private final ApplicationContext applicationContext;
	
	private String sslParam = "";

	@PostConstruct
	public void init() {
		// Check if SSL bypass bean exists (only in local dev)
		log.warn("═══════════════════════════════════════════════════════════");
		log.warn("⚠️  SslPropertyConfig: Checking for allowAllSSLContextParameters bean...");
		boolean sslBypassBeanExists = applicationContext.containsBean("allowAllSSLContextParameters");
		log.warn("⚠️  Bean exists: {}", sslBypassBeanExists);
		
		this.sslParam = sslBypassBeanExists 
			? "&sslContextParameters=#allowAllSSLContextParameters" 
			: "";

		if (sslBypassBeanExists) {
			log.warn("⚠️  SSL BYPASS ENABLED - sslParam will disable certificate validation");
			log.warn("⚠️  sslParam value: '{}'", sslParam);
		} else {
			log.warn("⚠️  SSL VALIDATION ENABLED - Production mode (certificate validation enforced)");
		}
		log.warn("═══════════════════════════════════════════════════════════");
	}
	
	/**
	 * Get SSL parameter to append to Camel HTTP URLs
	 * @return "&sslContextParameters=#allowAllSSLContextParameters" in dev, "" in prod
	 */
	public String getSslParam() {
		return this.sslParam;
	}
}
