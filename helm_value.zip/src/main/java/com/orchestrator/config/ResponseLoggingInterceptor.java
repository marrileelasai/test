package com.orchestrator.config;

import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.springframework.stereotype.Component;

/**
 * Response Logging Interceptor for all exposed APIs
 * Logs final response body and metadata
 */
@Slf4j
@Component
public class ResponseLoggingInterceptor implements Processor {

    @Override
    public void process(Exchange exchange) throws Exception {
        String routeId = exchange.getFromRouteId();
        Integer httpStatus = exchange.getIn().getHeader(Exchange.HTTP_RESPONSE_CODE, Integer.class);
        String responseBody = exchange.getIn().getBody(String.class);
        String endpoint = exchange.getProperty("EXPOSED_API_ENDPOINT", String.class);
        
        log.info("┌────────────────────────────────────────────────────────────────┐");
        log.info("│ API RESPONSE                                                   │");
        log.info("├────────────────────────────────────────────────────────────────┤");
        log.info("│ Endpoint      : {}", endpoint != null ? endpoint : "N/A");
        log.info("│ Route ID      : {}", routeId);
        log.info("│ HTTP Status   : {}", httpStatus != null ? httpStatus : 200);
        log.info("│ Response Body : {}", responseBody != null && responseBody.length() > 500 
            ? responseBody.substring(0, 500) + "... (truncated)" 
            : responseBody);
        log.info("└────────────────────────────────────────────────────────────────┘");
    }
}
