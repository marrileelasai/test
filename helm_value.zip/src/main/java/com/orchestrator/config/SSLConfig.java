package com.orchestrator.config;

import lombok.extern.slf4j.Slf4j;
import org.apache.camel.support.jsse.SSLContextParameters;
import org.apache.camel.support.jsse.TrustManagersParameters;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.net.ssl.X509TrustManager;
import java.security.cert.X509Certificate;

/**
 * SSL Configuration for Apache Camel HTTP Component
 * DEVELOPMENT ONLY - Bypasses SSL certificate validation
 * 
 * This bean is ONLY created when app.SSL_BYPASS_ENABLED=true
 * In production pods, this property is NOT set, so SSL validation is enforced
 */
@Slf4j
@Configuration
@ConditionalOnProperty(name = "app.SSL_BYPASS_ENABLED", havingValue = "true", matchIfMissing = false)
public class SSLConfig {
    
    public SSLConfig() {
        log.warn("═══════════════════════════════════════════════════════════");
        log.warn("⚠️  SSLConfig CLASS LOADED - SSL Bypass Bean will be created");
        log.warn("⚠️  app.SSL_BYPASS_ENABLED = true (from -Dssl.bypass.enabled JVM arg)");
        log.warn("═══════════════════════════════════════════════════════════");
    }
    
    @Bean(name = "allowAllSSLContextParameters")
    public SSLContextParameters allowAllSSLContextParameters() {
        log.warn("═══════════════════════════════════════════════════════════");
        log.warn("⚠️  SSL CERTIFICATE VALIDATION DISABLED - LOCAL DEV ONLY!");
        log.warn("⚠️  Production pods will enforce SSL certificate validation");
        log.warn("═══════════════════════════════════════════════════════════");
        
        TrustManagersParameters trustManagersParameters = new TrustManagersParameters();
        trustManagersParameters.setTrustManager(new TrustAllManager());
        
        SSLContextParameters sslContextParameters = new SSLContextParameters();
        sslContextParameters.setTrustManagers(trustManagersParameters);
        
        return sslContextParameters;
    }
    
    /**
     * Trust manager that accepts all certificates
     */
    private static class TrustAllManager implements X509TrustManager {
        @Override
        public void checkClientTrusted(X509Certificate[] chain, String authType) {
            // Trust all
        }
        
        @Override
        public void checkServerTrusted(X509Certificate[] chain, String authType) {
            // Trust all
        }
        
        @Override
        public X509Certificate[] getAcceptedIssuers() {
            return new X509Certificate[0];
        }
    }
}
