package com.orchestrator.config;

import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.springframework.stereotype.Component;

/**
 * W3C Trace Context Propagation
 *
 * Captures the incoming `traceparent` (and optional `tracestate`) headers
 * from the inbound request and stores them as exchange properties so that
 * every outbound HTTP call in the chain can forward them.
 *
 * W3C Trace Context spec: https://www.w3.org/TR/trace-context/
 *
 * Format:  traceparent: 00-<trace-id>-<parent-id>-<flags>
 * Example: traceparent: 00-4bf92f3577b34da6a3ce929d0e0e4736-00f067aa0ba902b7-01
 *
 * Usage: Place .process(w3cTracePropagationFilter) at the START of any
 *        entry-point route (Kafka consumer, Netty HTTP, REST etc.) so the
 *        trace context is captured before any downstream call is made.
 */
@Slf4j
@Component
public class W3CTracePropagationFilter implements Processor {

    public static final String TRACEPARENT_HEADER  = "traceparent";
    public static final String TRACESTATE_HEADER   = "tracestate";
    public static final String PROP_TRACEPARENT    = "W3C_TRACEPARENT";
    public static final String PROP_TRACESTATE     = "W3C_TRACESTATE";

    @Override
    public void process(Exchange exchange) throws Exception {

        // ── 1. Try to read from inbound HTTP / Kafka headers ────────────────
        String traceparent = exchange.getIn().getHeader(TRACEPARENT_HEADER, String.class);
        String tracestate  = exchange.getIn().getHeader(TRACESTATE_HEADER,  String.class);

        // ── 2. Store in exchange properties so all downstream routes can read them
        if (traceparent != null && !traceparent.isBlank()) {
            exchange.setProperty(PROP_TRACEPARENT, traceparent);
            if (tracestate != null && !tracestate.isBlank()) {
                exchange.setProperty(PROP_TRACESTATE, tracestate);
            }
            log.info("[W3C-TRACE] Captured traceparent: {}", traceparent);
            if (tracestate != null) {
                log.debug("[W3C-TRACE] Captured tracestate: {}", tracestate);
            }
        } else {
            // No incoming trace context — log for visibility (not an error)
            log.debug("[W3C-TRACE] No traceparent header found on inbound message. " +
                      "Outbound calls will not carry W3C trace context.");
        }
    }
}
