package com.orchestrator.routes;

import com.orchestrator.config.SslPropertyConfig;
import com.orchestrator.config.W3CTraceHeaderInjector;
import com.orchestrator.constants.OrchestratorConstants;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.camel.LoggingLevel;
import org.apache.camel.builder.RouteBuilder;
import org.springframework.stereotype.Component;

/**
 * Update Business Workspace Route (Kafka flow only)
 * 
 * Validates BOTH eventType and actualRows before deciding POST vs PUT
 * - actualRows=0 + eventType=Create → POST
 * - actualRows>0 + eventType=Update → PUT
 * - Mismatch → FAIL event (strict validation)
 */
@Component
@RequiredArgsConstructor
@Slf4j
public class UpdateBusinessWorkspaceRoute extends RouteBuilder {

    private final SslPropertyConfig sslPropertyConfig;
    private final W3CTraceHeaderInjector w3cTraceHeaderInjector;

    @Override
    public void configure() throws Exception {

        // Main route for creating or updating workspace (Kafka flow)
        from("direct:create-or-update-workspace")
            .routeId("create-or-update-workspace")
            .log(LoggingLevel.INFO, "[WORKSPACE-OP] Creating or updating Business Workspace")
            .log(LoggingLevel.INFO, "[WORKSPACE-OP] Checking escapeEvent property: ${exchangeProperty.escapeEvent}")
            .log(LoggingLevel.INFO, "[WORKSPACE-OP] Checking eventType property: ${exchangeProperty.eventType}")
            
            // Extract transactionNumber from ESCAPE event and call GetParentID
            .process(exchange -> {
                String escapeEvent = exchange.getProperty(OrchestratorConstants.PROP_ESCAPE_EVENT, String.class);
                log.info("[WORKSPACE-OP] Inside processor - escapeEvent is null: {}", escapeEvent == null);
                
                if (escapeEvent == null || escapeEvent.trim().isEmpty()) {
                    throw new IllegalStateException("ESCAPE event property '" + OrchestratorConstants.PROP_ESCAPE_EVENT + "' is null or empty. Ensure WorkspaceOrchestrationRoute sets this property before calling this route.");
                }
                
                DocumentContext json = JsonPath.parse(escapeEvent);
                
                // Extract submissionNumber (transactionNumber)
                String submissionNumber = null;
                try {
                    submissionNumber = json.read("$.data.submissionNumber", String.class);
                } catch (Exception e) {
                    try {
                        submissionNumber = json.read("$.submissionNumber", String.class);
                    } catch (Exception e2) {
                        throw new IllegalArgumentException("submissionNumber not found in ESCAPE event");
                    }
                }
                
                exchange.setProperty("transactionNumber", submissionNumber);
                log.info("[WORKSPACE-OP] Transaction Number: {}", submissionNumber);
            })
            
            // CRITICAL: Save workspace payload before calling GetParentID (which changes body)
            .process(exchange -> {
                String workspacePayload = exchange.getIn().getBody(String.class);
                exchange.setProperty("workspacePayload", workspacePayload);
                log.debug("[WORKSPACE-OP] Saved workspace payload to property before GetParentID call");
            })
            
            // Call GetParentID to check if workspace exists
            .to("direct:get-business-workspace-id")
            
            // Restore workspace payload after GetParentID
            .process(exchange -> {
                String workspacePayload = exchange.getProperty("workspacePayload", String.class);
                exchange.getIn().setBody(workspacePayload);
                log.debug("[WORKSPACE-OP] Restored workspace payload from property after GetParentID call");
            })
            
            // Validate eventType vs actualRows and route accordingly
            .to("direct:validate-and-route-workspace");

        // Validate eventType against actualRows, then POST or PUT
        from("direct:validate-and-route-workspace")
            .routeId("validate-and-route-workspace")
            .log(LoggingLevel.INFO, "[WORKSPACE-VALIDATE] Validating eventType vs workspace existence")
            .process(exchange -> {
                Boolean bwExists = exchange.getProperty("bwExists", Boolean.class);
                Integer bwId = exchange.getProperty("bwId", Integer.class);
                String eventType = exchange.getProperty("eventType", String.class);
                
                log.info("[WORKSPACE-VALIDATE] eventType={}, bwExists={}, bwId={}", eventType, bwExists, bwId);
                
                // Strict validation matrix
                
                if (!bwExists && "Create".equalsIgnoreCase(eventType)) {
                    //  Workspace doesn't exist AND Create event → POST
                    log.info("[WORKSPACE-VALIDATE] Valid: Create new workspace (POST)");
                    exchange.setProperty("httpMethod", "POST");
                    exchange.setProperty("validated", true);
                    
                } else if (bwExists && "Update".equalsIgnoreCase(eventType)) {
                    //  Workspace exists AND Update event → PUT
                    log.info("[WORKSPACE-VALIDATE] Valid: Update existing workspace ID {} (PUT)", bwId);
                    exchange.setProperty("httpMethod", "PUT");
                    exchange.setProperty("validated", true);
                    
                } else if (!bwExists && "Update".equalsIgnoreCase(eventType)) {
                    //  MISMATCH: Update requested but workspace doesn't exist
                    String error = String.format("VALIDATION FAILED: eventType=Update but workspace does not exist for TransactionNumber=%s", 
                        exchange.getProperty("transactionNumber"));
                    log.error("[WORKSPACE-VALIDATE] {}", error);
                    throw new IllegalStateException(error);
                    
                } else if (bwExists && "Create".equalsIgnoreCase(eventType)) {
                    //  MISMATCH: Create requested but workspace already exists
                    String error = String.format("VALIDATION FAILED: eventType=Create but workspace already exists with ID=%d for TransactionNumber=%s", 
                        bwId, exchange.getProperty("transactionNumber"));
                    log.error("[WORKSPACE-VALIDATE] {}", error);
                    throw new IllegalStateException(error);
                    
                } else {
                    // Unknown eventType
                    String error = String.format("Unknown eventType: %s. Expected 'Create' or 'Update'", eventType);
                    log.error("[WORKSPACE-VALIDATE] {}", error);
                    throw new IllegalArgumentException(error);
                }
            })
            
            // Execute POST or PUT based on validation
            .choice()
                .when(simple("${exchangeProperty.httpMethod} == 'POST'"))
                    .to("direct:post-workspace")
                .when(simple("${exchangeProperty.httpMethod} == 'PUT'"))
                    .to("direct:put-workspace")
            .end();

        // POST new workspace
        from("direct:post-workspace")
            .routeId("post-workspace")
            .log(LoggingLevel.INFO, "[WORKSPACE-POST] Creating new workspace")
            .log(LoggingLevel.INFO, "[WORKSPACE-POST] Payload being sent: ${body}")
            
            .setHeader(Exchange.HTTP_METHOD, constant("POST"))
            .setHeader("Content-Type", constant("application/json"))
            .setHeader("Accept", constant("application/json"))
            .setHeader("OTCSTicket", header("OTCSTicket"))
            
            // ── W3C FIX: inject traceparent before outbound call ──────────────
            .process(w3cTraceHeaderInjector)
            .toD("{{app.OTCS_BASE_URL}}/api/v2/businessworkspaces?bridgeEndpoint=true&throwExceptionOnFailure=false" + sslPropertyConfig.getSslParam())
            .log(LoggingLevel.INFO, "[WORKSPACE-POST] Response status: ${header.CamelHttpResponseCode}")
            .log(LoggingLevel.DEBUG, "[WORKSPACE-POST] Response body: ${body}")
            
            .process(exchange -> {
                Integer responseCode = exchange.getIn().getHeader(Exchange.HTTP_RESPONSE_CODE, Integer.class);
                String responseBody = exchange.getIn().getBody(String.class);
                
                if (responseCode == 200 || responseCode == 201) {
                    log.info("[WORKSPACE-POST] Workspace created successfully");
                    
                } else if (responseCode == 500 && responseBody != null && responseBody.contains("already exists")) {
                    // Workspace was created between GetParentID check and POST → retry as PUT
                    log.warn("[WORKSPACE-POST] Workspace already exists (race condition), retrying as PUT");
                    exchange.setProperty("retryAsPut", true);
                    
                } else if (responseCode == 500) {
                    // OTCS returned 500 - verify if workspace was actually created before failing
                    log.warn("[WORKSPACE-POST] POST returned 500, will verify if workspace was actually created");
                    exchange.setProperty("verify500Response", true);
                    
                } else {
                    String error = String.format("POST failed with status %d: %s", responseCode, responseBody);
                    log.error("[WORKSPACE-POST] {}", error);
                    throw new RuntimeException(error);
                }
            })
            
            // Handle race condition: re-check and PUT if "already exists"
            .choice()
                .when(simple("${exchangeProperty.retryAsPut} == true"))
                    .log(LoggingLevel.WARN, "[WORKSPACE-POST] Re-checking workspace existence for PUT retry")
                    .to("direct:get-business-workspace-id")
                    .process(exchange -> {
                        Boolean bwExists = exchange.getProperty("bwExists", Boolean.class);
                        if (!bwExists) {
                            throw new IllegalStateException("POST failed with 'already exists' but GetParentID still returns 0 rows");
                        }
                    })
                    .to("direct:put-workspace")
                .when(simple("${exchangeProperty.verify500Response} == true"))
                    .log(LoggingLevel.WARN, "[WORKSPACE-POST] Verifying workspace creation after 500 response")
                    .to("direct:get-business-workspace-id")
                    .process(exchange -> {
                        Boolean bwExists = exchange.getProperty("bwExists", Boolean.class);
                        Integer bwId = exchange.getProperty("bwId", Integer.class);
                        
                        if (bwExists) {
                            log.info("[WORKSPACE-POST] Workspace was successfully created despite 500 response (ID: {})", bwId);
                        } else {
                            throw new RuntimeException("POST returned 500 and workspace was NOT created - genuine failure");
                        }
                    })
            .end();

        // PUT update workspace
        from("direct:put-workspace")
            .routeId("put-workspace")
            .log(LoggingLevel.INFO, "[WORKSPACE-PUT] Updating workspace ID ${exchangeProperty.bwId} via category updates")
            .log(LoggingLevel.DEBUG, "[WORKSPACE-PUT] Payload: ${body}")
            
            // Call new category update route (splits into multiple async PUT calls)
            .to("direct:update-workspace-categories")
            
            .log(LoggingLevel.INFO, "[WORKSPACE-PUT] Workspace categories updated successfully");
    }
}
