package com.orchestrator.routes;

import com.orchestrator.config.ApiLoggingInterceptor;
import com.orchestrator.config.SslPropertyConfig;
import com.orchestrator.config.W3CTraceHeaderInjector;
import com.orchestrator.exception.GlobalExceptionHandler;
import com.orchestrator.service.CategoryMappingCacheService;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.camel.LoggingLevel;
import org.apache.camel.builder.RouteBuilder;
import org.springframework.stereotype.Component;

import java.util.*;

/**
 * Step 5: Create Business Workspace
 * Uses cached category mappings with otattributename (not sourceattribute)
 * Filters by workspacetype and builds payload dynamically
 */
@Component
@RequiredArgsConstructor
@Slf4j
public class CreateBusinessWorkspaceRoute extends RouteBuilder {

    private final CategoryMappingCacheService categoryMappingCacheService;
    private final SslPropertyConfig sslPropertyConfig;
    private final W3CTraceHeaderInjector w3cTraceHeaderInjector;
    private final GlobalExceptionHandler globalExceptionHandler;
    private final ApiLoggingInterceptor apiLoggingInterceptor;

    @Override
    public void configure() throws Exception {

        // Global exception handling
        onException(Exception.class)
            .handled(true)
            .process(globalExceptionHandler)
            .log(LoggingLevel.ERROR, "[CREATE-BW] Exception processed by GlobalExceptionHandler");

        // Step 5: Create Business Workspace for Document Upload
        from("direct:create-bw-for-upload")
            .routeId("create-bw-for-upload")
            .log(LoggingLevel.INFO, "[CREATE-BW] Step 5: Creating Business Workspace for upload")
            
            // Build BW creation payload
            .to("direct:build-bw-payload")
            
            // Create BW via POST /v2/businessworkspaces
            .log(LoggingLevel.INFO, "[CREATE-BW] Calling POST /v2/businessworkspaces")
            .log(LoggingLevel.DEBUG, "[CREATE-BW] Request payload: ${body}")
            .process(exchange -> {
                exchange.setProperty("API_START_TIME", System.currentTimeMillis());
                exchange.setProperty("API_ENDPOINT", "POST /api/v2/businessworkspaces");
            })
            .setHeader(Exchange.HTTP_METHOD, constant("POST"))
            .setHeader("Content-Type", constant("application/json"))
            .setHeader("Accept", constant("application/json"))
            .setHeader("OTCSTicket", exchangeProperty("otcsTicket"))
            // ── W3C FIX: inject traceparent before outbound call ──────────────
            .process(w3cTraceHeaderInjector)
            .toD("{{app.OTCS_BASE_URL}}/api/v2/businessworkspaces?bridgeEndpoint=true&throwExceptionOnFailure=false" + sslPropertyConfig.getSslParam())
            .process(apiLoggingInterceptor)
            .log(LoggingLevel.INFO, "[CREATE-BW] Response status: ${header.CamelHttpResponseCode}")
            .log(LoggingLevel.DEBUG, "[CREATE-BW] Response body: ${body}")
            
            .process(exchange -> {
                Integer responseCode = exchange.getIn().getHeader(Exchange.HTTP_RESPONSE_CODE, Integer.class);
                String responseBody = exchange.getIn().getBody(String.class);
                
                if (responseCode == 200 || responseCode == 201) {
                    // Parse response to extract bw_id from results.id
                    DocumentContext response = JsonPath.parse(responseBody);
                    Integer bwId = response.read("$.results.id", Integer.class);
                    exchange.setProperty("bwId", bwId);
                    exchange.setProperty("bwCreated", true);
                    log.info("[CREATE-BW] Business Workspace created successfully with ID: {}", bwId);
                } else if (responseCode == 500) {
                    // 500 might mean BW already exists - try to extract from error or use existing bw_id
                    log.warn("[CREATE-BW] Received 500 error - BW may already exist. Response: {}", responseBody);
                    exchange.setProperty("bwCreated", false);
                    // Keep existing bw_id from earlier GetParentID call
                } else {
                    log.error("[CREATE-BW] Failed to create BW. Status: {}, Response: {}", responseCode, responseBody);
                    exchange.setProperty("bwCreated", false);
                }
            });

        // Build Business Workspace creation payload
        from("direct:build-bw-payload")
            .routeId("build-bw-payload")
            .log(LoggingLevel.INFO, "[BUILD-BW-PAYLOAD] Building BW creation payload")
            .process(exchange -> {
                String requestBody = exchange.getProperty("requestBody", String.class);
                log.info("[BUILD-BW-PAYLOAD] RequestBody from property: {}", requestBody != null ? "Present (" + requestBody.length() + " chars)" : "NULL");
                DocumentContext requestJson = JsonPath.parse(requestBody);
                
                // Extract WorkspaceType from request
                String workspaceType = requestJson.read("$.Document.WorkspaceInfo.WorkspaceType", String.class);
                log.info("[BUILD-BW-PAYLOAD] WorkspaceType extracted: {}", workspaceType);
                
                // Get cached category mappings for this workspacetype
                DocumentContext categoryMappings = categoryMappingCacheService.getCategoryMappings();
                
                // Filter mappings by workspacetype
                List<Map<String, Object>> allMappings = categoryMappings.read("$.myRows[*]");
                log.info("[BUILD-BW-PAYLOAD] Total mappings in cache: {}", allMappings.size());
                List<Map<String, Object>> filteredMappings = new ArrayList<>();
                for (Map<String, Object> mapping : allMappings) {
                    String mappingWorkspaceType = (String) mapping.get("workspacetype");
                    if (workspaceType.equalsIgnoreCase(mappingWorkspaceType)) {
                        filteredMappings.add(mapping);
                    }
                }
                
                log.info("[BUILD-BW-PAYLOAD] Filtered {} mappings for workspacetype '{}' from {} total", filteredMappings.size(), workspaceType, allMappings.size());
                if (filteredMappings.isEmpty()) {
                    log.error("[BUILD-BW-PAYLOAD] No mappings found for workspacetype '{}'. Available types: {}", 
                        workspaceType,
                        allMappings.stream().map(m -> m.get("workspacetype")).distinct().toList());
                }
                
                // Get categories array from request
                List<Map<String, Object>> categories = requestJson.read("$.Document.categories[*]");
                
                // Build categories map: categoryid -> {metadataid: value}
                Map<String, Map<String, String>> categoryMap = new LinkedHashMap<>();
                
                // ===== STEP 1: Map from categories array (matching workspacetype) =====
                String rootTransactionNumber = exchange.getProperty("transactionNumber", String.class);
                
                for (Map<String, Object> mapping : filteredMappings) {
                    String categoryId = String.valueOf(mapping.get("categoryid"));
                    String metadataId = String.valueOf(mapping.get("metadataid"));
                    String otAttributeName = (String) mapping.get("otattributename");
                    String categoryName = (String) mapping.get("categoryname");
                    
                    if (otAttributeName == null || otAttributeName.trim().isEmpty()) {
                        continue;
                    }
                    
                    // Find matching category in request
                    for (Map<String, Object> requestCategory : categories) {
                        String requestCategoryName = (String) requestCategory.get("category_name");
                        
                        if (requestCategoryName != null && requestCategoryName.equalsIgnoreCase(categoryName)) {
                            Map<String, Object> attributes = (Map<String, Object>) requestCategory.get("attributes");
                            
                            if (attributes != null) {
                                String value = null;
                                
                                // TransactionNumber is ALWAYS at root level only (not in category attributes)
                                if ("TransactionNumber".equalsIgnoreCase(otAttributeName)) {
                                    value = rootTransactionNumber;
                                    if (value != null) {
                                        log.debug("[BUILD-BW-PAYLOAD] Using TransactionNumber from root: {}", value);
                                    }
                                } else {
                                    // For all other attributes, look in category attributes
                                    // Try exact match first
                                    value = (String) attributes.get(otAttributeName);
                                    
                                    // If not found, try case-insensitive match
                                    if (value == null) {
                                        for (Map.Entry<String, Object> attr : attributes.entrySet()) {
                                            if (attr.getKey().equalsIgnoreCase(otAttributeName)) {
                                                value = String.valueOf(attr.getValue());
                                                break;
                                            }
                                        }
                                    }
                                }
                                
                                if (value != null && !value.trim().isEmpty() && !"null".equals(value)) {
                                    // Create category entry if not exists
                                    categoryMap.putIfAbsent(categoryId, new LinkedHashMap<>());
                                    
                                    // Add metadata: {categoryid}_{metadataid} = value
                                    String key = categoryId + "_" + metadataId;
                                    categoryMap.get(categoryId).put(key, value);
                                    
                                    log.debug("[BUILD-BW-PAYLOAD] Mapped from categories {}_{}: {} = {}", categoryId, metadataId, otAttributeName, value);
                                }
                            }
                        }
                    }
                }
                
                // ===== STEP 2: Map from documentMetadata (use ALL mappings, not just filtered by workspacetype) =====
                Map<String, Object> documentMetadata = null;
                try {
                    documentMetadata = requestJson.read("$.Document.documentMetadata");
                    log.info("[BUILD-BW-PAYLOAD] Found documentMetadata with {} fields", documentMetadata.size());
                } catch (Exception e) {
                    log.debug("[BUILD-BW-PAYLOAD] No documentMetadata found in request");
                }
                
                if (documentMetadata != null && !documentMetadata.isEmpty()) {
                    // Use ALL mappings from cache, not just filteredMappings
                    for (Map<String, Object> mapping : allMappings) {
                        String categoryId = String.valueOf(mapping.get("categoryid"));
                        String metadataId = String.valueOf(mapping.get("metadataid"));
                        String otAttributeName = (String) mapping.get("otattributename");
                        
                        if (otAttributeName == null || otAttributeName.trim().isEmpty()) {
                            continue;
                        }
                        
                        // Find value in documentMetadata (case-insensitive)
                        String value = null;
                        for (Map.Entry<String, Object> entry : documentMetadata.entrySet()) {
                            if (entry.getKey().equalsIgnoreCase(otAttributeName)) {
                                Object valueObj = entry.getValue();
                                if (valueObj != null && !"file_content_base64".equalsIgnoreCase(entry.getKey())) {
                                    value = valueObj.toString();
                                }
                                break;
                            }
                        }
                        
                        if (value != null && !value.trim().isEmpty() && !"null".equals(value)) {
                            // Create category entry if not exists
                            categoryMap.putIfAbsent(categoryId, new LinkedHashMap<>());
                            
                            // Add metadata: {categoryid}_{metadataid} = value
                            String key = categoryId + "_" + metadataId;
                            categoryMap.get(categoryId).put(key, value);
                            
                            log.debug("[BUILD-BW-PAYLOAD] Mapped from documentMetadata {}_{}: {} = {}", categoryId, metadataId, otAttributeName, value);
                        }
                    }
                }
                
                // Keep category map NESTED by categoryId (DO NOT flatten for workspace creation)
                // Structure: {"464257": {"464257_3":"Policy"}, "79674": {"79674_3":"CUST123"}}
                log.info("[BUILD-BW-PAYLOAD] Built {} categories with total {} attributes", 
                    categoryMap.size(),
                    categoryMap.values().stream().mapToInt(Map::size).sum());
                
                // Get template_id from cache (all rows have same templateid)
                Integer templateId = null;
                if (filteredMappings.isEmpty()) {
                    // No mappings found - throw detailed error
                    Set<String> availableTypes = allMappings.stream()
                        .map(m -> (String) m.get("workspacetype"))
                        .filter(Objects::nonNull)
                        .collect(java.util.stream.Collectors.toSet());
                    
                    throw new IllegalStateException(
                        String.format("No category mappings found for workspacetype '%s'. " +
                            "Available types in cache: %s. " +
                            "Please ensure your request's Document.WorkspaceInfo.WorkspaceType matches one of these values.",
                            workspaceType, availableTypes));
                }
                
                Object templateIdObj = filteredMappings.get(0).get("templateid");
                if (templateIdObj instanceof String) {
                    templateId = Integer.parseInt((String) templateIdObj);
                } else if (templateIdObj instanceof Integer) {
                    templateId = (Integer) templateIdObj;
                }
                
                if (templateId == null) {
                    throw new IllegalStateException("template_id not found in filtered category mappings");
                }
                
                log.info("[BUILD-BW-PAYLOAD] Using template_id: {}", templateId);
                
                // Build final payload with NESTED categories
                Map<String, Object> payload = new LinkedHashMap<>();
                payload.put("template_id", templateId);
                
                Map<String, Object> roles = new LinkedHashMap<>();
                roles.put("categories", categoryMap);  // Use nested map
                payload.put("roles", roles);
                
                // Convert to JSON
                String payloadJson = JsonPath.parse(payload).jsonString();
                exchange.getIn().setBody(payloadJson);
                
                log.info("[BUILD-BW-PAYLOAD] Payload built successfully");
                log.debug("[BUILD-BW-PAYLOAD] Final payload: {}", payloadJson);
            });
    }
}
