package com.orchestrator.routes;

import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.orchestrator.config.ApiLoggingInterceptor;
import com.orchestrator.config.ResponseLoggingInterceptor;
import com.orchestrator.config.SslPropertyConfig;
import com.orchestrator.config.W3CTraceHeaderInjector;
import com.orchestrator.exception.GlobalExceptionHandler;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.camel.LoggingLevel;
import org.apache.camel.builder.RouteBuilder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

/**
 * Upload Large Document API - Phase 2 of 2-phase upload
 * 
 * Endpoint: POST /api/v1/UploadLargeDocument?UploadKey={transactionNumber_timestamp}
 * Content-Type: application/octet-stream
 * 
 * Request: Raw file stream (NOT base64)
 * Response: Upload status
 * 
 * CRITICAL: Streams file to disk without loading to memory
 * 
 * Flow:
 * 1. Get Id from query parameter
 * 2. Stream file to folder (STREAMING - NO MEMORY)
 * 3. Load metadata from folder
 * 4. Authenticate OTCS
 * 5. Get/Create Business Workspace
 * 6. Stream multipart to OTCS (STREAMING - NO MEMORY)
 * 7. Cleanup folder
 * 
 * NOTE: No session validation - just folder/file operations
 */
@Component
@RequiredArgsConstructor
@Slf4j
public class EndLargeFileUploadRoute extends RouteBuilder {

    private final GlobalExceptionHandler globalExceptionHandler;
    private final SslPropertyConfig sslPropertyConfig;
    private final W3CTraceHeaderInjector w3cTraceHeaderInjector;
    private final ApiLoggingInterceptor apiLoggingInterceptor;
    private final ResponseLoggingInterceptor responseLoggingInterceptor;
    
    @Value("${app.FILE_UPLOAD_PATH:/mnt/sftp-volume}")
    private String uploadPath;

    @Override
    public void configure() throws Exception {

        // Global exception handling
        onException(Exception.class)
            .handled(true)
            .process(globalExceptionHandler)
            .log(LoggingLevel.ERROR, "[END-LARGE-UPLOAD] Exception processed by GlobalExceptionHandler");

        // Main endpoint - accepts file stream
        from("netty-http:http://{{app.NETTY_MOCK_HOST}}:{{app.NETTY_MOCK_PORT}}/api/v1/UploadLargeDocument"
                + "?httpMethodRestrict=POST"
                + "&matchOnUriPrefix=false"
                + "&chunked=true"  // Enable streaming
                + "&chunkedMaxContentLength=10737418240")  // 10GB limit, won't buffer - streams directly
            .routeId("upload-large-document-api")
            .process(exchange -> exchange.setProperty("EXPOSED_API_ENDPOINT", "POST /api/v1/UploadLargeDocument"))
            .log(LoggingLevel.INFO, "[END-LARGE-UPLOAD] ========== End Large File Upload Request Received ==========")
            
            // Step 1: Get UploadKey from query parameter
            .process(exchange -> {
                String id = exchange.getIn().getHeader("UploadKey", String.class);
                
                if (id == null || id.isEmpty()) {
                    throw new IllegalArgumentException("UploadKey query parameter is required");
                }
                
                // Validate folder exists
                Path folderPath = Paths.get(uploadPath, id);
                if (!Files.exists(folderPath)) {
                    throw new IllegalArgumentException("Invalid UploadKey: folder not found - " + id);
                }
                
                log.info("[END-LARGE-UPLOAD] Folder found for UploadKey: {}", id);
                
                // Store Id for later steps
                exchange.setProperty("id", id);
                exchange.setProperty("folderPath", folderPath.toString());
            })
            
            // Step 2: Load metadata from folder (BEFORE streaming file)
            .process(exchange -> {
                String id = exchange.getProperty("id", String.class);
                Path folderPath = Paths.get(exchange.getProperty("folderPath", String.class));
                
                // Read metadata.json
                Path metadataPath = folderPath.resolve("metadata.json");
                if (!Files.exists(metadataPath)) {
                    throw new IllegalArgumentException("Metadata not found for Id: " + id);
                }
                
                String metadata = Files.readString(metadataPath);
                log.info("[END-LARGE-UPLOAD] Loaded metadata for Id: {}", id);
                
                // Extract fileName and transactionNumber from metadata
                DocumentContext json = JsonPath.parse(metadata);
                String fileName = json.read("$.Document.documentMetadata.file_name", String.class);
                String transactionNumber = json.read("$.Document.WorkspaceInfo.TransactionNumber", String.class);
                
                if (fileName == null || fileName.isEmpty()) {
                    throw new IllegalArgumentException("file_name not found in metadata");
                }
                if (transactionNumber == null || transactionNumber.isEmpty()) {
                    throw new IllegalArgumentException("TransactionNumber not found in metadata");
                }
                
                log.info("[END-LARGE-UPLOAD] Extracted from metadata - File: {}, TransactionNumber: {}", fileName, transactionNumber);
                
                // Store for next steps
                exchange.setProperty("payload", metadata);
                exchange.setProperty("fileName", fileName);
                exchange.setProperty("transactionNumber", transactionNumber);
            })
            
            // Step 3: Stream file to disk (CRITICAL: NO MEMORY LOAD)
            .process(exchange -> {
                String id = exchange.getProperty("id", String.class);
                String fileName = exchange.getProperty("fileName", String.class);
                Path folderPath = Paths.get(exchange.getProperty("folderPath", String.class));
                
                // Get file stream from request body (STREAMING - NOT LOADED TO MEMORY)
                InputStream fileStream = exchange.getIn().getBody(InputStream.class);
                
                if (fileStream == null) {
                    throw new IllegalArgumentException("Request body must contain file stream");
                }
                
                // Get target file path
                Path targetFilePath = folderPath.resolve(fileName);
                
                log.info("[END-LARGE-UPLOAD] Streaming file to disk: {}", targetFilePath);
                
                // Stream file to disk (STREAMING - uses ~8KB buffer, NO heap spike)
                long bytesWritten = Files.copy(fileStream, targetFilePath, StandardCopyOption.REPLACE_EXISTING);
                
                log.info("[END-LARGE-UPLOAD] File streamed to disk: {} bytes written", bytesWritten);
                
                // Store file path for next steps
                exchange.setProperty("filePath", targetFilePath.toString());
                exchange.setProperty("fileSize", bytesWritten);
            })
            
            // Step 4: Authenticate with OTCS
            .log(LoggingLevel.INFO, "[END-LARGE-UPLOAD] Step 4: Authenticating with OTCS")
            .to("direct:authenticate-otcs")
            .log(LoggingLevel.INFO, "[END-LARGE-UPLOAD] Authentication successful")
            
            // Step 5: Get workspace ID (sets bwExists property)
            .to("direct:get-business-workspace-id")
            
            // Step 6: Create workspace if needed
            .choice()
                .when(exchangeProperty("bwExists").isEqualTo(false))
                    .log(LoggingLevel.WARN, "[END-LARGE-UPLOAD] Workspace not found, creating...")
                    .process(exchange -> {
                        String payload = exchange.getProperty("payload", String.class);
                        exchange.setProperty("requestBody", payload);
                    })
                    .to("direct:create-bw-for-upload")
                .otherwise()
                    .log(LoggingLevel.INFO, "[END-LARGE-UPLOAD] Workspace exists: ${exchangeProperty.bwId}")
            .end()
            
            // Step 7: Build multipart body
            .log(LoggingLevel.INFO, "[END-LARGE-UPLOAD] Step 7: Building multipart")
            .process("streamingFileUploadProcessor")
            
            // Step 8: Upload to OTCS /v2/nodes
            .log(LoggingLevel.INFO, "[END-LARGE-UPLOAD] Step 8: Uploading to OTCS /v2/nodes")
            .process(exchange -> {
                exchange.setProperty("API_START_TIME", System.currentTimeMillis());
                exchange.setProperty("API_ENDPOINT", "POST /api/v2/nodes");
            })
            .setHeader("OTCSTicket", exchangeProperty("otcsTicket"))
            // ── W3C FIX: inject traceparent before outbound call ──────────────
            .process(w3cTraceHeaderInjector)
            .toD("{{app.OTCS_BASE_URL}}/api/v2/nodes?bridgeEndpoint=true&throwExceptionOnFailure=false" + sslPropertyConfig.getSslParam())
            .process(apiLoggingInterceptor)
            .log(LoggingLevel.INFO, "[END-LARGE-UPLOAD] Upload response status: ${header.CamelHttpResponseCode}")
            
            // Step 9: Transform response
            .to("direct:upload-api-response")
            
            // Step 9: Cleanup folder (COMMENTED OUT - pending team discussion on orphan folder handling)
            // TODO: Decide cleanup strategy - immediate delete vs scheduled job vs retention policy
            /*
            .process(exchange -> {
                String id = exchange.getProperty("id", String.class);
                Path folderPath = Paths.get(exchange.getProperty("folderPath", String.class));
                
                log.info("[END-LARGE-UPLOAD] Cleaning up folder: {}", id);
                
                try {
                    // Delete all files in folder
                    Files.walk(folderPath)
                        .sorted((p1, p2) -> -p1.compareTo(p2))  // Reverse order for deletion
                        .forEach(path -> {
                            try {
                                Files.deleteIfExists(path);
                            } catch (Exception e) {
                                log.warn("[END-LARGE-UPLOAD] Failed to delete: {}", path, e);
                            }
                        });
                    
                    log.info("[END-LARGE-UPLOAD] Folder cleaned up: {}", id);
                } catch (Exception e) {
                    log.error("[END-LARGE-UPLOAD] Failed to cleanup folder: {}", folderPath, e);
                    // Don't fail the request if cleanup fails
                }
            })
            */
            
            .log(LoggingLevel.INFO, "[END-LARGE-UPLOAD] ========== Large File Upload Complete ==========")
                        .process(responseLoggingInterceptor)            // Set response headers
            .setHeader(Exchange.HTTP_RESPONSE_CODE, constant(200))
            .setHeader(Exchange.CONTENT_TYPE, constant("application/json"));
    }
}
