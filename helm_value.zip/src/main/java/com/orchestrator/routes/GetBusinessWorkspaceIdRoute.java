package com.orchestrator.routes;

import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.orchestrator.config.ApiLoggingInterceptor;
import com.orchestrator.config.SslPropertyConfig;
import com.orchestrator.config.W3CTraceHeaderInjector;
import com.orchestrator.exception.GlobalExceptionHandler;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.camel.LoggingLevel;
import org.apache.camel.builder.RouteBuilder;
import org.springframework.stereotype.Component;

/**
 * Get Business Workspace ID from GetParentID WebReport
 * Reusable route for both Document Upload API and Kafka Workspace flows
 * 
 * INPUT: Requires exchange property "transactionNumber"
 * OUTPUT: Sets exchange properties "bwExists" (boolean) and "bwId" (Integer if exists)
 */
@Component
@RequiredArgsConstructor
@Slf4j
public class GetBusinessWorkspaceIdRoute extends RouteBuilder {

    private final SslPropertyConfig sslPropertyConfig;
    private final W3CTraceHeaderInjector w3cTraceHeaderInjector;
    private final GlobalExceptionHandler globalExceptionHandler;
    private final ApiLoggingInterceptor apiLoggingInterceptor;

    @Override
    public void configure() throws Exception {

        // Global exception handling
        onException(Exception.class)
            .handled(true)
            .process(globalExceptionHandler)
            .log(LoggingLevel.ERROR, "[GET-BW-ID] Exception processed by GlobalExceptionHandler");

        // Reusable route to get Business Workspace ID from WebReport
        from("direct:get-business-workspace-id")
            .routeId("get-business-workspace-id")
            .log(LoggingLevel.INFO, "[GET-BW-ID] Getting Business Workspace ID")
            .process(exchange -> {
                String transactionNumber = exchange.getProperty("transactionNumber", String.class);
                log.info("[GET-BW-ID] Looking up BW ID for Transaction Number: {}", transactionNumber);
            })
            
            // Clear body for GET request
            .setBody(constant(""))
            .setHeader(Exchange.HTTP_METHOD, constant("GET"))
            .setHeader("Accept", constant("application/json"))
            
            // Call GetParentID WebReport
            .log(LoggingLevel.INFO, "[GET-BW-ID] Calling GetParentID WebReport")
            .process(exchange -> {
                String url = "{{app.OTCS_BASE_URL}}/api/v1/webreports/GetParentID?format=json&suppress_response_codes=string&TransactionNumber=" + exchange.getProperty("transactionNumber", String.class);
                log.info("[GET-BW-ID] URL: {}", url);
                exchange.setProperty("API_START_TIME", System.currentTimeMillis());
                exchange.setProperty("API_ENDPOINT", "GET /api/v1/webreports/GetParentID");
            })
            // ── W3C FIX: inject traceparent before outbound call ──────────────
            .process(w3cTraceHeaderInjector)
            .toD("{{app.OTCS_BASE_URL}}/api/v1/webreports/GetParentID?format=json&suppress_response_codes=string&TransactionNumber=${exchangeProperty.transactionNumber}&bridgeEndpoint=true&throwExceptionOnFailure=false" + sslPropertyConfig.getSslParam())
            .process(apiLoggingInterceptor)
            .log(LoggingLevel.INFO, "[GET-BW-ID] HTTP Status: ${header.CamelHttpResponseCode}")
            .log(LoggingLevel.INFO, "[GET-BW-ID] Response Body: ${body}")
            
            .process(exchange -> {
                String response = exchange.getIn().getBody(String.class);
                String transactionNumber = exchange.getProperty("transactionNumber", String.class);
                
                // Parse nested JSON response: {"data": "{...JSON string...}", "statusCode": 200}
                DocumentContext outerJson = JsonPath.parse(response);
                String dataString = outerJson.read("$.data", String.class);
                
                // Parse inner JSON to check if BW exists
                DocumentContext innerJson = JsonPath.parse(dataString);
                Integer actualRows = innerJson.read("$.actualRows", Integer.class);
                
                if (actualRows == 0) {
                    // Business Workspace doesn't exist
                    log.warn("[GET-BW-ID] Business Workspace not found for Transaction Number: {}", transactionNumber);
                    exchange.setProperty("bwId", null);
                    exchange.setProperty("bwExists", false);
                } else {
                    // BW exists - extract ID
                    Integer bwId = innerJson.read("$.myRows[0].id", Integer.class);
                    log.info("[GET-BW-ID] Business Workspace ID (bw_id): {}", bwId);
                    exchange.setProperty("bwId", bwId);
                    exchange.setProperty("bwExists", true);
                }
            });
    }
}
