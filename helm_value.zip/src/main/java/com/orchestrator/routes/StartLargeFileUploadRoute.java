package com.orchestrator.routes;

import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.orchestrator.config.ResponseLoggingInterceptor;
import com.orchestrator.exception.GlobalExceptionHandler;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.camel.LoggingLevel;
import org.apache.camel.builder.RouteBuilder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Start Large Document Upload API - Phase 1 of 2-phase upload
 * 
 * Endpoint: POST /api/v1/StartLargeDocument
 * Content-Type: application/json
 * 
 * Request: Metadata only (NO file_content_base64)
 * Response: Id (transactionNumber_timestamp) for file upload in Phase 2
 * 
 * Purpose:
 * - Validate metadata
 * - Create folder with Id as name
 * - Save metadata.json
 * - Return Id for EndLargeFileUpload
 * 
 * NOTE: No session management - just folder creation
 */
@Component
@RequiredArgsConstructor
@Slf4j
public class StartLargeFileUploadRoute extends RouteBuilder {

    private final GlobalExceptionHandler globalExceptionHandler;
    private final ResponseLoggingInterceptor responseLoggingInterceptor;
    
    @Value("${app.FILE_UPLOAD_PATH:/mnt/sftp-volume}")
    private String uploadPath;

    @Override
    public void configure() throws Exception {

        // Global exception handling
        onException(Exception.class)
            .handled(true)
            .process(globalExceptionHandler)
            .log(LoggingLevel.ERROR, "[START-LARGE-UPLOAD] Exception processed by GlobalExceptionHandler");

        // Main endpoint
        from("netty-http:http://{{app.NETTY_MOCK_HOST}}:{{app.NETTY_MOCK_PORT}}/api/v1/StartLargeDocument"
                + "?httpMethodRestrict=POST"
                + "&matchOnUriPrefix=false")
            .routeId("start-large-document-api")
            .process(exchange -> exchange.setProperty("EXPOSED_API_ENDPOINT", "POST /api/v1/StartLargeDocument"))
            .log(LoggingLevel.INFO, "[START-LARGE-UPLOAD] ========== Start Large File Upload Request Received ==========")
            .log(LoggingLevel.DEBUG, "[START-LARGE-UPLOAD] Request body: ${body}")
            
            // Step 1: Validate request schema using unified schema
            .to("json-validator:schemas/request-schema.json")
            .log(LoggingLevel.INFO, "[START-LARGE-UPLOAD] Request validation successful")
            
            // Step 2: Extract metadata for folder creation
            .process(exchange -> {
                String requestBody = exchange.getIn().getBody(String.class);
                DocumentContext json = JsonPath.parse(requestBody);
                
                String transactionNumber = json.read("$.Document.WorkspaceInfo.TransactionNumber", String.class);
                String fileName = json.read("$.Document.documentMetadata.file_name", String.class);
                
                log.info("[START-LARGE-UPLOAD] TransactionNumber: {}, File: {}", transactionNumber, fileName);
                
                exchange.setProperty("transactionNumber", transactionNumber);
                exchange.setProperty("fileName", fileName);
                exchange.setProperty("metadata", requestBody);
            })
            
            // Step 3: Create folder with Id (transactionNumber_timestamp)
            .process(exchange -> {
                String transactionNumber = exchange.getProperty("transactionNumber", String.class);
                String metadata = exchange.getProperty("metadata", String.class);
                
                // Generate Id: transactionNumber_epochTime
                String timestamp = String.valueOf(System.currentTimeMillis());
                String id = transactionNumber + "_" + timestamp;
                
                log.info("[START-LARGE-UPLOAD] Creating folder for Id: {}", id);
                
                // Create folder
                Path folderPath = Paths.get(uploadPath, id);
                try {
                    Files.createDirectories(folderPath);
                    
                    // Save metadata.json
                    Path metadataPath = folderPath.resolve("metadata.json");
                    Files.writeString(metadataPath, metadata);
                    
                    log.info("[START-LARGE-UPLOAD] Folder created: {}", folderPath);
                } catch (IOException e) {
                    log.error("[START-LARGE-UPLOAD] Failed to create folder: {}", folderPath, e);
                    throw new RuntimeException("Failed to create upload folder: " + e.getMessage(), e);
                }
                
                exchange.setProperty("id", id);
                log.info("[START-LARGE-UPLOAD] Id generated: {}", id);
            })
            
            // Step 4: Build response
            .process(exchange -> {
                String id = exchange.getProperty("id", String.class);
                
                // Build simplified response
                Map<String, Object> response = new LinkedHashMap<>();
                response.put("Uniqueid", id);
                
                String responseJson = JsonPath.parse(response).jsonString();
                exchange.getIn().setBody(responseJson);
                
                log.info("[START-LARGE-UPLOAD] Response prepared for Id: {}", id);
            })
            
            .log(LoggingLevel.INFO, "[START-LARGE-UPLOAD] ========== Folder Created Successfully ==========")
                        .process(responseLoggingInterceptor)
                        // Set response headers
            .setHeader(Exchange.HTTP_RESPONSE_CODE, constant(200))
            .setHeader(Exchange.CONTENT_TYPE, constant("application/json"));
    }
}
