package com.orchestrator.routes;

import com.orchestrator.config.W3CTracePropagationFilter;
import lombok.RequiredArgsConstructor;
import org.apache.camel.LoggingLevel;
import org.apache.camel.builder.RouteBuilder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class KafkaConsumerRoute extends RouteBuilder {

    @Value("${app.KAFKA_THREAD_POOL_MIN}")
    private int threadPoolMin;

    @Value("${app.KAFKA_THREAD_POOL_MAX}")
    private int threadPoolMax;

    // W3C trace capture — injected via constructor (Lombok @RequiredArgsConstructor)
    private final W3CTracePropagationFilter w3cTracePropagationFilter;

    @Override
    public void configure() {

        // Real Kafka consumer
        from("kafka:{{app.KAFKA_SUBMISSION_TOPIC}}")
                .routeId("kafka-to-OT")
                .threads(threadPoolMin, threadPoolMax, "escape-to-OT-threadPool")
                .log(LoggingLevel.INFO, "Step 1: Kafka received payload: ${body}")

                // ── W3C FIX: Capture traceparent from Kafka message headers ──────
                // Kafka producers that support W3C trace context will include
                // a `traceparent` header in the Kafka record. We capture it here
                // at the entry point so it propagates through all downstream calls.
                .process(w3cTracePropagationFilter)
                .log(LoggingLevel.DEBUG, "[W3C-TRACE] Trace context captured from Kafka message")
                // ─────────────────────────────────────────────────────────────────

                .to("direct:orchestrate-business-workspace");
    }
}