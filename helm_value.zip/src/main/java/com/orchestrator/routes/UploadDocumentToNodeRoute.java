package com.orchestrator.routes;

import com.orchestrator.config.SslPropertyConfig;
import com.orchestrator.config.W3CTraceHeaderInjector;
import com.orchestrator.exception.GlobalExceptionHandler;
import com.orchestrator.service.CategoryMappingCacheService;
import com.orchestrator.util.MultipartBodyBuilder;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.camel.LoggingLevel;
import org.apache.camel.builder.RouteBuilder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;

/**
* Step 6: Upload Document to Business Workspace
* Multipart upload with base64 file decoding and dynamic category mapping
*/
@Component
@RequiredArgsConstructor
@Slf4j
public class UploadDocumentToNodeRoute extends RouteBuilder {

    private final CategoryMappingCacheService categoryMappingCacheService;
    private final SslPropertyConfig sslPropertyConfig;
    private final W3CTraceHeaderInjector w3cTraceHeaderInjector;
    private final GlobalExceptionHandler globalExceptionHandler;

    @Value("${app.FILE_UPLOAD_PATH}")
    private String fileUploadPath;

    @Override
    public void configure() throws Exception {

        // Global exception handling
        onException(Exception.class)
            .handled(true)
            .process(globalExceptionHandler)
            .log(LoggingLevel.ERROR, "[UPLOAD-DOCUMENT] Exception processed by GlobalExceptionHandler");

        // Step 6: Upload document to BW as node
        from("direct:upload-document-to-node")
            .routeId("upload-document-to-node")
            .log(LoggingLevel.INFO, "[UPLOAD-NODE] Step 6: Uploading document to Business Workspace")

            // Build document upload payload (body part for multipart)
            .to("direct:build-document-payload")

            // Prepare multipart upload
            .to("direct:prepare-multipart-upload")

            // Upload document to /v2/nodes
            .log(LoggingLevel.INFO, "[UPLOAD-NODE] Uploading to POST /v2/nodes")
            .setHeader(Exchange.HTTP_METHOD, constant("POST"))
            .setHeader("OTCSTicket", exchangeProperty("otcsTicket"))
            // Keep Content-Type header with boundary set in prepare-multipart-upload
            // ── W3C FIX: inject traceparent before outbound call ──────────────
            .process(w3cTraceHeaderInjector)
            .toD("{{app.OTCS_BASE_URL}}/api/v2/nodes?bridgeEndpoint=true&throwExceptionOnFailure=false" + sslPropertyConfig.getSslParam())
            .log(LoggingLevel.INFO, "[UPLOAD-NODE] Upload response status: ${header.CamelHttpResponseCode}")
            .log(LoggingLevel.DEBUG, "[UPLOAD-NODE] Upload response body: ${body}")

            .process(exchange -> {
                Integer responseCode = exchange.getIn().getHeader(Exchange.HTTP_RESPONSE_CODE, Integer.class);
                String responseBody = exchange.getIn().getBody(String.class);

                if (responseCode == 200 || responseCode == 201) {
                    log.info("[UPLOAD-NODE] Document uploaded successfully");
                    exchange.setProperty("documentUploaded", true);
                } else {
                    log.error("[UPLOAD-NODE] Failed to upload document. Status: {}, Response: {}", responseCode, responseBody);
                    exchange.setProperty("documentUploaded", false);
                }
            })

            // Transform response to simplified format
            .to("direct:upload-api-response");

        // Build document upload payload (JSON body part)
        from("direct:build-document-payload")
            .routeId("build-document-payload")
            .log(LoggingLevel.INFO, "[BUILD-DOC-PAYLOAD] Building document upload payload")
            .process(exchange -> {
                String requestBody = exchange.getProperty("requestBody", String.class);
                DocumentContext requestJson = JsonPath.parse(requestBody);
                Integer bwId = exchange.getProperty("bwId", Integer.class);

                // Get document metadata from request
                Map<String, Object> documentMetadata = requestJson.read("$.Document.documentMetadata");
                String fileName = (String) documentMetadata.get("file_name");

                log.info("[BUILD-DOC-PAYLOAD] Building payload for file: {}", fileName);
                log.info("[BUILD-DOC-PAYLOAD] Parent BW ID: {}", bwId);

                // Get cached category mappings filtered by workspacetype = "Document"
                DocumentContext categoryMappings = categoryMappingCacheService.getCategoryMappings();
                List<Map<String, Object>> allMappings = categoryMappings.read("$.myRows[*]");

                // Filter by workspacetype = "Document"
                List<Map<String, Object>> documentMappings = new ArrayList<>();
                for (Map<String, Object> mapping : allMappings) {
                    String workspaceType = (String) mapping.get("workspacetype");
                    if ("Document".equalsIgnoreCase(workspaceType)) {
                        documentMappings.add(mapping);
                    }
                }

                log.info("[BUILD-DOC-PAYLOAD] Found {} Document category mappings", documentMappings.size());

                // Build categories from documentMetadata using otattributename
                Map<String, String> categories = new LinkedHashMap<>();

                for (Map<String, Object> mapping : documentMappings) {
                    String categoryId = String.valueOf(mapping.get("categoryid"));
                    String metadataId = String.valueOf(mapping.get("metadataid"));
                    String otAttributeName = (String) mapping.get("otattributename");

                    if (otAttributeName == null || otAttributeName.trim().isEmpty()) {
                        continue;
                    }

                    // Try to find value in documentMetadata
                    String value = null;

                    // Exact match
                    if (documentMetadata.containsKey(otAttributeName)) {
                        value = String.valueOf(documentMetadata.get(otAttributeName));
                    } else {
                        // Case-insensitive match
                        for (Map.Entry<String, Object> entry : documentMetadata.entrySet()) {
                            if (entry.getKey().equalsIgnoreCase(otAttributeName)) {
                                value = String.valueOf(entry.getValue());
                                break;
                            }
                        }
                    }

                    if (value != null && !value.trim().isEmpty() && !"null".equals(value)) {
                        String key = categoryId + "_" + metadataId;
                        categories.put(key, value);
                        log.debug("[BUILD-DOC-PAYLOAD] Mapped {}_{}: {} = {}", categoryId, metadataId, otAttributeName, value);
                    }
                }

                log.info("[BUILD-DOC-PAYLOAD] Built {} document category attributes", categories.size());

                // Build payload structure
                Map<String, Object> payload = new LinkedHashMap<>();
                payload.put("type", 144);
                payload.put("parent_id", bwId);
                payload.put("name", fileName);
                payload.put("description", "");

                Map<String, Object> roles = new LinkedHashMap<>();
                roles.put("categories", categories);
                payload.put("roles", roles);

                // Convert to JSON
                String payloadJson = JsonPath.parse(payload).jsonString();
                exchange.setProperty("documentPayloadJson", payloadJson);

                log.info("[BUILD-DOC-PAYLOAD] Document payload built successfully");
                log.debug("[BUILD-DOC-PAYLOAD] Payload: {}", payloadJson);
            });

        // Prepare multipart upload with file from disk
        from("direct:prepare-multipart-upload")
            .routeId("prepare-multipart-upload")
            .log(LoggingLevel.INFO, "[PREPARE-MULTIPART] Preparing multipart upload")
            .process(exchange -> {
                String folderName = exchange.getProperty("folderName", String.class);
                String fileName = exchange.getProperty("fileName", String.class);
                String payloadJson = exchange.getProperty("documentPayloadJson", String.class);
                
                // Read binary file from disk (both routes now save as binary)
                Path binaryFilePath = Paths.get(fileUploadPath, folderName, fileName);
                log.info("[PREPARE-MULTIPART] Reading binary file: {}", binaryFilePath);
                
                byte[] fileBytes = Files.readAllBytes(binaryFilePath);
                log.info("[PREPARE-MULTIPART] File size: {} bytes", fileBytes.length);

                // Build multipart using utility
                MultipartBodyBuilder.Result result = MultipartBodyBuilder.build(payloadJson, fileBytes, fileName);

                // Set body and Content-Type header
                exchange.getIn().setBody(result.getBody());
                exchange.getIn().setHeader("Content-Type", result.getContentType());

                log.info("[PREPARE-MULTIPART] Multipart prepared: {} bytes", result.getBody().length);
            });
    }
}
 