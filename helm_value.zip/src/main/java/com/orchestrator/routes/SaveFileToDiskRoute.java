package com.orchestrator.routes;

import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.orchestrator.exception.GlobalExceptionHandler;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.LoggingLevel;
import org.apache.camel.builder.RouteBuilder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

/**
 * Save file to disk before processing
 * Decodes base64 content while streaming to disk (memory-efficient)
 */
@Component
@RequiredArgsConstructor
@Slf4j
public class SaveFileToDiskRoute extends RouteBuilder {

    private final GlobalExceptionHandler globalExceptionHandler;

    @Value("${app.FILE_UPLOAD_PATH}")
    private String fileUploadPath;

    @Override
    public void configure() throws Exception {

        // Global exception handling
        onException(Exception.class)
            .handled(true)
            .process(globalExceptionHandler)
            .log(LoggingLevel.ERROR, "[SAVE-FILE-TO-DISK] Exception processed by GlobalExceptionHandler");

        from("direct:save-file-to-disk")
            .routeId("save-file-to-disk")
            .log(LoggingLevel.INFO, "[SAVE-TO-DISK] Saving file to disk (decoding base64 on-the-fly)")
            .process(exchange -> {
                String requestBody = exchange.getIn().getBody(String.class);

                // Parse request JSON
                DocumentContext json = JsonPath.parse(requestBody);

                // Extract required fields
                String transactionNumber = json.read("$.Document.WorkspaceInfo.TransactionNumber");
                String fileName = json.read("$.Document.documentMetadata.file_name");
                String base64Content = json.read("$.Document.documentMetadata.file_content_base64");

                log.info("[SAVE-TO-DISK] Transaction Number: {}", transactionNumber);
                log.info("[SAVE-TO-DISK] File Name: {}", fileName);
                log.info("[SAVE-TO-DISK] Base64 content length: {} chars", base64Content.length());

                // Generate timestamp for folder name (epoch time)
                String timestamp = String.valueOf(System.currentTimeMillis());
                String folderName = transactionNumber + "_" + timestamp;

                // Create directory: /mnt/sftp-volume/{TransactionNumber}_{timestamp}/
                Path dirPath = Paths.get(fileUploadPath, folderName);
                Files.createDirectories(dirPath);
                log.info("[SAVE-TO-DISK] Created directory: {}", dirPath.toAbsolutePath());

                // Decode base64 WHILE writing to disk (streaming decode - saves 33% memory!)
                Path filePath = dirPath.resolve(fileName);
                
                // Create Base64 InputStream decoder
                java.io.ByteArrayInputStream base64Stream = new java.io.ByteArrayInputStream(base64Content.getBytes());
                java.io.InputStream decodingStream = java.util.Base64.getDecoder().wrap(base64Stream);
                
                // Stream decoded bytes directly to file (no intermediate buffer!)
                Files.copy(decodingStream, filePath);
                
                long fileSize = Files.size(filePath);
                log.info("[SAVE-TO-DISK] Decoded and saved file: {} ({} bytes)", filePath.toAbsolutePath(), fileSize);
                log.info("[SAVE-TO-DISK] Memory saved: ~{}% by streaming decode", 
                    Math.round((base64Content.length() - fileSize) * 100.0 / base64Content.length()));

                // Store metadata in exchange properties for later steps
                exchange.setProperty("requestBody", requestBody);
                exchange.setProperty("payload", requestBody);  // For compatibility
                exchange.setProperty("transactionNumber", transactionNumber);
                exchange.setProperty("folderName", folderName);
                exchange.setProperty("fileName", fileName);
                exchange.setProperty("filePath", filePath.toString());

                log.info("[SAVE-TO-DISK] File saved successfully to: {}", filePath.toAbsolutePath());
            });
    }
}
