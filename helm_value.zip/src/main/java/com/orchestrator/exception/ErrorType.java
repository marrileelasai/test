package com.orchestrator.exception;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

/**
 * Enum for standardized error types in orchestration routes
 */
@Getter
@RequiredArgsConstructor
public enum ErrorType {
    INVALID_REQUEST("INVALID_REQUEST", 400, "Invalid request parameter or missing required field"),
    AUTHENTICATION_FAILED("AUTHENTICATION_FAILED", 401, "Authentication failed - Invalid credentials or token expired"),
    FORBIDDEN("FORBIDDEN", 403, "Access forbidden - Insufficient permissions"),
    RESOURCE_NOT_FOUND("RESOURCE_NOT_FOUND", 404, "Resource not found"),
    VALIDATION_ERROR("VALIDATION_ERROR", 422, "Validation failed - Invalid data format"),
    UPSTREAM_SERVER_ERROR("UPSTREAM_SERVER_ERROR", 502, "Upstream service error"),
    SERVICE_ERROR("SERVICE_ERROR", 502, "Service error occurred"),
    UNKNOWN("UNKNOWN", 500, "Unknown error");

    private final String errorCode;
    private final int statusCode;
    private final String defaultMessage;

    /**
     * Determines the appropriate ErrorType based on HTTP status code
     */
    public static ErrorType fromHttpStatus(int statusCode) {
        return switch (statusCode) {
            case 400 -> INVALID_REQUEST;
            case 401 -> AUTHENTICATION_FAILED;
            case 403 -> FORBIDDEN;
            case 404 -> RESOURCE_NOT_FOUND;
            case 422 -> VALIDATION_ERROR;
            case 500 -> UPSTREAM_SERVER_ERROR;
            case 502, 503, 504 -> UPSTREAM_SERVER_ERROR;
            default -> statusCode >= 500 ? UPSTREAM_SERVER_ERROR : UNKNOWN;
        };
    }

    /**
     * Determines the appropriate ErrorType based on the exception
     */
    public static ErrorType fromException(Exception exception) {
        if (exception == null) {
            return UNKNOWN;
        }

        String message = exception.getMessage();
        if (message == null) {
            return determineFromExceptionType(exception);
        }

        // Check for HTTP status codes in the message
        if (message.contains("400") || message.contains("Bad Request")) {
            return INVALID_REQUEST;
        } else if (message.contains("401") || message.contains("Authentication failed") || 
                   message.contains("Invalid username/password")) {
            return AUTHENTICATION_FAILED;
        } else if (message.contains("403") || message.contains("Forbidden")) {
            return FORBIDDEN;
        } else if (message.contains("404") || message.contains("Not Found")) {
            return RESOURCE_NOT_FOUND;
        } else if (message.contains("422") || message.contains("validation")) {
            return VALIDATION_ERROR;
        } else if (message.contains("500") || message.contains("Internal Server Error")) {
            return UPSTREAM_SERVER_ERROR;
        }

        return determineFromExceptionType(exception);
    }

    private static ErrorType determineFromExceptionType(Exception exception) {
        if (exception instanceof IllegalArgumentException) {
            return INVALID_REQUEST;
        } else if (exception instanceof IllegalStateException) {
            return SERVICE_ERROR;
        }
        return UNKNOWN;
    }
}
