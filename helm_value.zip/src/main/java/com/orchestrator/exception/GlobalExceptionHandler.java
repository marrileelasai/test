package com.orchestrator.exception;

import com.jayway.jsonpath.JsonPath;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Global exception handler for all orchestration routes
 * Logs exceptions gracefully with full stack traces and returns formatted error responses
 */
@Slf4j
@Component
public class GlobalExceptionHandler implements Processor {

    @Override
    public void process(Exchange exchange) throws Exception {
        Exception cause = exchange.getProperty(Exchange.EXCEPTION_CAUGHT, Exception.class);
        
        // Check if this is an HTTP error response (handle it!)
        Integer httpResponseCode = exchange.getIn().getHeader(Exchange.HTTP_RESPONSE_CODE, Integer.class);
        if (httpResponseCode != null && httpResponseCode >= 400) {
            // HTTP error response - map to appropriate ErrorType
            String responseBody = exchange.getIn().getBody(String.class);
            ErrorType errorType = ErrorType.fromHttpStatus(httpResponseCode);
            String errorMessage = String.format("%s (HTTP %d): %s", 
                errorType.getDefaultMessage(), httpResponseCode, 
                responseBody != null ? responseBody : "No response body");

            logError(errorType, errorMessage, exchange, null);
            buildErrorResponse(exchange, errorType, errorMessage);
            return;
        }

        // Exception-based error handling
        ErrorType errorType = ErrorType.fromException(cause);
        String errorMessage = (cause != null && cause.getMessage() != null) 
                ? cause.getMessage() 
                : errorType.getDefaultMessage();

        logError(errorType, errorMessage, exchange, cause);
        buildErrorResponse(exchange, errorType, errorMessage);
    }

    private void logError(ErrorType errorType, String errorMessage, Exchange exchange, Exception cause) {
        // Log ORCHESTRATION ERROR
        log.error("┌─────────────────────────────────────────────────────────┐");
        log.error("│ ORCHESTRATION ERROR                                     │");
        log.error("├─────────────────────────────────────────────────────────┤");
        log.error("│ Error Type    : {}", errorType.getErrorCode());
        log.error("│ Status Code   : {}", errorType.getStatusCode());
        log.error("│ Error Message : {}", errorMessage);
        log.error("│ Location      : {}", identifyErrorLocation(exchange));
        log.error("│ Exchange ID   : {}", exchange.getExchangeId());
        log.error("└─────────────────────────────────────────────────────────┘");

        if (cause != null) {
            log.error("Full stack trace:", cause);
        }
    }

    private void buildErrorResponse(Exchange exchange, ErrorType errorType, String errorMessage) {
        // Build error response using Map (consistent with rest of codebase)
        Map<String, Object> errorResponse = new LinkedHashMap<>();
        errorResponse.put("error", errorMessage);
        errorResponse.put("errorcode", errorType.getStatusCode());
        errorResponse.put("timestamp", Instant.now().toString());

        String jsonResponse = JsonPath.parse(errorResponse).jsonString();

        exchange.getIn().setBody(jsonResponse);
        exchange.getIn().setHeader(Exchange.HTTP_RESPONSE_CODE, errorType.getStatusCode());
        exchange.getIn().setHeader(Exchange.CONTENT_TYPE, "application/json");
    }

    private String identifyErrorLocation(Exchange exchange) {
        String routeId = exchange.getFromRouteId();
        if (routeId != null) {
            if (routeId.contains("auth")) {
                return "AUTH_ENDPOINT (POST /v1/auth)";
            } else if (routeId.contains("categories")) {
                return "CATEGORIES_ENDPOINT (GET /v2/nodes/{id}/categories)";
            }
            return routeId;
        }
        return "UNKNOWN";
    }
}
