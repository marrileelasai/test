package com.orchestrator.util;

import lombok.extern.slf4j.Slf4j;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.UUID;

/**
 * Utility to build RFC 2388 compliant multipart/form-data payloads.
 * Eliminates duplicate code across processors and routes.
 * 
 * Usage:
 *   MultipartBodyBuilder.Result result = MultipartBodyBuilder.build(jsonPayload, fileBytes, fileName);
 *   exchange.getIn().setBody(result.getBody());
 *   exchange.getIn().setHeader("Content-Type", result.getContentType());
 */
@Slf4j
public class MultipartBodyBuilder {

    /**
     * Build multipart/form-data with JSON body and binary file
     * 
     * @param jsonPayload JSON string for "body" field
     * @param fileBytes Binary file content
     * @param fileName Original filename
     * @return MultipartBodyBuilder.Result with body bytes and Content-Type header
     * @throws IOException if multipart construction fails
     */
    public static Result build(String jsonPayload, byte[] fileBytes, String fileName) throws IOException {
        String boundary = "----WebKitFormBoundary" + UUID.randomUUID().toString().replace("-", "");
        ByteArrayOutputStream multipartBody = new ByteArrayOutputStream();

        // Part 1: body (JSON)
        multipartBody.write(("--" + boundary + "\r\n").getBytes(StandardCharsets.UTF_8));
        multipartBody.write("Content-Disposition: form-data; name=\"body\"\r\n".getBytes(StandardCharsets.UTF_8));
        multipartBody.write("Content-Type: application/json\r\n\r\n".getBytes(StandardCharsets.UTF_8));
        multipartBody.write(jsonPayload.getBytes(StandardCharsets.UTF_8));
        multipartBody.write("\r\n".getBytes(StandardCharsets.UTF_8));

        // Part 2: file (binary)
        multipartBody.write(("--" + boundary + "\r\n").getBytes(StandardCharsets.UTF_8));
        multipartBody.write(("Content-Disposition: form-data; name=\"file\"; filename=\"" + fileName + "\"\r\n").getBytes(StandardCharsets.UTF_8));
        multipartBody.write("Content-Type: application/octet-stream\r\n\r\n".getBytes(StandardCharsets.UTF_8));
        multipartBody.write(fileBytes);
        multipartBody.write("\r\n".getBytes(StandardCharsets.UTF_8));

        // Final boundary
        multipartBody.write(("--" + boundary + "--\r\n").getBytes(StandardCharsets.UTF_8));

        byte[] body = multipartBody.toByteArray();
        String contentType = "multipart/form-data; boundary=" + boundary;

        log.debug("[MULTIPART] Built multipart body: {} bytes, boundary: {}", body.length, boundary);
        
        return new Result(body, contentType);
    }

    /**
     * Build multipart/form-data with JSON body and streamed binary file
     * CRITICAL: Streams file using InputStream - does NOT load entire file to memory
     * 
     * @param jsonPayload JSON string for "body" field
     * @param fileStream InputStream to read file content
     * @param fileName Original filename
     * @param fileSize Size of file in bytes
     * @return MultipartBodyBuilder.Result with body bytes and Content-Type header
     * @throws IOException if multipart construction fails
     */
    public static Result buildStreaming(String jsonPayload, InputStream fileStream, String fileName, long fileSize) throws IOException {
        String boundary = "----WebKitFormBoundary" + UUID.randomUUID().toString().replace("-", "");
        ByteArrayOutputStream multipartBody = new ByteArrayOutputStream();

        // Part 1: body (JSON)
        multipartBody.write(("--" + boundary + "\r\n").getBytes(StandardCharsets.UTF_8));
        multipartBody.write("Content-Disposition: form-data; name=\"body\"\r\n".getBytes(StandardCharsets.UTF_8));
        multipartBody.write("Content-Type: application/json\r\n\r\n".getBytes(StandardCharsets.UTF_8));
        multipartBody.write(jsonPayload.getBytes(StandardCharsets.UTF_8));
        multipartBody.write("\r\n".getBytes(StandardCharsets.UTF_8));

        // Part 2: file (binary) - STREAM from InputStream
        multipartBody.write(("--" + boundary + "\r\n").getBytes(StandardCharsets.UTF_8));
        multipartBody.write(("Content-Disposition: form-data; name=\"file\"; filename=\"" + fileName + "\"\r\n").getBytes(StandardCharsets.UTF_8));
        multipartBody.write("Content-Type: application/octet-stream\r\n\r\n".getBytes(StandardCharsets.UTF_8));
        
        // Stream file content (reads in chunks, ~8KB buffer by default)
        byte[] buffer = new byte[8192];
        int bytesRead;
        long totalRead = 0;
        while ((bytesRead = fileStream.read(buffer)) != -1) {
            multipartBody.write(buffer, 0, bytesRead);
            totalRead += bytesRead;
        }
        
        log.debug("[MULTIPART] Streamed file: {} bytes (expected: {})", totalRead, fileSize);
        
        multipartBody.write("\r\n".getBytes(StandardCharsets.UTF_8));

        // Final boundary
        multipartBody.write(("--" + boundary + "--\r\n").getBytes(StandardCharsets.UTF_8));

        byte[] body = multipartBody.toByteArray();
        String contentType = "multipart/form-data; boundary=" + boundary;

        log.debug("[MULTIPART] Built streaming multipart body: {} bytes, boundary: {}", body.length, boundary);
        
        return new Result(body, contentType);
    }

    /**
     * Result container for multipart build operation
     */
    public static class Result {
        private final byte[] body;
        private final String contentType;

        public Result(byte[] body, String contentType) {
            this.body = body;
            this.contentType = contentType;
        }

        public byte[] getBody() {
            return body;
        }

        public String getContentType() {
            return contentType;
        }
    }
}
