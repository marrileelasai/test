package com.orchestrator.constants;

/**
 * Constants for exchange properties and custom headers.
 * Prevents typos in property/header names across routes.
 */
public class OrchestratorConstants {
    
    // Custom header name for OTCS authentication ticket
    public static final String OTCS_TICKET_HEADER = "OTCSTicket";
    
    // Exchange property names
    public static final String PROP_ESCAPE_EVENT = "escapeEvent";
    public static final String PROP_OTCS_TICKET = "otcsTicket";
    public static final String PROP_CATEGORY_MAPPING = "categoryMapping";
    public static final String PROP_WORKSPACE_PAYLOAD = "workspacePayload";
    
    private OrchestratorConstants() {
        // Utility class - prevent instantiation
    }
}
