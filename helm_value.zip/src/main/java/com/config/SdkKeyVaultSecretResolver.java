package com.config;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import lombok.extern.slf4j.Slf4j;

import com.azure.core.credential.TokenCredential;
import com.azure.core.http.HttpClient;
import com.azure.core.http.netty.NettyAsyncHttpClientBuilder;
import com.azure.identity.DefaultAzureCredentialBuilder;
import com.azure.identity.InteractiveBrowserCredentialBuilder;
import com.azure.security.keyvault.secrets.SecretClient;
import com.azure.security.keyvault.secrets.SecretClientBuilder;
import com.azure.security.keyvault.secrets.models.KeyVaultSecret;

/**
 * Azure SDK + Netty-backed resolver for ${az_kv:secret[#version]} tokens.
 *
 * How it works:
 *  - Intercepts property values during Config Data load (via ResolvingEnumerablePropertySource).
 *  - Replaces ONLY tokens that match ${az_kv:...} BEFORE Spring's own ${...} resolution runs.
 *  - Does NOT scan/loop over all properties; resolves lazily per key lookup.
 *
 * Auth policy:
 *  - In Kubernetes (e.g., AKS): DefaultAzureCredential (platform-injected identity: MI/UAMI or Workload Identity).
 *  - Outside Kubernetes (dev local): InteractiveBrowserCredential (opens browser once).
 *  - Optional override: -Daz.kv.auth-mode=default|interactive
 *
 * Transport:
 *  - Netty (azure-core-http-netty) to align with Spring/Camel stacks; no Spring HTTP is used.
 *
 * Required BEFORE YAML load:
 *  - Vault URL via env AZURE_KEYVAULT_URI or system property az.kv.vault-url
 *
 * Behavior:
 *  - failFast=true (default) throws on missing vault/secret/auth failures.
 *  - failFast=false resolves unknown tokens to empty string "".
 *
 * Example application.yml:
 *  spring:
 *    datasource:
 *      url: jdbc:postgresql://mydb:5432/app
 *      username: ${az_kv:db-user}
 *      password: ${az_kv:db-password}
 *
 *  # Inline/mixed strings with multiple tokens also work:
 *  kafka:
 *    sasl:
 *      jaas:
 *        config: "org.apache.kafka.common.security.plain.PlainLoginModule required username='${az_kv:kafka-user}' password='${az_kv:kafka-pass}';"
 */
@Slf4j
public class SdkKeyVaultSecretResolver {

    // Regex that supports both short and inline-vault forms
    private static final Pattern KV_PLACEHOLDER = Pattern.compile(
            "\\$\\{az_kv(?:\\(vault=([^}]+)\\))?:" +   // group(1): optional inline vault URL
                    "([a-zA-Z0-9._\\-/]+)" +                  // group(2): secret name
                    "(?:#([a-zA-Z0-9\\-]+))?}"                // group(3): optional version
    );

    // Default vault (only used when you use the short form ${az_kv:secret})
    private static final String ENV_VAULT_URI = "AZURE_KEYVAULT_URI";
    private static final String SYS_VAULT_URI = "az.kv.vault-url";

    private final boolean failFast;
    private final SecretClient defaultClient; // may be null

    // Shared across all clients
    private final TokenCredential sharedCredential;
    private final HttpClient nettyClient;


    // Cache SecretClient per vault URL (for inline-vault form)
    private final Map<String, SecretClient> clientsByVault = new ConcurrentHashMap<>();

    // Cache resolved values (keyed by "<vaultUrl>|<secretName>[#version]")
    private final Map<String, String> cache = new ConcurrentHashMap<>();

    public SdkKeyVaultSecretResolver(boolean failFast) {
        this.failFast = failFast;

        // Build one credential and one HTTP client, reused everywhere
        this.sharedCredential = chooseCredential();
        this.nettyClient = new NettyAsyncHttpClientBuilder().build();

        // Build default client if default vault is configured (enables ${az_kv:secret})
        String defaultVaultUrl = firstNonBlank(System.getenv(ENV_VAULT_URI), System.getProperty(SYS_VAULT_URI));
        if (hasText(defaultVaultUrl)) {
            this.defaultClient = new SecretClientBuilder()
                    .vaultUrl(defaultVaultUrl)
                    .credential(sharedCredential)
                    .httpClient(nettyClient)
                    .buildClient();
        } else {
            this.defaultClient = null; // fine if you always use inline-vault placeholders
        }
    }


private String resolvePlaceholders(String input) {
        if (input == null) return null;
        // Simple placeholder resolution for ${...}
        Pattern doubleBracePattern = Pattern.compile("\\$\\{\\{([^}]+)}}");
        Matcher m = doubleBracePattern.matcher(input);
        StringBuffer sb = new StringBuffer();
        while (m.find()) {
            String key = m.group(1);
            String value = System.getProperty(key, System.getenv(key));
            m.appendReplacement(sb, value != null ? Matcher.quoteReplacement(value) : "");
        }
        m.appendTail(sb);
        return sb.toString();
    }

    /** Resolve Key Vault tokens in the provided value. */
    public Object resolve(Object value) {
        if (!(value instanceof String s)) return value;
        System.out.println("value -->"+ value);
       //log.debug("value -->"+ value);

        // First resolve nested placeholders like ${vault.url}
        String resolved = resolvePlaceholders(s);

        Matcher m = KV_PLACEHOLDER.matcher(resolved);

        //Matcher m = KV_PLACEHOLDER.matcher(s);
        if (!m.find()) return value; // nothing to do

        StringBuffer out = new StringBuffer();
        do {
            String inlineVault = m.group(1);  // may be null (when using ${az_kv:secret})
            String secretName  = m.group(2);
            String version     = m.group(3);

            if (!hasText(secretName)) {
                if (failFast) {
                    throw new IllegalArgumentException("Secret name missing in placeholder: " + m.group(0));
                }
                m.appendReplacement(out, "");
                continue;
            }

            String cacheKey = (inlineVault == null ? "" : inlineVault) + "|" + secretName
                    + (version == null ? "" : "#" + version);

            // FIX: call the 3-arg fetch(...) that accepts inlineVault
            String secretVal = cache.computeIfAbsent(cacheKey,
                    k -> fetch(inlineVault, secretName, version));

            String replacement = (secretVal == null) ? "" : Matcher.quoteReplacement(secretVal);
            m.appendReplacement(out, replacement);
        } while (m.find());
        m.appendTail(out);

        return out.toString();
    }

    // ---------- Authentication selection ----------

    private TokenCredential chooseCredential() {
        String override = System.getProperty("az.kv.auth-mode", "").trim().toLowerCase();
        if ("interactive".equals(override)) {
            System.out.println("[AzKV] Using InteractiveBrowserCredential");
            log.debug("[AzKV] Using InteractiveBrowserCredential");
            return new InteractiveBrowserCredentialBuilder()
                    .redirectUrl("http://localhost:8400")
                    .build();
        }
        if ("default".equals(override)) {
            System.out.println("[AzKV] Using DefaultAzureCredential");
            log.debug("[AzKV] Using DefaultAzureCredential");
            return new DefaultAzureCredentialBuilder().build();
        }

        // Heuristic: in Kubernetes use DefaultAzureCredential; otherwise interactive for local dev
        if (isKubernetes()) {
            return new DefaultAzureCredentialBuilder().build();
        }
        return new InteractiveBrowserCredentialBuilder()
                .redirectUrl("http://localhost:8400")
                .build();
    }

    private boolean isKubernetes() {
        return hasText(System.getenv("KUBERNETES_SERVICE_HOST"));
    }

    // ---------- Secret fetch (supports default or inline vault) ----------

    private String fetch(String inlineVaultUrl, String name, String version) {
        // Choose client: inline vault (preferred if provided) else default vault
        SecretClient client = (hasText(inlineVaultUrl))
                ? clientsByVault.computeIfAbsent(inlineVaultUrl, url ->
                new SecretClientBuilder()
                        .vaultUrl(url)
                        .credential(this.sharedCredential)
                        .httpClient(this.nettyClient)
                        .buildClient())
                : this.defaultClient;

        if (client == null) {
            if (failFast) {
                throw new IllegalStateException(
                        "No Key Vault configured. Provide inline vault like ${az_kv(vault=https://<kv>.vault.azure.net/):"
                                + name + "} or set AZURE_KEYVAULT_URI / -Daz.kv.vault-url for ${az_kv:" + name + "}.");
            }
            return null;
        }

        try {
            KeyVaultSecret secret = (version == null)
                    ? client.getSecret(name)
                    : client.getSecret(name, version);

            // FOR TESTING ONLY – you asked to print values
            System.out.println("read from key vault:" + name + ": " + secret.getValue());
           // log.debug("read from key vault:" + name + ": " + secret.getValue());

            return secret.getValue();
        } catch (Exception e) {
            if (failFast) {
                throw new IllegalStateException("Failed to resolve Key Vault secret '" + name +
                        (version != null ? "#" + version : "") +
                        "' from " + (hasText(inlineVaultUrl) ? inlineVaultUrl : client.getVaultUrl()), e);
            }
            return null;
        }
    }

    // ---------- utils ----------

    private static boolean hasText(String s) {
        return s != null && !s.isBlank();
    }

    private static String firstNonBlank(String a, String b) {
        return hasText(a) ? a : (hasText(b) ? b : null);
    }
}