package com.config;


import org.springframework.core.env.EnumerablePropertySource;

import java.util.Objects;

/**
 * Decorates an existing EnumerablePropertySource and performs on-demand resolution
 * of values containing {{az_kv:...}} tokens via the provided resolver.
 *
 * - No scanning/looping: resolution happens only when a property is requested.
 * - Preserves origin metadata by using the delegate as the "source".
 */
public class ResolvingEnumerablePropertySource extends EnumerablePropertySource<Object> {

    private final EnumerablePropertySource<?> delegate;
    private final SdkKeyVaultSecretResolver resolver;

    public ResolvingEnumerablePropertySource(String name,
                                             EnumerablePropertySource<?> delegate,
                                             SdkKeyVaultSecretResolver resolver) {
        super(name, delegate); // keep origin info
        this.delegate = Objects.requireNonNull(delegate, "delegate");
        this.resolver = Objects.requireNonNull(resolver, "resolver");
    }

    @Override
    public Object getProperty(String name) {
        Object raw = delegate.getProperty(name);
        return resolver.resolve(raw);
    }

    @Override
    public String[] getPropertyNames() {
        return delegate.getPropertyNames();
    }
}
