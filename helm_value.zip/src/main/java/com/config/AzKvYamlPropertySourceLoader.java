package com.config;

import org.springframework.boot.env.PropertySourceLoader;
import org.springframework.boot.env.YamlPropertySourceLoader;
import org.springframework.core.Ordered;
import org.springframework.core.env.EnumerablePropertySource;
import org.springframework.core.env.PropertySource;
import org.springframework.core.io.Resource;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * KeyVault-aware YAML PropertySourceLoader that participates in Spring Boot's Config Data phase.
 *
 * - Delegates YAML parsing to Spring's YamlPropertySourceLoader (keeps profile/origin behavior).
 * - Wraps resulting PropertySources with a lazy resolver for ${az_kv:...} tokens.
 * - No scanning/looping; values are resolved only when a specific property is accessed.
 * - Runs before Spring/Camel context initialization.
 *
 * Notes:
 * - Uses a Netty-backed Azure SDK resolver (SdkKeyVaultSecretResolver) provided in a separate file.
 * - Requires a lazy wrapper (ResolvingEnumerablePropertySource) provided in a separate file.
 */
public class AzKvYamlPropertySourceLoader implements PropertySourceLoader, Ordered {

    private final YamlPropertySourceLoader yamlDelegate = new YamlPropertySourceLoader();

    // Fail-fast default can be overridden with -Daz.kv.fail-fast=false
    private final SdkKeyVaultSecretResolver resolver =
            new SdkKeyVaultSecretResolver(Boolean.parseBoolean(System.getProperty("az.kv.fail-fast", "true")));

    @Override
    public String[] getFileExtensions() {
        return new String[] { "yml", "yaml" };
    }

    @Override
    public List<PropertySource<?>> load(String name, Resource resource) throws IOException {
        List<PropertySource<?>> originals = yamlDelegate.load(name, resource);
        List<PropertySource<?>> decorated = new ArrayList<>(originals.size());

        for (PropertySource<?> ps : originals) {
            if (ps instanceof EnumerablePropertySource<?> enumerable) {
                decorated.add(new ResolvingEnumerablePropertySource(ps.getName(), enumerable, resolver));
            } else {
                decorated.add(ps); // passthrough (rare)
            }
        }
        return decorated;
    }

    @Override
    public int getOrder() {
        // Highest precedence so this loader is chosen for yml/yaml
        return Ordered.HIGHEST_PRECEDENCE;
    }
}