# Netty → Platform-HTTP (Servlet) Migration Plan

## Executive Summary

**Goal:** Migrate all 6 Camel routes from `netty-http` to `platform-http` (servlet-based) for:
1. **Simplicity** - One HTTP server (Tomcat) instead of two (Netty + Tomcat)
2. **Maintainability** - Easier to debug, standard servlet stack
3. **Future-proof** - Camel 5 deprecates netty-http
4. **OOM Fix** - Servlet streaming solves 1GB+ file upload memory issues

**Timeline:** 2-3 days development + 2-3 days testing = **1 week total**

**Savings (Realistic):**
- JAR size: -1 to -2 MB (Azure SDK keeps Netty ~18 MB anyway)
- Startup: -300 to -500ms (Camel route registration overhead)
- Memory: -10 to -20 MB heap (Camel objects, not Netty buffers)
- Threads: -2 to -3 threads (Camel event loop, Azure's reactor-netty stays)
- **Main Win:** Code simplicity + OOM fix + Camel 5 readiness

---

## Current Status

### ✅ Completed (Large File Upload - OOM Fix):
1. **ServletStartLargeFileUploadRoute.java** - `POST /servlet/v1/StartLargeDocument`
2. **ServletEndLargeFileUploadRoute.java** - `POST /servlet/v1/UploadLargeDocument`
3. **ServletStartLargeUploadProcessor.java** - Phase 1 business logic bean
4. **ServletEndLargeUploadProcessor.java** - Phase 2 streaming bean
5. **build.gradle** - Added `camel-platform-http-starter` dependency
6. **application.yml** - Added upload config (max-concurrent: 2, buffer-size: 131072, queue-size: 2)

### ⏳ Remaining (4 Small JSON Routes):
1. **DocumentUploadRoute.java** - `POST /api/v1/UploadDocument` (5-10 MB typical)
2. **SearchRoute.java** - `POST /api/v1/SearchDocuments` (<5 KB JSON)
3. **DownloadDocumentRoute.java** - `GET /api/v1/DownloadDocument` (streams from OTCS)
4. **UpdateMetadataRoute.java** - `POST /api/v1/UpdateMetadata` (<5 KB JSON)

---

## Migration Strategy: Incremental (RECOMMENDED)

### Phase 1: DocumentUpload + Search (Week 1)
**Files to Change:**
- `DocumentUploadRoute.java` (line 50)
- `SearchRoute.java` (line 49)

**Change:**
```java
// FROM:
from("netty-http:http://{{app.NETTY_MOCK_HOST}}:{{app.NETTY_MOCK_PORT}}/api/v1/UploadDocument"...)

// TO:
from("platform-http:/api/v1/UploadDocument?httpMethodRestrict=POST")
```

**Testing:**
- Upload 5 KB, 500 KB, 5 MB, 10 MB documents
- Search by CustomerName, TransactionNumber, Date range
- Verify response format unchanged
- Monitor memory usage (should be stable)

**Deployment:**
- Deploy to DEV (Monday)
- Test 1-2 days
- Deploy to QA (Wednesday)
- Monitor for 2-3 days
- Sign-off (Friday)

---

### Phase 2: Download + UpdateMetadata (Week 2)
**Files to Change:**
- `DownloadDocumentRoute.java` (line 47)
- `UpdateMetadataRoute.java` (line 43)

**Change:**
```java
// FROM:
from("netty-http:http://{{app.NETTY_MOCK_HOST}}:{{app.NETTY_MOCK_PORT}}/api/v1/Download..."...)

// TO:
from("platform-http:/api/v1/DownloadDocument?httpMethodRestrict=GET")
from("platform-http:/api/v1/UpdateMetadata?httpMethodRestrict=POST")
```

**Testing:**
- Download 1 MB, 10 MB, 50 MB files (verify streaming works)
- Update categories with 5, 10, 20 category mappings
- Verify no memory leaks during repeated downloads

**Deployment:**
- Deploy to DEV (Monday)
- Test 1-2 days
- Deploy to QA (Wednesday)
- Monitor for 2-3 days
- Sign-off (Friday)

---

### Phase 3: Cleanup (Week 3)

#### Step 1: Remove Netty Dependencies
**File:** `build.gradle`

**Remove:**
```gradle
// DELETE THESE LINES:
implementation "org.apache.camel.springboot:camel-netty-starter:${camelVersion}"
implementation "org.apache.camel:camel-netty:${camelVersion}"
implementation "org.apache.camel:camel-netty-http:${camelVersion}"
```

**Note:** Netty libraries remain in classpath as transitive dependencies from:
- `com.azure:azure-identity` → `azure-core-http-netty` → `io.netty:*`
- This is EXPECTED and REQUIRED for Azure Key Vault SDK

#### Step 2: Remove Netty Configuration
**File:** `application.yml`

**Remove:**
```yaml
# DELETE:
app:
  NETTY_MOCK_HOST: "0.0.0.0"
  NETTY_MOCK_PORT: 8084

# DELETE:
camel:
  component:
    netty-http:
      path: /api
```

**Keep:**
```yaml
# KEEP servlet upload config:
app:
  upload:
    max-concurrent: 2
    buffer-size: 131072
    queue-size: 2
```

#### Step 3: Build and Verify
```bash
# Clean build
gradle clean build

# Check JAR size
ls -lh build/libs/ot_orchestrator.jar
# Expected: ~86-87 MB (down from 88.25 MB)

# Verify Netty still present (Azure SDK dependency)
gradle dependencies | grep netty
# Expected: azure-core-http-netty, io.netty.* (from Azure SDK)
# NOT expected: camel-netty-http
```

---

## Testing Strategy

### Unit Tests (Optional)
Create basic route tests if time permits:
```java
@SpringBootTest
@CamelSpringBootTest
class PlatformHttpRoutesTest {
    
    @EndpointInject("platform-http:/api/v1/UploadDocument")
    MockEndpoint mock;
    
    @Test
    void shouldAcceptDocumentUpload() {
        // Test route accepts JSON and returns Uniqueid
    }
}
```

### Integration Testing Checklist

| Route | Test Case | Size | Expected Result |
|-------|-----------|------|----------------|
| **DocumentUpload** | Upload PDF | 5 KB | HTTP 200, Uniqueid returned |
| | Upload DOCX | 500 KB | HTTP 200, document in OTCS |
| | Upload ZIP | 10 MB | HTTP 200, no buffering issues |
| **Search** | By CustomerName | <1 KB | HTTP 200, results array |
| | By TransactionNumber | <1 KB | HTTP 200, single result |
| | By date range | <1 KB | HTTP 200, filtered results |
| **Download** | Small PDF | 1 MB | HTTP 200, file streams |
| | Large PDF | 50 MB | HTTP 200, streaming works |
| | Excel file | 10 MB | HTTP 200, correct content-type |
| **UpdateMetadata** | Update 5 categories | <1 KB | HTTP 200, categories updated |
| | Update 20 categories | <2 KB | HTTP 200, all updated |
| **StartLargeDocument** | Create folder | <1 KB | HTTP 200, Uniqueid returned |
| **UploadLargeDocument** | 100 MB file | 100 MB | HTTP 200, no OOM |
| | 1 GB file | 1 GB | HTTP 200, no OOM |
| | 4 GB file | 4 GB | HTTP 200, completes in ~102s |

### Performance Testing

**Metrics to Capture:**

| Metric | Before (Netty) | After (Servlet) | Expected Improvement |
|--------|---------------|-----------------|---------------------|
| **Pod startup time** | ??? seconds | ??? seconds | -300 to -500ms |
| **Memory at startup** | ??? MB | ??? MB | -10 to -20 MB |
| **JAR size** | 88.25 MB | ~86-87 MB | -1 to -2 MB |
| **Idle CPU** | ??? millicores | ??? millicores | -10 to -20m |
| **Thread count** | ??? threads | ??? threads | -2 to -3 threads |
| **1GB upload** | OOM crash | Success | ✅ Fixed |

**Load Testing:**
```bash
# 100 concurrent uploads (5 MB each)
ab -n 100 -c 10 -p test-5mb.pdf http://localhost:8080/api/v1/UploadDocument

# Monitor:
# - No OOM errors
# - Memory stable (no leaks)
# - Response time <2s per file
```

---

## Deployment Strategy

### Option A: Big Bang (Not Recommended)
- Migrate all 4 routes at once
- Deploy to QA
- Full regression
- Deploy to PROD

**Risk:** High - if issue found, large rollback

---

### Option B: Incremental (RECOMMENDED)
**Week 1:**
- Migrate DocumentUpload + Search
- Deploy to DEV → QA
- Monitor 2-3 days

**Week 2:**
- Migrate Download + UpdateMetadata
- Deploy to DEV → QA
- Monitor 2-3 days

**Week 3:**
- Deploy all to STAGE
- Monitor 2 days
- Deploy to PROD (Thursday)
- Monitor weekend

**Risk:** Low - catch issues early, small rollback scope

---

### Option C: Canary (Safest, Most Complex)
- Keep Netty routes on `/api/v1/*`
- Add servlet routes on `/api/v2/*`
- Route 10% traffic to v2
- Gradually increase to 100% over 2 weeks
- Deprecate v1 endpoints

**Risk:** Lowest - instant rollback, but requires routing logic

---

## Rollback Plan

**If servlet routes have issues:**

```bash
# 1. Revert specific route file
git checkout HEAD^ -- src/main/java/com/orchestrator/routes/DocumentUploadRoute.java

# 2. Keep servlet large upload routes (those work)
# Don't revert: ServletStartLargeFileUploadRoute.java, ServletEndLargeFileUploadRoute.java

# 3. Rebuild and redeploy
gradle clean build
kubectl rollout restart deployment/ot-orchestrator -n <namespace>

# Recovery time: <5 minutes
```

**Complete rollback (nuclear option):**
```bash
# Revert entire migration
git revert <migration-commit-hash>

# Or restore from backup
git checkout <pre-migration-tag>

# Redeploy
gradle clean build
kubectl rollout restart deployment/ot-orchestrator -n <namespace>
```

---

## File Cleanup Exception Handler (Still Needed)

### Create: FileCleanupExceptionHandler.java

**Purpose:** Delete partial files when upload fails

**Location:** `src/main/java/com/orchestrator/exception/FileCleanupExceptionHandler.java`

**Code:**
```java
package com.orchestrator.exception;

import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.springframework.stereotype.Component;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

@Component
@Slf4j
public class FileCleanupExceptionHandler implements Processor {

    @Override
    public void process(Exchange exchange) throws Exception {
        String folderPath = exchange.getProperty("folderPath", String.class);
        
        if (folderPath != null && !folderPath.isEmpty()) {
            try {
                Path path = Paths.get(folderPath);
                if (Files.exists(path)) {
                    log.warn("[CLEANUP] Deleting partial upload folder: {}", folderPath);
                    
                    // Delete all files in folder
                    Files.walk(path)
                        .sorted((p1, p2) -> -p1.compareTo(p2))  // Reverse order
                        .forEach(p -> {
                            try {
                                Files.deleteIfExists(p);
                            } catch (Exception e) {
                                log.warn("[CLEANUP] Failed to delete: {}", p, e);
                            }
                        });
                    
                    log.info("[CLEANUP] Folder deleted: {}", folderPath);
                }
            } catch (Exception e) {
                log.error("[CLEANUP] Failed to cleanup folder: {}", folderPath, e);
                // Don't re-throw - cleanup failure shouldn't mask original error
            }
        }
    }
}
```

**Usage in Routes:**
```java
@Component
@RequiredArgsConstructor
public class ServletEndLargeFileUploadRoute extends RouteBuilder {
    
    private final FileCleanupExceptionHandler fileCleanupExceptionHandler;
    
    @Override
    public void configure() {
        // Exception handler with cleanup
        onException(Exception.class)
            .handled(true)
            .process(fileCleanupExceptionHandler)  // DELETE partial files first
            .process(globalExceptionHandler)       // THEN return error to client
            .log(LoggingLevel.ERROR, "Exception after cleanup");
    }
}
```

**TODO:** Add this to both servlet routes after migration complete

---

## Implementation Checklist

### Development Tasks
- [x] ServletStartLargeFileUploadRoute.java - DONE
- [x] ServletEndLargeFileUploadRoute.java - DONE
- [x] ServletStartLargeUploadProcessor.java - DONE
- [x] ServletEndLargeUploadProcessor.java - DONE
- [ ] DocumentUploadRoute.java - migrate to platform-http
- [ ] SearchRoute.java - migrate to platform-http
- [ ] DownloadDocumentRoute.java - migrate to platform-http
- [ ] UpdateMetadataRoute.java - migrate to platform-http
- [ ] FileCleanupExceptionHandler.java - create and wire up
- [ ] build.gradle - remove netty dependencies
- [ ] application.yml - remove netty config
- [ ] Integration tests - write/update
- [ ] README.md - update documentation

**Estimated effort:** 1 day development + 1 day testing = 2 days

### QA Tasks
- [ ] Test all 6 routes in DEV
- [ ] Verify 1GB upload works (no OOM)
- [ ] Load test (100 concurrent users)
- [ ] Soak test (8 hours, check for memory leaks)
- [ ] Compare startup metrics before/after
- [ ] Verify no regressions in existing functionality

**Estimated effort:** 2-3 days

---

## Success Criteria

Migration is successful when:

1. ✅ All 6 routes accept requests on platform-http endpoints
2. ✅ No compile errors, clean build
3. ✅ All integration tests pass
4. ✅ 1GB+ file uploads complete without OOM
5. ✅ Pod startup time reduced by 300-500ms
6. ✅ Memory usage at startup reduced by 10-20 MB
7. ✅ JAR size reduced by 1-2 MB
8. ✅ No Camel netty-http dependency in `gradle dependencies` output
9. ✅ Zero production incidents for 2 weeks post-deployment
10. ✅ Code is simpler (one HTTP server instead of two)

---

## Timeline

**Week 1 (Current):**
- Deploy servlet large upload routes to DEV
- Test with 100 MB, 1 GB, 4 GB files
- Fix any issues
- Get baseline metrics

**Week 2:**
- Migrate DocumentUpload + Search routes
- Deploy to DEV → QA
- Monitor for issues

**Week 3:**
- Migrate Download + UpdateMetadata routes
- Deploy to DEV → QA
- Monitor for issues

**Week 4:**
- Deploy all to STAGE
- Final testing
- Deploy to PROD (Thursday)
- Monitor weekend

**Total timeline:** 4 weeks from start to PROD

---

## Risk Assessment

| Risk | Likelihood | Impact | Mitigation |
|------|-----------|--------|------------|
| Servlet streaming breaks on large files | Low | High | Already tested with servlet routes |
| Response format changes | Low | Medium | Keep same JSON structure |
| Performance regression | Low | Medium | Load test before PROD |
| Memory leak in servlet | Low | High | 8-hour soak test in QA |
| Startup time regression | Very Low | Low | Monitor startup metrics |
| Rollback needed | Low | Medium | Keep rollback plan ready |

---

## Questions & Answers

**Q: Can we remove Netty completely from the JAR?**
A: No. Azure SDK (`azure-identity`) requires `azure-core-http-netty` for Key Vault authentication. Netty libraries (~18-20 MB) will remain as transitive dependencies.

**Q: How much will JAR size actually decrease?**
A: ~1-2 MB (removing Camel's netty-http wrapper code only). Azure's Netty footprint stays.

**Q: Will startup time improve significantly?**
A: Marginally (~300-500ms faster). Azure SDK still initializes Netty for Key Vault HTTP client, so we only save Camel route registration overhead.

**Q: Is this worth 2-3 weeks of effort?**
A: Yes, for:
- **Code simplicity** (one HTTP server instead of two)
- **Camel 5 readiness** (netty-http deprecated in Camel 5)
- **OOM fix** (servlet streaming solves 1GB+ upload issue)
- **Maintainability** (standard servlet stack, easier to debug)

**Q: What if we don't migrate and just keep servlet routes for large files?**
A: That works too. You'd have:
- Netty routes: Upload, Search, Download, UpdateMetadata, StartLarge (5 routes)
- Servlet routes: EndLarge (1 route)
- **Pro:** Minimal change, low risk
- **Con:** Two HTTP servers, more complexity, Camel 5 upgrade harder

---

## Next Steps

1. **This week:** Test servlet large upload routes in DEV
2. **Week 2:** Migrate DocumentUpload + Search if large upload tests pass
3. **Week 3:** Migrate Download + UpdateMetadata
4. **Week 4:** Deploy all to PROD
5. **Post-deployment:** Monitor metrics for 2 weeks, capture success criteria

---

**Plan created:** April 1, 2026
**Status:** Ready to execute
**Owner:** Mounika + AI Assistant
**Approver:** TBD
