# Servlet Large File Upload - Lessons Learned & Corrections

## Project Context
- **Project:** AKS-OrchestrationAPI (Spring Boot 3.4.1 + Camel 4.14.4)
- **Problem:** Netty HTTP buffering causes OOM on 1GB+ file uploads
- **Solution:** Parallel servlet-based implementation using platform-http
- **Date:** April 1, 2026

---

## Key Corrections & Decisions

### 1. **Platform-HTTP IS Servlet (Not a Separate Thing)**
**Correction:** Platform-HTTP is just Camel's DSL wrapper around Spring Boot's embedded Tomcat servlet container.

```
camel-platform-http → Spring Boot Tomcat → Servlet API → True streaming
```

**Not:** A new HTTP server or different technology.

---

### 2. **Buffer Size Matters for Network Speed**
**Initial mistake:** Suggested 8KB buffer (Java default for Files.copy)

**Correction:** 
- 8KB buffer = 25 MB/s throughput (CPU bottleneck from syscall overhead)
- 128KB buffer = Good for 500m CPU (Config A)
- 256KB buffer = Good for 1000m CPU (Config B)
- 1MB buffer = Only for very high CPU (not needed for Config A/B)

**Decision:** Use **128KB for Config A**, scalable to 256KB for Config B.

---

### 3. **Queue Size Must Account for Timeout Chain**
**Initial mistake:** Suggested queue capacity of 10

**Correction:**
```
Timeout chain:
- NGINX ingress: 60s
- APIM: 30-60s
- WAF: 30s
- Palo Alto: 30s

Queue of 10 with 102s per upload (4GB, Config A):
- 10th request waits 17 minutes → Times out at EVERY layer
```

**Decision:** **Queue size = 2 max** (realistic for timeout constraints)

---

### 4. **Use Camel's Thread Pool, Not Spring Bean**
**Initial mistake:** Created separate Spring `@Bean` for ExecutorService

**Correction:** Camel has native thread pool via `threads()` DSL:
```java
from("platform-http:/endpoint")
    .threads()
        .poolSize(2)
        .maxQueueSize(2)
        .rejectedPolicy(ThreadPoolRejectedPolicy.Abort)
    .process(...);
```

**Benefits:**
- ✅ Camel-native (visible in metrics)
- ✅ Configured in route (clear intent)
- ✅ HTTP 503 on rejection (immediate feedback)

**Decision:** Use Camel `threads()` DSL, not external Spring beans.

---

### 5. **No .tmp Files (Direct Write with Overwrite)**
**Initial suggestion:** Write to `.tmp` file, then atomic rename

**User's correction:** "We're not launching rockets" - simple overwrite is fine

**Decision:** 
```java
Files.copy(stream, finalPath, StandardCopyOption.REPLACE_EXISTING);
```

**Rationale:**
- Isolated folders per UploadKey (no concurrent access)
- Overwrite on retry (simple, works)
- Exception handler deletes partial files
- No need for atomic rename complexity

---

### 6. **CPU is the Bottleneck, Not Network**
**Reality check:**
```
Network: 1 Gbps = 125 MB/s (available)
Disk: NVMe 500 MB/s (available)
CPU: 250 millicore = 30 MB/s (BOTTLENECK)
```

**With Config A (500m CPU):**
- Single upload: 40 MB/s
- 4GB file: 102 seconds (not 40 seconds from network speed)

**Decision:** Don't over-optimize network buffering when CPU is the limit.

---

### 7. **Disk Spooling Doesn't Scale with High Concurrency**
**User's challenge:** "Atomic using .tmp with disk spooling is disaster with concurrency"

**Acknowledgment:** At 50+ concurrent uploads:
- Disk becomes bottleneck (filesystem lock contention)
- Random I/O thrashing
- Memory pressure from page cache

**Decision:** 
- Config A: 2 concurrent (disk handles this fine)
- Config B: 5 concurrent (still manageable)
- Config C: 8 concurrent (pushing limits, but within Config C's higher memory budget)

---

## Configuration Summary

### **Config A (Conservative - Deployed Initially)**
```yaml
resources:
  cpu: 500m
  memory: 2Gi

jvm: -Xms1536m -Xmx1536m -XX:MaxDirectMemorySize=256m

app.upload:
  max-concurrent: 2
  buffer-size: 131072  # 128KB
  queue-size: 2
```

**Performance:**
- 40 MB/s per upload
- 4GB file: 102 seconds
- 2 concurrent uploads max

---

### **Config B (Balanced - Upgrade Path)**
```yaml
resources:
  cpu: 1000m
  memory: 4Gi

jvm: -Xms3072m -Xmx3072m -XX:MaxDirectMemorySize=512m

app.upload:
  max-concurrent: 5
  buffer-size: 262144  # 256KB
  queue-size: 2
```

**Performance:**
- 80 MB/s per upload
- 4GB file: 51 seconds
- 5 concurrent uploads max

---

### **Config C (High Concurrency - If Needed)**
```yaml
resources:
  cpu: 1000m
  memory: 4Gi

jvm: -Xms2048m -Xmx2048m -XX:MaxDirectMemorySize=1536m

app.upload:
  max-concurrent: 8
  buffer-size: 524288  # 512KB
  queue-size: 2
```

**Performance:**
- 50 MB/s per upload (CPU spread thin)
- 4GB file: 82 seconds
- 8 concurrent uploads max

---

## Architecture Decisions

### **Parallel Implementation (Not Replacement)**
- **Netty endpoints:** `/uploadapi/v1/*` (unchanged, existing clients)
- **Servlet endpoints:** `/servlet/v1/*` (new, for large files)
- **No disruption:** Both coexist indefinitely

### **File Cleanup Strategy**
- Exception handler deletes partial files on failure
- Simple overwrite on retry (no .tmp complexity)
- Trust Kubernetes to clean orphaned folders on pod restart

### **Schema Reuse**
- Servlet endpoints use same schemas as Netty
- `start-large-upload-schema.json` for StartLargeDocument
- No validation for EndLargeDocument (raw binary stream)

---

## Key Takeaways for Future AI Context

1. **Always question buffer size suggestions** - Check actual CPU capacity first
2. **Queue size must account for timeout chain** - Not just theoretical capacity
3. **Prefer Camel-native patterns** - Don't create external Spring beans unnecessarily
4. **Disk spooling is acceptable at low concurrency** - But doesn't scale to 50+
5. **User knows their infrastructure** - Listen when they challenge assumptions (APIM, WAF, Palo Alto timeouts)
6. **Simple solutions over clever ones** - Direct overwrite beats atomic rename when isolation exists
7. **CPU is often the bottleneck** - Not network, not disk, especially with 250-500 millicore pods

---

## File Structure Created

```
src/main/java/com/orchestrator/
├── routes/
│   ├── servlet/
│   │   ├── ServletStartLargeFileUploadRoute.java  (Phase 1 - metadata)
│   │   └── ServletEndLargeFileUploadRoute.java    (Phase 2 - file upload, PENDING)
│   └── [netty routes unchanged]
│
├── exception/
│   └── FileCleanupExceptionHandler.java           (Auto-delete partial files, PENDING)
│
└── config/
    └── [No UploadExecutorConfig - using Camel threads() DSL instead]

src/main/resources/
└── application.yml                                 (Added upload config)

build.gradle                                        (Added platform-http dependency)
```

---

## Testing Checklist (Future Validation)

- [ ] 100MB file upload (Config A)
- [ ] 1GB file upload (Config A)
- [ ] 4GB file upload (Config A)
- [ ] Network drop during upload (file deleted?)
- [ ] Pod killed during upload (orphaned file cleanup?)
- [ ] 2 concurrent uploads (both succeed?)
- [ ] 3 concurrent uploads (queued, then processed?)
- [ ] 4+ concurrent uploads (HTTP 503 rejection?)
- [ ] Upgrade to Config B (5 concurrent works?)

---

**Last Updated:** April 1, 2026 during conversation about servlet-based large file upload implementation.
