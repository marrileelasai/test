package com.orchestrator.processor;

import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;

/**
 * Processor bean for ServletEndLargeFileUploadRoute.
 * Handles file streaming with configurable buffer size.
 * 
 * Design decisions:
 * - Direct write to final path (no .tmp files for simplicity)
 * - 128KB buffer optimized for 500m CPU (Config A)
 * - Read metadata.json from disk (10ms acceptable)
 */
@Component
@Slf4j
public class ServletEndLargeUploadProcessor {

    @Value("${app.FILE_UPLOAD_PATH:/mnt/sftp-volume}")
    private String uploadPath;

    @Value("${app.upload.buffer-size:131072}")
    private int bufferSize;

    /**
     * Stream file upload to disk.
     * 
     * @param uploadKey Unique identifier (transactionNumber_timestamp)
     * @param inputStream File content stream from servlet
     * @return Result with uniqueId and bytes written
     * @throws Exception on I/O errors
     */
    public EndLargeUploadResult processUpload(String uploadKey, InputStream inputStream) throws Exception {
        
        // Step 1: Read metadata.json to get fileName
        Path folderPath = Paths.get(uploadPath, uploadKey);
        Path metadataPath = folderPath.resolve("metadata.json");
        
        if (!Files.exists(metadataPath)) {
            throw new IllegalArgumentException("UploadKey not found: " + uploadKey);
        }
        
        String metadataJson = Files.readString(metadataPath);
        DocumentContext json = JsonPath.parse(metadataJson);
        String fileName = json.read("$.Document.documentMetadata.file_name", String.class);
        String transactionNumber = json.read("$.Document.WorkspaceInfo.TransactionNumber", String.class);
        
        log.info("[SERVLET-END-LARGE-UPLOAD] UploadKey: {}, FileName: {}", uploadKey, fileName);
        
        // Step 2: Stream file to disk (direct write, no .tmp)
        Path filePath = folderPath.resolve(fileName);
        long bytesWritten = 0;
        
        try (OutputStream out = Files.newOutputStream(filePath, 
                StandardOpenOption.CREATE, 
                StandardOpenOption.TRUNCATE_EXISTING)) {
            
            byte[] buffer = new byte[bufferSize];
            int bytesRead;
            
            while ((bytesRead = inputStream.read(buffer)) != -1) {
                out.write(buffer, 0, bytesRead);
                bytesWritten += bytesRead;
            }
        }
        
        log.info("[SERVLET-END-LARGE-UPLOAD] File written: {} bytes to {}", bytesWritten, filePath);
        
        return new EndLargeUploadResult(uploadKey, bytesWritten, filePath.toString(), fileName, transactionNumber, metadataJson);
    }

    /**
     * Result object for end large upload processing.
     */
    @Data
    public static class EndLargeUploadResult {
        private final String uniqueId;
        private final long bytesWritten;
        private final String filePath;
        private final String fileName;
        private final String transactionNumber;
        private final String metadataJson;
    }
}
