package com.orchestrator.processor;

import com.orchestrator.config.ApiLoggingInterceptor;
import com.orchestrator.config.SslPropertyConfig;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.HttpEntity;
import org.apache.http.entity.InputStreamEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ContentType;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.ssl.SSLContextBuilder;
import org.apache.http.util.EntityUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.io.ByteArrayInputStream;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.File;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Vector;
import javax.net.ssl.SSLContext;

/**
 * Streams large file directly to OTCS /api/v2/nodes without building multipart byte[] in memory.
 */
@Component("servletStreamingUploadToOtcsProcessor")
@RequiredArgsConstructor
@Slf4j
public class ServletStreamingUploadToOtcsProcessor implements Processor {

    private final StreamingFileUploadProcessor streamingFileUploadProcessor;
    private final ApiLoggingInterceptor apiLoggingInterceptor;
    private final SslPropertyConfig sslPropertyConfig;

    @Value("${app.OTCS_BASE_URL}")
    private String otcsBaseUrl;

    @Override
    public void process(Exchange exchange) throws Exception {
        String payload = exchange.getProperty("payload", String.class);
        String filePath = exchange.getProperty("filePath", String.class);
        String fileName = exchange.getProperty("fileName", String.class);
        Integer bwId = exchange.getProperty("bwId", Integer.class);
        String otcsTicket = exchange.getProperty("otcsTicket", String.class);

        if (filePath == null || fileName == null || bwId == null || payload == null || otcsTicket == null) {
            throw new IllegalArgumentException("Missing required properties for OTCS upload");
        }

        String otcsPayload = streamingFileUploadProcessor.buildOTCSPayload(payload, bwId);

        exchange.setProperty("API_START_TIME", System.currentTimeMillis());
        exchange.setProperty("API_ENDPOINT", "POST /api/v2/nodes");

        HttpPost post = new HttpPost(otcsBaseUrl + "/api/v2/nodes");
        post.setHeader("OTCSTicket", otcsTicket);
        post.setHeader("Accept", "application/json");

        File uploadFile = new File(filePath);
        if (!uploadFile.exists() || !uploadFile.isFile()) {
            throw new IllegalArgumentException("Upload file not found: " + filePath);
        }

        String boundary = "----OTCSBoundary" + System.currentTimeMillis();
        String contentType = "multipart/form-data; boundary=" + boundary;

        byte[] bodyPartHeader = (
            "--" + boundary + "\r\n" +
            "Content-Disposition: form-data; name=\"body\"\r\n" +
            "Content-Type: application/json; charset=UTF-8\r\n\r\n"
        ).getBytes(StandardCharsets.UTF_8);
        byte[] bodyPartPayload = otcsPayload.getBytes(StandardCharsets.UTF_8);
        byte[] bodyPartEnd = "\r\n".getBytes(StandardCharsets.UTF_8);

        byte[] filePartHeader = (
            "--" + boundary + "\r\n" +
            "Content-Disposition: form-data; name=\"file\"; filename=\"" + fileName + "\"\r\n" +
            "Content-Type: application/octet-stream\r\n\r\n"
        ).getBytes(StandardCharsets.UTF_8);
        byte[] closingBoundary = ("\r\n--" + boundary + "--\r\n").getBytes(StandardCharsets.UTF_8);

        long contentLength =
            bodyPartHeader.length +
            bodyPartPayload.length +
            bodyPartEnd.length +
            filePartHeader.length +
            uploadFile.length() +
            closingBoundary.length;

        Vector<InputStream> streams = new Vector<>(Arrays.asList(
            new ByteArrayInputStream(bodyPartHeader),
            new ByteArrayInputStream(bodyPartPayload),
            new ByteArrayInputStream(bodyPartEnd),
            new ByteArrayInputStream(filePartHeader),
            new FileInputStream(uploadFile),
            new ByteArrayInputStream(closingBoundary)
        ));

        InputStream multipartStream = new java.io.SequenceInputStream(streams.elements());
        HttpEntity multipart = new InputStreamEntity(multipartStream, contentLength, ContentType.parse(contentType));

        post.setEntity(multipart);

        try (CloseableHttpClient client = createHttpClient();
             CloseableHttpResponse response = client.execute(post)) {

            int statusCode = response.getStatusLine().getStatusCode();
            String responseBody = response.getEntity() != null
                    ? EntityUtils.toString(response.getEntity(), StandardCharsets.UTF_8)
                    : "";

            exchange.getIn().setBody(responseBody);
            exchange.getIn().setHeader(Exchange.HTTP_RESPONSE_CODE, statusCode);
            exchange.getIn().setHeader("CamelHttpResponseCode", statusCode);

            apiLoggingInterceptor.process(exchange);
            log.info("[SERVLET-STREAMING-OTCS] Upload response status: {}", statusCode);
        }
    }

    private CloseableHttpClient createHttpClient() throws Exception {
        String sslParam = sslPropertyConfig.getSslParam();
        boolean sslBypassEnabled = sslParam != null && sslParam.contains("allowAllSSLContextParameters");

        if (!sslBypassEnabled) {
            return HttpClients.createDefault();
        }

        log.warn("[SERVLET-STREAMING-OTCS] SSL bypass enabled for Apache HttpClient (local/dev only)");
        SSLContext sslContext = SSLContextBuilder.create()
                .loadTrustMaterial((chain, authType) -> true)
                .build();

        SSLConnectionSocketFactory sslSocketFactory = new SSLConnectionSocketFactory(
                sslContext,
                NoopHostnameVerifier.INSTANCE
        );

        return HttpClientBuilder.create()
                .setSSLSocketFactory(sslSocketFactory)
                .build();
    }
}
