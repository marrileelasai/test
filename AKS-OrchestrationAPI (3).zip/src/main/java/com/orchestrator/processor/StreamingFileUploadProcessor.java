package com.orchestrator.processor;

import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.orchestrator.service.CategoryMappingCacheService;
import com.orchestrator.util.MultipartBodyBuilder;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.io.FileInputStream;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * STREAMING FILE UPLOAD PROCESSOR
 * 
 * CRITICAL: Streams file using InputStream instead of readAllBytes()
 * WITHOUT loading entire file to memory
 * 
 * Works exactly like FileUploadProcessor but with streaming
 * Returns multipart body for Camel HTTP to send (same pattern)
 */
@Component("streamingFileUploadProcessor")
@RequiredArgsConstructor
@Slf4j
public class StreamingFileUploadProcessor implements Processor {

    private final CategoryMappingCacheService categoryMappingCacheService;
    
    @Value("${app.OTCS_DOCUMENT_TYPE:144}")
    private Integer documentType;
    
    @Override
    public void process(Exchange exchange) throws Exception {
        String payload = exchange.getProperty("payload", String.class);
        String filePath = exchange.getProperty("filePath", String.class);
        String fileName = exchange.getProperty("fileName", String.class);
        Integer bwId = exchange.getProperty("bwId", Integer.class);

        log.info("[STREAMING-UPLOAD] Preparing multipart from: {}", filePath);

        // Build OTCS payload
        String otcsPayload = buildOTCSPayload(payload, bwId);

        Path uploadPath = Path.of(filePath);
        long fileSize = Files.size(uploadPath);
        log.info("[STREAMING-UPLOAD] File size: {} bytes (will stream)", fileSize);

        // Stream file using InputStream (NOT readAllBytes!)
        try (InputStream fileStream = new FileInputStream(uploadPath.toFile())) {
            // Build multipart using utility - but with InputStream instead of byte[]
            MultipartBodyBuilder.Result result = MultipartBodyBuilder.buildStreaming(otcsPayload, fileStream, fileName, fileSize);

            // Set body and headers for Camel HTTP component to upload
            exchange.getIn().setBody(result.getBody());
            exchange.getIn().setHeader("Content-Type", result.getContentType());
            exchange.getIn().setHeader(Exchange.HTTP_METHOD, "POST");
            exchange.getIn().setHeader(Exchange.CONTENT_LENGTH, result.getBody().length);

            log.info("[STREAMING-UPLOAD] Multipart ready (streamed from disk): {} bytes", result.getBody().length);
        }
    }

    /**
     * Build OTCS payload JSON for /v2/nodes
     * Maps from documentMetadata only
     * Creates nested structure grouped by categoryId
     */
    public String buildOTCSPayload(String payload, Integer bwId) throws Exception {
        DocumentContext json = JsonPath.parse(payload);
        Map<String, Object> documentMetadata = json.read("$.Document.documentMetadata");
        String fileName = (String) documentMetadata.get("file_name");
        
        DocumentContext categoryMappings = categoryMappingCacheService.getCategoryMappings();
        List<Map<String, Object>> allMappings = categoryMappings.read("$.myRows[*]");

        log.info("[STREAMING-UPLOAD] Mapping from documentMetadata only using {} total mappings", allMappings.size());
        
        // Build FLAT structure: {categoryId_metadataId -> value}
        Map<String, String> categories = new LinkedHashMap<>();
        
        for (Map<String, Object> mapping : allMappings) {
            String categoryId = String.valueOf(mapping.get("categoryid"));
            String metadataId = String.valueOf(mapping.get("metadataid"));
            String otAttributeName = (String) mapping.get("otattributename");
            
            if (otAttributeName == null || otAttributeName.trim().isEmpty()) continue;

            String value = null;

            // Map from documentMetadata only (case-insensitive)
            if (documentMetadata.containsKey(otAttributeName)) {
                value = String.valueOf(documentMetadata.get(otAttributeName));
            } else {
                for (Map.Entry<String, Object> entry : documentMetadata.entrySet()) {
                    if (entry.getKey().equalsIgnoreCase(otAttributeName)) {
                        value = String.valueOf(entry.getValue());
                        break;
                    }
                }
            }

            if (value != null && !value.trim().isEmpty() && !"null".equals(value)) {
                // Flat structure: categories[categoryId_metadataId] = value
                categories.put(categoryId + "_" + metadataId, value);

                log.debug("[STREAMING-UPLOAD] Mapped {}_{}: {} = {}", categoryId, metadataId, otAttributeName, value);
            }
        }
        
        Map<String, Object> otcsPayload = new LinkedHashMap<>();
        otcsPayload.put("type", documentType);
        otcsPayload.put("parent_id", bwId);
        otcsPayload.put("name", fileName);
        otcsPayload.put("description", "");
        otcsPayload.put("roles", Map.of("categories", categories));
        
        log.info("[STREAMING-UPLOAD] Built OTCS payload with {} flat category attributes", categories.size());
        log.info("[STREAMING-UPLOAD] Category source policy: documentMetadata-only");
        
        String jsonPayload = JsonPath.parse(otcsPayload).jsonString();
        log.info("[STREAMING-UPLOAD] OTCS Upload Payload: {}", jsonPayload);
        
        return jsonPayload;
    }
}
