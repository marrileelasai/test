package com.orchestrator.processor;

import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

/**
 * Business logic processor for servlet-based StartLargeDocument.
 * 
 * Responsibilities:
 * - Parse JSON once
 * - Extract metadata
 * - Create unique folder
 * - Save metadata.json
 * 
 * Testable without Camel runtime.
 */
@Component
@Slf4j
public class ServletStartLargeUploadProcessor {

    @Value("${app.FILE_UPLOAD_PATH:/mnt/sftp-volume}")
    private String uploadPath;

    /**
     * Process start large upload request.
     * Parse JSON once, extract all needed fields, create folder, save metadata.
     * 
     * @param jsonBody Request JSON body
     * @return StartLargeUploadResult with uniqueId for response
     */
    public StartLargeUploadResult processRequest(String jsonBody) throws Exception {
        // Parse JSON once
        DocumentContext json = JsonPath.parse(jsonBody);
        
        // Extract all needed fields in one pass
        String transactionNumber = json.read("$.Document.WorkspaceInfo.TransactionNumber", String.class);
        String fileName = json.read("$.Document.documentMetadata.file_name", String.class);
        
        // Validate required fields
        if (transactionNumber == null || transactionNumber.isEmpty()) {
            throw new IllegalArgumentException("TransactionNumber is required");
        }
        if (fileName == null || fileName.isEmpty()) {
            throw new IllegalArgumentException("file_name is required");
        }
        
        log.info("[SERVLET-START-LARGE-UPLOAD] Transaction: {}, File: {}", transactionNumber, fileName);
        
        // Generate unique ID: transactionNumber_epochTimestamp
        String timestamp = String.valueOf(System.currentTimeMillis());
        String uniqueId = transactionNumber + "_" + timestamp;
        
        log.info("[SERVLET-START-LARGE-UPLOAD] Generated Uniqueid: {}", uniqueId);
        
        // Create folder
        Path folderPath = Paths.get(uploadPath, uniqueId);
        Files.createDirectories(folderPath);
        
        log.info("[SERVLET-START-LARGE-UPLOAD] Created folder: {}", folderPath);
        
        // Save metadata.json
        Path metadataPath = folderPath.resolve("metadata.json");
        Files.writeString(metadataPath, jsonBody);
        
        log.info("[SERVLET-START-LARGE-UPLOAD] Saved metadata.json: {}", metadataPath);
        
        // Return result
        return new StartLargeUploadResult(uniqueId, fileName, folderPath.toString());
    }

    /**
     * Result object for start large upload processing.
     */
    @Data
    public static class StartLargeUploadResult {
        private final String uniqueId;
        private final String fileName;
        private final String folderPath;
    }
}
