package com.orchestrator.processor;

import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.orchestrator.constants.OrchestratorConstants;
import com.orchestrator.service.CategoryMappingCacheService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.springframework.stereotype.Component;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Collections;
import java.util.stream.Collectors;

/**
 * Maps ESCAPE event data to Business Workspace payload
 * Uses category field mapping from cache (via CategoryMappingCacheService)
 * Refactored to use JSONPath and Map-based JSON building
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class BusinessWorkspaceMapper implements Processor {
    
    private final CategoryMappingCacheService categoryMappingCacheService;
    
    @Override
    public void process(Exchange exchange) throws Exception {
        log.info("[MAPPER] Starting Business Workspace payload construction");
        
        try {
            // Get category mapping from cache (direct service call - no exchange property needed)
            DocumentContext categoryMappingData = categoryMappingCacheService.getCategoryMappings();
            String categoryMappingJson = categoryMappingData.jsonString();
            log.debug("[MAPPER] Category mapping loaded from cache");
            
            // Get ESCAPE event
            String escapeEventJson = exchange.getProperty(OrchestratorConstants.PROP_ESCAPE_EVENT, String.class);
            String workspaceType = exchange.getProperty(OrchestratorConstants.PROP_WORKSPACE_TYPE, String.class);
            log.debug("[MAPPER] ESCAPE event JSON: {}", escapeEventJson);
            log.info("[MAPPER] WorkspaceType from exchange property '{}': {}", 
                OrchestratorConstants.PROP_WORKSPACE_TYPE, workspaceType);
            
            if (categoryMappingJson == null || escapeEventJson == null) {
                log.error("[MAPPER] Missing required data - categoryMapping: {}, escapeEvent: {}", 
                    categoryMappingJson != null, escapeEventJson != null);
                throw new IllegalStateException("Missing category mapping or ESCAPE event data");
            }
            
            // Build filtered category mapping JSON placeholder by workspaceType
            String filteredCategoryMappingJson = buildFilteredCategoryMappingJson(categoryMappingJson, workspaceType);
            log.info("[MAPPER] Filtered category mapping payload prepared for workspaceType '{}'", workspaceType);
            log.debug("[MAPPER] Filtered category mapping payload: {}", filteredCategoryMappingJson);

            // Build payload using filtered category mapping placeholder + ESCAPE event
            String workspacePayload = buildWorkspacePayload(filteredCategoryMappingJson, escapeEventJson);
            
            log.info("[MAPPER] Successfully constructed workspace payload");
            log.debug("[MAPPER] Workspace payload: {}", workspacePayload);
            
            // Use getMessage() instead of getIn() to preserve exchange properties
            exchange.getMessage().setBody(workspacePayload);
            exchange.setProperty(OrchestratorConstants.PROP_WORKSPACE_PAYLOAD, workspacePayload);
            
        } catch (Exception e) {
            log.error("[MAPPER] Error constructing workspace payload", e);
            throw new RuntimeException("Failed to construct Business Workspace payload", e);
        }
    }
    
    /**
     * Build workspace payload using JSONPath and Map-based JSON construction
     */
    private String buildWorkspacePayload(String categoryMappingJson, String escapeEventJson) {
        log.info("[MAPPER] Building workspace payload using JSONPath");
        
        // Parse ESCAPE event JSON once (not in loop!)
        DocumentContext escapeEventContext = JsonPath.parse(escapeEventJson);
        
        // Extract myRows from WebReport response using JSONPath
        List<Map<String, Object>> rows = extractMyRows(categoryMappingJson);
        log.info("[MAPPER] Extracted {} mapping rows", rows.size());
        
        // Extract template ID from actual category mappings (first row)
        Integer templateId = null;
        if (!rows.isEmpty()) {
            Object templateIdObj = rows.get(0).get("templateid");
            if (templateIdObj instanceof String) {
                templateId = Integer.parseInt((String) templateIdObj);
            } else if (templateIdObj instanceof Integer) {
                templateId = (Integer) templateIdObj;
            }
        }
        
        if (templateId == null) {
            log.error("[MAPPER] template_id not found in category mappings. First row: {}", 
                rows.isEmpty() ? "NO ROWS" : rows.get(0));
            throw new IllegalStateException("template_id not found in category mappings");
        }
        
        log.debug("[MAPPER] Using template ID from mappings: {}", templateId);
        
        // Extract submissionNumber for workspace name
        String submissionNumber = null;
        try {
            submissionNumber = escapeEventContext.read("$.data.submissionNumber");
            log.debug("[MAPPER] Extracted submissionNumber: {}", submissionNumber);
        } catch (Exception e) {
            log.warn("[MAPPER] Could not extract submissionNumber from ESCAPE event", e);
        }
        
        // Base template structure
        Map<String, Object> payload = new LinkedHashMap<>();
        payload.put("template_id", templateId);
        // NOTE: OTCS v2/businessworkspaces API fails with 500 error when "name" field is provided
        // Let OTCS auto-generate the workspace name instead
        // if (submissionNumber != null) {
        //     payload.put("name", submissionNumber);
        // }
        
        Map<String, Object> roles = new LinkedHashMap<>();
        Map<String, Object> categories = new LinkedHashMap<>();
        log.info("[MAPPER] Extracted {} mapping rows", rows.size());
        
        // Group fields by categoryId
        for (Map<String, Object> row : rows) {
            String categoryId = String.valueOf(row.get("categoryid"));
            String metadataId = String.valueOf(row.get("metadataid"));
            String sourceAttribute = (String) row.get("sourceattribute");
            String categoryName = (String) row.get("categoryname");
            
            log.debug("[MAPPER] Processing: categoryId={}, metadataId={}, sourceAttribute={}, categoryName={}", 
                categoryId, metadataId, sourceAttribute, categoryName);
            
            // Get or create category object
            @SuppressWarnings("unchecked")
            Map<String, Object> categoryFields = (Map<String, Object>) categories.computeIfAbsent(
                categoryId, k -> new LinkedHashMap<>()
            );
            
            // Build field key: categoryid_metadataid
            String fieldKey = categoryId + "_" + metadataId;
            
            // Extract value from ESCAPE event using JSONPath
            String fieldValue = null;
            if (sourceAttribute != null && !sourceAttribute.equals("null") && !sourceAttribute.isEmpty()) {
                try {
                    fieldValue = escapeEventContext.read("$.data." + sourceAttribute);
                    log.debug("[MAPPER] Mapped field {}: {} = {}", fieldKey, sourceAttribute, fieldValue);
                } catch (Exception e) {
                    log.debug("[MAPPER] Field {} not found in ESCAPE event: {}", sourceAttribute, e.getMessage());
                }
            } else {
                log.debug("[MAPPER] No sourceattribute for field {}, setting to null", fieldKey);
            }
            
            // Add field to category
            categoryFields.put(fieldKey, fieldValue);
        }
        
        // Build final structure
        roles.put("categories", categories);
        payload.put("roles", roles);
        
        // Convert Map to JSON using JsonPath (handles escaping, nested Maps, nulls)
        String jsonPayload = JsonPath.parse(payload).jsonString();
        
        log.info("[MAPPER] Workspace payload construction complete");
        return jsonPayload;
    }

    private String buildFilteredCategoryMappingJson(String categoryMappingJson, String workspaceType) {
        if (workspaceType == null || workspaceType.trim().isEmpty()) {
            log.info("[MAPPER] workspaceType not provided, using original categoryMappingJson payload");
            return categoryMappingJson;
        }

        DocumentContext rootContext = JsonPath.parse(categoryMappingJson);
        @SuppressWarnings("unchecked")
        Map<String, Object> root = rootContext.read("$");

        @SuppressWarnings("unchecked")
        List<Map<String, Object>> allRows = (List<Map<String, Object>>) root.get("myRows");
        if (allRows == null) {
            allRows = Collections.emptyList();
        }

        log.info("[MAPPER] Total mapping rows before workspaceType filter: {}", allRows.size());

        List<Map<String, Object>> filteredRows = allRows.stream()
            .filter(row -> {
                Object mappingWorkspaceTypeObj = row.get("workspacetype");
                return mappingWorkspaceTypeObj != null
                    && workspaceType.equalsIgnoreCase(String.valueOf(mappingWorkspaceTypeObj));
            })
            .collect(Collectors.toList());

        if (filteredRows.isEmpty()) {
            List<String> availableTypes = allRows.stream()
                .map(row -> row.get("workspacetype"))
                .filter(Objects::nonNull)
                .map(String::valueOf)
                .distinct()
                .sorted()
                .collect(Collectors.toList());

            String error = String.format(
                "No category mappings found for workspaceType '%s'. Available workspacetype values: %s",
                workspaceType, availableTypes
            );
            log.error("[MAPPER] {}", error);
            throw new IllegalStateException(error);
        }

        root.put("actualRows", filteredRows.size());
        root.put("filteredRows", filteredRows.size());
        root.put("myRows", filteredRows);
        root.put("sourceID", root.get("sourceID"));
        root.put("totalRows", filteredRows.size());
        root.put("totalSourceRows", filteredRows.size());
        

        String filteredJson = JsonPath.parse(root).jsonString();
        log.info("[MAPPER] Created filtered categoryMappingJson with {} rows for workspaceType '{}'",
            filteredRows.size(), workspaceType);
        return filteredJson;
    }
    
    /**
     * Extract myRows array from WebReport response using JSONPath
     * Handles nested escaped JSON in "data" field
     */
    @SuppressWarnings("unchecked")
    private List<Map<String, Object>> extractMyRows(String json) {
        log.debug("[MAPPER] Extracting myRows using JSONPath");
        
        // Parse once
        DocumentContext jsonContext = JsonPath.parse(json);
        
        try {
            // Try direct path first
            return jsonContext.read("$.myRows");
        } catch (Exception e1) {
            log.debug("[MAPPER] Direct $.myRows failed, trying nested data.myRows");
            
            try {
                // Try data.myRows (for nested structure)
                String dataJson = jsonContext.read("$.data");
                
                // If data is a string (escaped JSON), parse it
                if (dataJson.startsWith("{") || dataJson.startsWith("[")) {
                    DocumentContext dataContext = JsonPath.parse(dataJson);
                    return dataContext.read("$.myRows");
                }
                
                return jsonContext.read("$.data.myRows");
            } catch (Exception e2) {
                log.error("[MAPPER] Failed to extract myRows from response", e2);
                throw new RuntimeException("Could not find myRows in WebReport response", e2);
            }
        }
    }
}
