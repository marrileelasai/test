package com.orchestrator.chunkedupload.util;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

public class BoundedFileInputStream extends InputStream {

    private final InputStream delegate;
    private long remaining;

    public BoundedFileInputStream(File file, long startOffset, long length, int bufferSize) throws IOException {
        FileInputStream fis = new FileInputStream(file);
        fis.getChannel().position(startOffset);
        this.delegate = new BufferedInputStream(fis, bufferSize);
        this.remaining = length;
    }

    @Override
    public int read() throws IOException {
        if (remaining <= 0) {
            return -1;
        }
        int value = delegate.read();
        if (value != -1) {
            remaining--;
        }
        return value;
    }

    @Override
    public int read(byte[] b, int off, int len) throws IOException {
        if (remaining <= 0) {
            return -1;
        }
        int maxLen = (int) Math.min(len, remaining);
        int read = delegate.read(b, off, maxLen);
        if (read > 0) {
            remaining -= read;
        }
        return read;
    }

    @Override
    public void close() throws IOException {
        delegate.close();
    }
}
