package com.orchestrator.chunkedupload.processor;

import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.orchestrator.chunkedupload.config.ChunkedUploadProperties;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.Part;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.springframework.stereotype.Component;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.UUID;

@Component("chunkedMultipartIngressProcessor")
@RequiredArgsConstructor
@Slf4j
public class ChunkedMultipartIngressProcessor implements Processor {

    private final ChunkedUploadProperties properties;

    @Override
    public void process(Exchange exchange) throws Exception {
        HttpServletRequest request = exchange.getIn().getHeader("CamelHttpServletRequest", HttpServletRequest.class);
        if (request == null) {
            throw new IllegalArgumentException("Servlet request is not available");
        }

        String contentType = request.getContentType();
        if (contentType == null || !contentType.toLowerCase().startsWith("multipart/")) {
            throw new IllegalArgumentException("Content-Type must be multipart/form-data");
        }

        Part metadataPart = null;
        Part filePart = null;
        for (Part part : request.getParts()) {
            if ("metadata".equalsIgnoreCase(part.getName())) {
                metadataPart = part;
            } else if ("file".equalsIgnoreCase(part.getName())) {
                filePart = part;
            }
        }

        if (metadataPart == null || filePart == null) {
            throw new IllegalArgumentException("Missing required multipart parts: metadata/file");
        }

        String metadataJson;
        try (InputStream metadataStream = metadataPart.getInputStream()) {
            metadataJson = new String(metadataStream.readAllBytes(), StandardCharsets.UTF_8);
        }

        if (metadataJson.isBlank()) {
            throw new IllegalArgumentException("metadata part is empty");
        }

        DocumentContext json = JsonPath.parse(metadataJson);
        String transactionNumber = json.read("$.Document.WorkspaceInfo.TransactionNumber", String.class);
        String fileNameFromMetadata = json.read("$.Document.documentMetadata.file_name", String.class);

        if (transactionNumber == null || transactionNumber.isBlank()) {
            throw new IllegalArgumentException("metadata Document.WorkspaceInfo.TransactionNumber is required");
        }

        String submittedFileName = filePart.getSubmittedFileName();
        String fileName = (fileNameFromMetadata != null && !fileNameFromMetadata.isBlank())
                ? fileNameFromMetadata
                : submittedFileName;

        if (fileName == null || fileName.isBlank()) {
            throw new IllegalArgumentException("metadata Document.documentMetadata.file_name or multipart file name is required");
        }

        Path spoolDir = Path.of(properties.getSpoolTempPath());
        Files.createDirectories(spoolDir);

        Path spoolFile = spoolDir.resolve(UUID.randomUUID() + ".upload.tmp");
        try (InputStream rawIn = filePart.getInputStream();
             InputStream in = new BufferedInputStream(rawIn, properties.getIoBufferSize());
             OutputStream out = new BufferedOutputStream(Files.newOutputStream(spoolFile), properties.getIoBufferSize())) {
            byte[] buffer = new byte[properties.getIoBufferSize()];
            int read;
            while ((read = in.read(buffer)) != -1) {
                out.write(buffer, 0, read);
            }
        }

        String folderName = transactionNumber + "_" + System.currentTimeMillis();
        Path finalDir = Path.of(properties.getFinalBasePath(), folderName);
        Files.createDirectories(finalDir);

        Path finalFilePath = finalDir.resolve(fileName);
        try {
            Files.move(spoolFile, finalFilePath, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
        } catch (Exception atomicMoveEx) {
            Files.move(spoolFile, finalFilePath, StandardCopyOption.REPLACE_EXISTING);
        }

        long fileSize = Files.size(finalFilePath);
        log.info("[CHUNKED-UPLOAD] File moved from spool to final location - Txn: {}, File: {}, Size: {} bytes", transactionNumber, fileName, fileSize);

        exchange.getIn().setBody(metadataJson);
        exchange.setProperty("requestBody", metadataJson);
        exchange.setProperty("payload", metadataJson);
        exchange.setProperty("transactionNumber", transactionNumber);
        exchange.setProperty("folderName", folderName);
        exchange.setProperty("fileName", fileName);
        exchange.setProperty("filePath", finalFilePath.toString());
        exchange.setProperty("fileSize", fileSize);
    }
}
