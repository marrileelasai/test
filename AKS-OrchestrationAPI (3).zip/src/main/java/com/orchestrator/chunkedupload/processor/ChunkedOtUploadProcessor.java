package com.orchestrator.chunkedupload.processor;

import com.jayway.jsonpath.JsonPath;
import com.orchestrator.chunkedupload.config.ChunkedUploadProperties;
import com.orchestrator.chunkedupload.util.BoundedFileInputStream;
import com.orchestrator.config.ApiLoggingInterceptor;
import com.orchestrator.config.SslPropertyConfig;
import com.orchestrator.processor.ServletStreamingUploadToOtcsProcessor;
import com.orchestrator.processor.StreamingFileUploadProcessor;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.InputStreamEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.ssl.SSLContextBuilder;
import org.apache.http.util.EntityUtils;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.net.ssl.SSLContext;
import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.lang.management.ManagementFactory;
import java.lang.management.MemoryMXBean;
import java.lang.management.MemoryUsage;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Vector;

@Component("chunkedOtUploadProcessor")
@ConditionalOnProperty(prefix = "app.chunked-upload", name = "enabled", havingValue = "true")
@RequiredArgsConstructor
@Slf4j
public class ChunkedOtUploadProcessor implements Processor {

    private final ChunkedUploadProperties properties;
    private final StreamingFileUploadProcessor streamingFileUploadProcessor;
    private final ApiLoggingInterceptor apiLoggingInterceptor;
    private final SslPropertyConfig sslPropertyConfig;
    private final ObjectMapper objectMapper;
    private final ServletStreamingUploadToOtcsProcessor servletStreamingUploadToOtcsProcessor;

    @Value("${app.OTCS_BASE_URL}")
    private String otcsBaseUrl;

    @Override
    public void process(Exchange exchange) throws Exception {
        String payload = exchange.getProperty("payload", String.class);
        String filePath = exchange.getProperty("filePath", String.class);
        String fileName = exchange.getProperty("fileName", String.class);
        Integer bwId = exchange.getProperty("bwId", Integer.class);
        String otcsTicket = exchange.getProperty("otcsTicket", String.class);

        logResourceSnapshot("before-upload", null, null, null);

        if (!properties.isUseChunkApi()) {
            log.info("[CHUNKED-UPLOAD] Chunk API disabled. Using single-call upload via /api/v2/nodes");
            logResourceSnapshot("before-single-upload", null, null, null);
            servletStreamingUploadToOtcsProcessor.process(exchange);
            logResourceSnapshot("after-single-upload", null, null, null);
            return;
        }

        if (filePath == null || fileName == null || bwId == null || payload == null || otcsTicket == null) {
            throw new IllegalArgumentException("Missing required properties for chunked OTCS upload");
        }

        File uploadFile = new File(filePath);
        if (!uploadFile.exists() || !uploadFile.isFile()) {
            throw new IllegalArgumentException("Upload file not found: " + filePath);
        }

        long fileSize = Files.size(uploadFile.toPath());

        long minChunkApiBytes = properties.getMinFileSizeForChunkApiMb() * 1024L * 1024L;
        if (fileSize < minChunkApiBytes) {
            log.warn("[CHUNKED-UPLOAD] File size {} bytes is below OT multipart minimum {} MB. Using single-call upload via /api/v2/nodes",
                fileSize,
                properties.getMinFileSizeForChunkApiMb());
            logResourceSnapshot("before-small-file-fallback-single-upload", null, null, null);
            servletStreamingUploadToOtcsProcessor.process(exchange);
            logResourceSnapshot("after-small-file-fallback-single-upload", null, null, null);
            return;
        }

        long chunkSizeBytes = properties.getChunkSizeMb() * 1024L * 1024L;
        int totalParts = (int) Math.ceil((double) fileSize / (double) chunkSizeBytes);

        String otcsPayload = streamingFileUploadProcessor.buildOTCSPayload(payload, bwId);

        try (CloseableHttpClient client = createHttpClient()) {
            try {
                String uploadId = initializeChunkedUpload(exchange, client, otcsTicket, fileName, fileSize, totalParts, chunkSizeBytes, otcsPayload);
                logResourceSnapshot("after-init", null, totalParts, null);

                for (int partNumber = 1; partNumber <= totalParts; partNumber++) {
                    long offset = (long) (partNumber - 1) * chunkSizeBytes;
                    long partLength = Math.min(chunkSizeBytes, fileSize - offset);
                    if (properties.isResourceLogEachPart()) {
                        logResourceSnapshot("before-part", partNumber, totalParts, partLength);
                    }
                    uploadSingleChunk(exchange, client, otcsTicket, uploadId, uploadFile, partNumber, offset, partLength);
                    if (properties.isResourceLogEachPart()) {
                        logResourceSnapshot("after-part", partNumber, totalParts, partLength);
                    }
                }

                logResourceSnapshot("before-complete", null, totalParts, null);
                String completeResponse = completeChunkedUpload(exchange, client, otcsTicket, uploadId);
                exchange.getIn().setBody(completeResponse);
                exchange.getIn().setHeader(Exchange.HTTP_RESPONSE_CODE, 200);
                exchange.getIn().setHeader("CamelHttpResponseCode", 200);
                logResourceSnapshot("after-complete", null, totalParts, null);
            } catch (RuntimeException chunkApiFailure) {
                if (properties.isFallbackToSingleUploadIfChunkApiUnavailable() && isChunkApiUnavailableError(chunkApiFailure)) {
                    log.warn("[CHUNKED-UPLOAD] OTCS chunk API unavailable. Falling back to single /api/v2/nodes upload. Cause: {}", chunkApiFailure.getMessage());
                    logResourceSnapshot("before-fallback-single-upload", null, null, null);
                    servletStreamingUploadToOtcsProcessor.process(exchange);
                    logResourceSnapshot("after-fallback-single-upload", null, null, null);
                } else {
                    throw chunkApiFailure;
                }
            }
        }

        logResourceSnapshot("after-upload", null, null, null);
    }

    private void logResourceSnapshot(String stage, Integer partNumber, Integer totalParts, Long partLength) {
        if (!properties.isResourceLoggingEnabled()) {
            return;
        }

        Runtime runtime = Runtime.getRuntime();
        long usedHeap = runtime.totalMemory() - runtime.freeMemory();
        long committedHeap = runtime.totalMemory();
        long maxHeap = runtime.maxMemory();

        MemoryMXBean memoryBean = ManagementFactory.getMemoryMXBean();
        MemoryUsage heapUsage = memoryBean.getHeapMemoryUsage();

        double usedHeapMb = bytesToMb(usedHeap);
        double committedHeapMb = bytesToMb(committedHeap);
        double maxHeapMb = bytesToMb(maxHeap);
        double mxBeanUsedMb = bytesToMb(heapUsage.getUsed());

        String cpuInfo = "n/a";
        java.lang.management.OperatingSystemMXBean osBean = ManagementFactory.getOperatingSystemMXBean();
        if (osBean instanceof com.sun.management.OperatingSystemMXBean sunOsBean) {
            double processCpuLoad = sunOsBean.getProcessCpuLoad();
            long processCpuTimeNanos = sunOsBean.getProcessCpuTime();
            cpuInfo = String.format("processCpuLoad=%.3f, processCpuTimeMs=%d",
                    processCpuLoad,
                    processCpuTimeNanos / 1_000_000L);
        }

        if (partNumber != null && totalParts != null) {
            log.info("[CHUNKED-UPLOAD][RESOURCES] stage={}, part={}/{}, partBytes={}, heapUsedMb={}, heapCommittedMb={}, heapMaxMb={}, mxBeanHeapUsedMb={}, {}",
                    stage,
                    partNumber,
                    totalParts,
                    partLength,
                    String.format("%.2f", usedHeapMb),
                    String.format("%.2f", committedHeapMb),
                    String.format("%.2f", maxHeapMb),
                    String.format("%.2f", mxBeanUsedMb),
                    cpuInfo);
        } else {
            log.info("[CHUNKED-UPLOAD][RESOURCES] stage={}, heapUsedMb={}, heapCommittedMb={}, heapMaxMb={}, mxBeanHeapUsedMb={}, {}",
                    stage,
                    String.format("%.2f", usedHeapMb),
                    String.format("%.2f", committedHeapMb),
                    String.format("%.2f", maxHeapMb),
                    String.format("%.2f", mxBeanUsedMb),
                    cpuInfo);
        }
    }

    private double bytesToMb(long bytes) {
        return bytes / (1024.0 * 1024.0);
    }

    private boolean isChunkApiUnavailableError(RuntimeException ex) {
        String msg = ex.getMessage();
        if (msg == null) {
            return false;
        }
        String lc = msg.toLowerCase();
        return lc.contains("mappings registry")
                || (lc.contains("chunk") && lc.contains("404"))
            || (lc.contains("chunk") && lc.contains("could not be found"))
            || lc.contains("file is too small")
            || (lc.contains("min size") && lc.contains("mb"));
    }

    private String initializeChunkedUpload(Exchange exchange,
                                           CloseableHttpClient client,
                                           String otcsTicket,
                                           String fileName,
                                           long fileSize,
                                           int totalParts,
                                           long chunkSizeBytes,
                                           String otcsPayload) throws Exception {

        String url = otcsBaseUrl + properties.getOtcs().getInitPath();
        log.info("[CHUNKED-UPLOAD] Calling OT init API: {}", url);
        HttpPost post = new HttpPost(url);
        post.setHeader("OTCSTicket", otcsTicket);
        post.setHeader("Accept", "application/json");

        // OTCS /v2/multipart expects form parameters where `body` can be parsed as Assoc
        // Send as multipart/form-data with `body` as JSON string (same style as /v2/nodes style body field)
        String boundary = "----OTCSMultipartInit" + System.nanoTime();
        String contentType = "multipart/form-data; boundary=" + boundary;

        byte[] fileNamePart = (
            "--" + boundary + "\r\n" +
            "Content-Disposition: form-data; name=\"file_name\"\r\n\r\n" +
            fileName + "\r\n"
        ).getBytes(StandardCharsets.UTF_8);

        byte[] fileSizePart = (
            "--" + boundary + "\r\n" +
            "Content-Disposition: form-data; name=\"file_size\"\r\n\r\n" +
            fileSize + "\r\n"
        ).getBytes(StandardCharsets.UTF_8);

        byte[] partSizePart = (
            "--" + boundary + "\r\n" +
            "Content-Disposition: form-data; name=\"part_size\"\r\n\r\n" +
            chunkSizeBytes + "\r\n"
        ).getBytes(StandardCharsets.UTF_8);

        byte[] totalPartsPart = (
            "--" + boundary + "\r\n" +
            "Content-Disposition: form-data; name=\"total_parts\"\r\n\r\n" +
            totalParts + "\r\n"
        ).getBytes(StandardCharsets.UTF_8);

        byte[] bodyHeader = (
            "--" + boundary + "\r\n" +
            "Content-Disposition: form-data; name=\"body\"\r\n" +
            "Content-Type: application/json; charset=UTF-8\r\n\r\n"
        ).getBytes(StandardCharsets.UTF_8);

        byte[] bodyPayload = otcsPayload.getBytes(StandardCharsets.UTF_8);
        byte[] bodyEnd = "\r\n".getBytes(StandardCharsets.UTF_8);
        byte[] closing = ("--" + boundary + "--\r\n").getBytes(StandardCharsets.UTF_8);

        long contentLength =
            fileNamePart.length +
            fileSizePart.length +
            partSizePart.length +
            totalPartsPart.length +
            bodyHeader.length +
            bodyPayload.length +
            bodyEnd.length +
            closing.length;

        Vector<InputStream> streams = new Vector<>(Arrays.asList(
            new ByteArrayInputStream(fileNamePart),
            new ByteArrayInputStream(fileSizePart),
            new ByteArrayInputStream(partSizePart),
            new ByteArrayInputStream(totalPartsPart),
            new ByteArrayInputStream(bodyHeader),
            new ByteArrayInputStream(bodyPayload),
            new ByteArrayInputStream(bodyEnd),
            new ByteArrayInputStream(closing)
        ));

        InputStream multipartStream = new java.io.SequenceInputStream(streams.elements());
        post.setEntity(new InputStreamEntity(multipartStream, contentLength, ContentType.parse(contentType)));

        exchange.setProperty("API_START_TIME", System.currentTimeMillis());
        exchange.setProperty("API_ENDPOINT", "POST " + properties.getOtcs().getInitPath());

        try (CloseableHttpResponse response = client.execute(post)) {
            int status = response.getStatusLine().getStatusCode();
            String responseBody = response.getEntity() != null
                    ? EntityUtils.toString(response.getEntity(), StandardCharsets.UTF_8)
                    : "";
            exchange.getIn().setHeader(Exchange.HTTP_RESPONSE_CODE, status);
            exchange.getIn().setBody(responseBody);
            apiLoggingInterceptor.process(exchange);

            if (status < 200 || status >= 300) {
                throw new RuntimeException("Chunk init failed with status " + status + ": " + responseBody);
            }

            String uploadId = extractUploadId(responseBody);
            log.info("[CHUNKED-UPLOAD] Init successful. uploadId={}, totalParts={}", uploadId, totalParts);
            return uploadId;
        }
    }

        private void uploadSingleChunk(Exchange exchange,
                                   CloseableHttpClient client,
                                   String otcsTicket,
                                   String uploadId,
                                   File uploadFile,
                                   int partNumber,
                                   long offset,
                                   long partLength) throws Exception {

        String path = String.format(properties.getOtcs().getChunkPathTemplate(), uploadId, partNumber);
        String url = otcsBaseUrl + path;
        log.info("[CHUNKED-UPLOAD] Calling OT part API: {} (part {})", url, partNumber);

        final int maxAttempts = 3;
        for (int attempt = 1; attempt <= maxAttempts; attempt++) {
            HttpPost post = new HttpPost(url);
            post.setHeader("OTCSTicket", otcsTicket);
            post.setHeader("Accept", "application/json");

            // OT multipart part endpoint expects multipart/form-data with binary field part_content
            String boundary = "----OTCSMultipartPart" + System.nanoTime();
            String contentType = "multipart/form-data; boundary=" + boundary;
            post.setHeader("Content-Type", contentType);

            byte[] partHeader = (
                "--" + boundary + "\r\n" +
                "Content-Disposition: form-data; name=\"part_content\"; filename=\"part-" + partNumber + ".bin\"\r\n" +
                "Content-Type: application/octet-stream\r\n\r\n"
            ).getBytes(StandardCharsets.UTF_8);
            byte[] closing = ("\r\n--" + boundary + "--\r\n").getBytes(StandardCharsets.UTF_8);

            long contentLength = partHeader.length + partLength + closing.length;

            Vector<InputStream> streams = new Vector<>(Arrays.asList(
                new ByteArrayInputStream(partHeader),
                new BufferedInputStream(new BoundedFileInputStream(uploadFile, offset, partLength, properties.getIoBufferSize()), properties.getIoBufferSize()),
                new ByteArrayInputStream(closing)
            ));

            InputStream multipartStream = new java.io.SequenceInputStream(streams.elements());
            post.setEntity(new InputStreamEntity(multipartStream, contentLength, ContentType.parse(contentType)));

            exchange.setProperty("API_START_TIME", System.currentTimeMillis());
            exchange.setProperty("API_ENDPOINT", "POST " + path + " (attempt " + attempt + "/" + maxAttempts + ")");

            try (CloseableHttpResponse response = client.execute(post)) {
                int status = response.getStatusLine().getStatusCode();
                String responseBody = response.getEntity() != null
                        ? EntityUtils.toString(response.getEntity(), StandardCharsets.UTF_8)
                        : "";

                exchange.getIn().setHeader(Exchange.HTTP_RESPONSE_CODE, status);
                exchange.getIn().setBody(responseBody);
                apiLoggingInterceptor.process(exchange);

                if (status >= 200 && status < 300) {
                    log.info("[CHUNKED-UPLOAD] Uploaded part {} ({} bytes) on attempt {}/{}",
                            partNumber, partLength, attempt, maxAttempts);
                    return;
                }

                if (attempt == maxAttempts) {
                    throw new RuntimeException("Chunk upload failed for part " + partNumber + ", status=" + status + ", body=" + responseBody);
                }

                log.warn("[CHUNKED-UPLOAD] Part {} upload failed with status {} on attempt {}/{}. Retrying...",
                        partNumber, status, attempt, maxAttempts);
            } catch (IOException ioEx) {
                if (attempt == maxAttempts) {
                    throw ioEx;
                }
                log.warn("[CHUNKED-UPLOAD] Part {} upload connection error on attempt {}/{}: {}. Retrying...",
                        partNumber, attempt, maxAttempts, ioEx.getMessage());
            }

            Thread.sleep(2000L * attempt);
        }
    }

    private String completeChunkedUpload(Exchange exchange,
                                         CloseableHttpClient client,
                                         String otcsTicket,
                                         String uploadId) throws Exception {

        String path = String.format(properties.getOtcs().getCompletePathTemplate(), uploadId);
        String url = otcsBaseUrl + path;
        log.info("[CHUNKED-UPLOAD] Calling OT complete API: {}", url);

        HttpPost post = new HttpPost(url);
        post.setHeader("OTCSTicket", otcsTicket);
        post.setHeader("Accept", "application/json");
        
        // Simple POST with upload_key only - no request body per swagger

        exchange.setProperty("API_START_TIME", System.currentTimeMillis());
        exchange.setProperty("API_ENDPOINT", "POST " + path);

        try (CloseableHttpResponse response = client.execute(post)) {
            int status = response.getStatusLine().getStatusCode();
            String responseBody = response.getEntity() != null
                    ? EntityUtils.toString(response.getEntity(), StandardCharsets.UTF_8)
                    : "";

            exchange.getIn().setHeader(Exchange.HTTP_RESPONSE_CODE, status);
            exchange.getIn().setBody(responseBody);
            apiLoggingInterceptor.process(exchange);

            if (status < 200 || status >= 300) {
                throw new RuntimeException("Chunk complete failed, status=" + status + ", body=" + responseBody);
            }

            log.info("[CHUNKED-UPLOAD] Complete successful. uploadId={}", uploadId);
            log.info("[CHUNKED-UPLOAD] Complete response body: {}", responseBody);
            return responseBody;
        }
    }

    private String extractUploadId(String responseBody) {
        String[] paths = new String[]{
                "$.upload_key",
                "$.uploadKey",
                "$.upload_id",
                "$.uploadId",
                "$.results.upload_key",
                "$.results.uploadKey",
                "$.results.upload_id",
                "$.results.uploadId",
            "$.results.data.upload_key",
            "$.results.data.uploadKey",
            "$.results.data.upload_id",
            "$.results.data.uploadId",
                "$.data.upload_key",
                "$.data.uploadKey",
                "$.data.upload_id",
                "$.data.uploadId"
        };

        for (String path : paths) {
            try {
                Object uploadIdRaw = JsonPath.read(responseBody, path);
                String uploadId = uploadIdRaw != null ? String.valueOf(uploadIdRaw) : null;
                if (uploadId != null && !uploadId.isBlank()) {
                    return uploadId;
                }
            } catch (Exception ignored) {
                // Try next path
            }
        }
        throw new IllegalStateException("uploadId not found in chunk-init response: " + responseBody);
    }

    private CloseableHttpClient createHttpClient() throws Exception {
        String sslParam = sslPropertyConfig.getSslParam();
        boolean sslBypassEnabled = sslParam != null && sslParam.contains("allowAllSSLContextParameters");

        if (!sslBypassEnabled) {
            return HttpClients.createDefault();
        }

        log.warn("[CHUNKED-UPLOAD] SSL bypass enabled for Apache HttpClient (local/dev only)");
        SSLContext sslContext = SSLContextBuilder.create()
                .loadTrustMaterial((chain, authType) -> true)
                .build();

        SSLConnectionSocketFactory sslSocketFactory = new SSLConnectionSocketFactory(
                sslContext,
                NoopHostnameVerifier.INSTANCE
        );

        return HttpClientBuilder.create()
                .setSSLSocketFactory(sslSocketFactory)
                .build();
    }
}
