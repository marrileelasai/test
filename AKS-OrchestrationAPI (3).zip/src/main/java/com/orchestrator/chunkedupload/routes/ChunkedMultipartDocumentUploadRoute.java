package com.orchestrator.chunkedupload.routes;

import com.jayway.jsonpath.JsonPath;
import com.orchestrator.chunkedupload.config.ChunkedUploadProperties;
import com.orchestrator.chunkedupload.service.ChunkedUploadConcurrencyGuard;
import com.orchestrator.config.ResponseLoggingInterceptor;
import com.orchestrator.exception.GlobalExceptionHandler;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.camel.LoggingLevel;
import org.apache.camel.builder.RouteBuilder;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

import java.util.LinkedHashMap;
import java.util.Map;

@Component
@ConditionalOnProperty(prefix = "app.chunked-upload", name = "enabled", havingValue = "true")
@RequiredArgsConstructor
@Slf4j
public class ChunkedMultipartDocumentUploadRoute extends RouteBuilder {

    private final GlobalExceptionHandler globalExceptionHandler;
    private final ResponseLoggingInterceptor responseLoggingInterceptor;
    private final ChunkedUploadProperties properties;
    private final ChunkedUploadConcurrencyGuard concurrencyGuard;

    @Override
    public void configure() throws Exception {

        onException(Exception.class)
            .handled(true)
            .process(exchange -> {
                if (Boolean.TRUE.equals(exchange.getProperty("chunkedGuardAcquired", Boolean.class))) {
                    concurrencyGuard.release();
                    exchange.setProperty("chunkedGuardAcquired", false);
                }
            })
            .process(globalExceptionHandler)
            .log(LoggingLevel.ERROR, "[UPLOAD-CHUNKED] Exception processed by GlobalExceptionHandler");

        from("platform-http:" + properties.getApiPath() + "?httpMethodRestrict=POST")
            .routeId("document-upload-chunked-poc-api")
            .process(exchange -> exchange.setProperty("EXPOSED_API_ENDPOINT", "POST " + properties.getApiPath()))
            .log(LoggingLevel.INFO, "[UPLOAD-CHUNKED] ========== Chunked Upload Request Received ==========")

            .process(exchange -> {
                boolean acquired = concurrencyGuard.tryAcquire();
                if (!acquired) {
                    Map<String, Object> res = new LinkedHashMap<>();
                    res.put("status", "error");
                    res.put("message", "Too many concurrent uploads in progress. Try again shortly.");

                    exchange.getIn().setHeader(Exchange.HTTP_RESPONSE_CODE, 429);
                    exchange.getIn().setHeader("CamelHttpResponseCode", 429);
                    exchange.getIn().setBody(JsonPath.parse(res).jsonString());
                    exchange.setProperty(Exchange.ROUTE_STOP, Boolean.TRUE);
                    return;
                }
                exchange.setProperty("chunkedGuardAcquired", true);
            })

            .filter(exchangeProperty(Exchange.ROUTE_STOP).isNull())
                .process("chunkedMultipartIngressProcessor")
                .to("json-validator:schemas/upload-multipart-schema.json")
                .log(LoggingLevel.INFO, "[UPLOAD-CHUNKED] Request validation successful")

                .to("direct:authenticate-otcs")
                .to("direct:get-business-workspace-id")

                .process(exchange -> {
                    String payload = exchange.getProperty("payload", String.class);
                    exchange.setProperty("requestBody", payload);
                })

                .choice()
                    .when(exchangeProperty("bwExists").isEqualTo(false))
                        .log(LoggingLevel.WARN, "[UPLOAD-CHUNKED] Workspace not found, creating...")
                        .to("direct:create-bw-for-upload")
                    .otherwise()
                        .log(LoggingLevel.INFO, "[UPLOAD-CHUNKED] Workspace exists: ${exchangeProperty.bwId}")
                        .to("direct:build-bw-payload")
                        .to("direct:put-workspace")
                .end()

                .process("chunkedOtUploadProcessor")
                .to("direct:upload-api-response")
                .process(responseLoggingInterceptor)
                .log(LoggingLevel.INFO, "[UPLOAD-CHUNKED] ========== Chunked Upload Complete ==========")
            .end()

            .process(exchange -> {
                if (Boolean.TRUE.equals(exchange.getProperty("chunkedGuardAcquired", Boolean.class))) {
                    concurrencyGuard.release();
                    exchange.setProperty("chunkedGuardAcquired", false);
                }
            });
    }
}
