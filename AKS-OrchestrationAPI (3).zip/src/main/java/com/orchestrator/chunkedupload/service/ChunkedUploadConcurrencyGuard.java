package com.orchestrator.chunkedupload.service;

import java.util.concurrent.Semaphore;

public class ChunkedUploadConcurrencyGuard {

    private final Semaphore semaphore;

    public ChunkedUploadConcurrencyGuard(int maxConcurrentUploads) {
        this.semaphore = new Semaphore(Math.max(1, maxConcurrentUploads), true);
    }

    public boolean tryAcquire() {
        return semaphore.tryAcquire();
    }

    public void release() {
        semaphore.release();
    }

    public int getActiveUploads() {
        return semaphore.getQueueLength();
    }
}
