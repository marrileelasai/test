package com.orchestrator.chunkedupload.config;

import com.orchestrator.chunkedupload.service.ChunkedUploadConcurrencyGuard;
import jakarta.servlet.MultipartConfigElement;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.web.servlet.MultipartConfigFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.util.unit.DataSize;

import java.nio.file.Files;
import java.nio.file.Path;

@Configuration
@EnableConfigurationProperties(ChunkedUploadProperties.class)
public class ChunkedUploadConfiguration {

    @Bean
    @ConditionalOnProperty(prefix = "app.chunked-upload", name = "enabled", havingValue = "true")
    public MultipartConfigElement multipartConfigElementForChunkedPoc(ChunkedUploadProperties properties) throws Exception {
        Path spoolPath = Path.of(properties.getSpoolTempPath());
        Files.createDirectories(spoolPath);

        MultipartConfigFactory factory = new MultipartConfigFactory();
        factory.setLocation(spoolPath.toString());
        factory.setFileSizeThreshold(DataSize.ofBytes(0));
        return factory.createMultipartConfig();
    }

    @Bean
    @ConditionalOnProperty(prefix = "app.chunked-upload", name = "enabled", havingValue = "true")
    public ChunkedUploadConcurrencyGuard chunkedUploadConcurrencyGuard(ChunkedUploadProperties properties) {
        return new ChunkedUploadConcurrencyGuard(properties.getMaxConcurrentUploads());
    }
}
