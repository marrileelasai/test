package com.orchestrator.chunkedupload.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "app.chunked-upload")
public class ChunkedUploadProperties {

    private boolean enabled = false;
    private String apiPath = "/api/v1/UploadLargefileChunked";
    private String spoolTempPath = "/mnt/sftp-volume/.chunked-spool";
    private String finalBasePath = "/mnt/sftp-volume";
    private int chunkSizeMb = 100;
    private int minFileSizeForChunkApiMb = 100;
    private int ioBufferSize = 1_048_576;
    private int maxConcurrentUploads = 2;
    private boolean useChunkApi = false;
    private boolean fallbackToSingleUploadIfChunkApiUnavailable = true;
    private boolean resourceLoggingEnabled = true;
    private boolean resourceLogEachPart = true;

    private Otcs otcs = new Otcs();

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    public String getApiPath() {
        return apiPath;
    }

    public void setApiPath(String apiPath) {
        this.apiPath = apiPath;
    }

    public String getSpoolTempPath() {
        return spoolTempPath;
    }

    public void setSpoolTempPath(String spoolTempPath) {
        this.spoolTempPath = spoolTempPath;
    }

    public String getFinalBasePath() {
        return finalBasePath;
    }

    public void setFinalBasePath(String finalBasePath) {
        this.finalBasePath = finalBasePath;
    }

    public int getChunkSizeMb() {
        return chunkSizeMb;
    }

    public void setChunkSizeMb(int chunkSizeMb) {
        this.chunkSizeMb = chunkSizeMb;
    }

    public int getMinFileSizeForChunkApiMb() {
        return minFileSizeForChunkApiMb;
    }

    public void setMinFileSizeForChunkApiMb(int minFileSizeForChunkApiMb) {
        this.minFileSizeForChunkApiMb = minFileSizeForChunkApiMb;
    }

    public int getIoBufferSize() {
        return ioBufferSize;
    }

    public void setIoBufferSize(int ioBufferSize) {
        this.ioBufferSize = ioBufferSize;
    }

    public int getMaxConcurrentUploads() {
        return maxConcurrentUploads;
    }

    public void setMaxConcurrentUploads(int maxConcurrentUploads) {
        this.maxConcurrentUploads = maxConcurrentUploads;
    }

    public boolean isUseChunkApi() {
        return useChunkApi;
    }

    public void setUseChunkApi(boolean useChunkApi) {
        this.useChunkApi = useChunkApi;
    }

    public boolean isFallbackToSingleUploadIfChunkApiUnavailable() {
        return fallbackToSingleUploadIfChunkApiUnavailable;
    }

    public void setFallbackToSingleUploadIfChunkApiUnavailable(boolean fallbackToSingleUploadIfChunkApiUnavailable) {
        this.fallbackToSingleUploadIfChunkApiUnavailable = fallbackToSingleUploadIfChunkApiUnavailable;
    }

    public boolean isResourceLoggingEnabled() {
        return resourceLoggingEnabled;
    }

    public void setResourceLoggingEnabled(boolean resourceLoggingEnabled) {
        this.resourceLoggingEnabled = resourceLoggingEnabled;
    }

    public boolean isResourceLogEachPart() {
        return resourceLogEachPart;
    }

    public void setResourceLogEachPart(boolean resourceLogEachPart) {
        this.resourceLogEachPart = resourceLogEachPart;
    }

    public Otcs getOtcs() {
        return otcs;
    }

    public void setOtcs(Otcs otcs) {
        this.otcs = otcs;
    }

    public static class Otcs {
        private String initPath = "/api/v2/multipart";
        private String chunkPathTemplate = "/api/v2/multipart/%s/%d";
        private String completePathTemplate = "/api/v2/multipart/%s";

        public String getInitPath() {
            return initPath;
        }

        public void setInitPath(String initPath) {
            this.initPath = initPath;
        }

        public String getChunkPathTemplate() {
            return chunkPathTemplate;
        }

        public void setChunkPathTemplate(String chunkPathTemplate) {
            this.chunkPathTemplate = chunkPathTemplate;
        }

        public String getCompletePathTemplate() {
            return completePathTemplate;
        }

        public void setCompletePathTemplate(String completePathTemplate) {
            this.completePathTemplate = completePathTemplate;
        }
    }
}
