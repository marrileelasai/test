package com.orchestrator.service;

import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.CamelContext;
import org.apache.camel.ProducerTemplate;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

/**
 * In-Memory cache service for category field mappings from WebReport.
 * 
 * Features:
 * - Loads category mappings on startup
 * - Caches in memory using Camel's Caffeine component (1 hour TTL, time-based eviction)
 * - Provides fast JSONPath query methods
 * - Auto-refreshes every hour via scheduled task
 * - Thread-safe
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class CategoryMappingCacheService {

    private final ProducerTemplate producerTemplate;
    private final CamelContext camelContext;
    private final ApplicationContext applicationContext;

    @Value("${app.BASE_WEBREPORTS_URL}")
    private String baseWebReportsUrl;

    @Value("${app.OTCS_BASE_URL}")
    private String otcsBaseUrl;

    private static final String CACHE_NAME = "categoryMappingsCache";
    private static final String CACHE_KEY = "default";

    /**
     * REMOVED: Don't load on startup - load lazily on first request
     * This avoids timing issues with Camel context initialization
     */
    // @EventListener(ApplicationReadyEvent.class)
    // public void loadCacheOnStartup() {
    //     log.info("=== CategoryMappingCacheService: Loading cache after application ready ===");
    //     try {
    //         refreshCache("DEV");
    //         log.info("=== CategoryMappingCacheService: Startup cache load completed ===");
    //     } catch (Exception e) {
    //         log.error("=== CategoryMappingCacheService: Failed to load cache on startup ===", e);
    //     }
    // }

    /**
     * Scheduled refresh every hour - only runs after first cache load
     */
    @Scheduled(fixedRate = 3600000, initialDelay = 3600000) // 1 hour in milliseconds
    public void scheduledRefresh() {
        log.info("=== CategoryMappingCacheService: Scheduled refresh starting ===");
        try {
            refreshCache(CACHE_KEY);
            log.info("=== CategoryMappingCacheService: Scheduled refresh completed ===");
        } catch (Exception e) {
            log.error("=== CategoryMappingCacheService: Scheduled refresh failed ===", e);
        }
    }

    /**
     * Refresh cache by calling WebReport
     * Environment parameter is embedded in BASE_WEBREPORTS_URL (e.g., /webreports=DEV)
     */
    public void refreshCache(String cacheKey) {
        log.info("Refreshing category mapping cache...");

        try {
            // Step 1: Authenticate to get token
            String authToken = authenticate();
            
            log.info("Got auth ticket: {}...", authToken.substring(0, Math.min(20, authToken.length())));
            
            // Step 2: Call WebReport using full URL from BASE_WEBREPORTS_URL (no modification needed)
            String webReportUrl = baseWebReportsUrl;
            
            log.info("Calling WebReport: {}", webReportUrl);
            
            // Conditionally add SSL bypass parameter (only if bean exists in local dev)
            boolean sslBypassBeanExists = applicationContext.containsBean("allowAllSSLContextParameters");
            String sslParam = sslBypassBeanExists ? "&sslContextParameters=#allowAllSSLContextParameters" : "";
            String camelUrl = webReportUrl + "&bridgeEndpoint=true&throwExceptionOnFailure=false" + sslParam;
            
            log.info("Camel URL: {}", camelUrl);
            
            String response = producerTemplate.requestBodyAndHeader(
                camelUrl,
                "",
                "OTCSTicket", authToken,
                String.class
            );

            if (response == null || response.trim().isEmpty()) {
                log.error("WebReport returned empty response");
                return;
            }

            log.debug("WebReport response (first 200 chars): {}", response.substring(0, Math.min(200, response.length())));

            // Step 3: Parse nested JSON response - "data" field contains JSON STRING
            DocumentContext outerJson = JsonPath.parse(response);
            String dataString = outerJson.read("$.data", String.class);

            if (dataString == null || dataString.trim().isEmpty()) {
                log.error("WebReport data field is empty");
                return;
            }

            // Step 4: Parse the inner JSON string to get actual category data
            DocumentContext categoryData = JsonPath.parse(dataString);
            List<Map<String, Object>> myRows = categoryData.read("$.myRows");

            log.info("Loaded {} category field mappings", myRows.size());

            // Cache the DocumentContext for fast querying using Camel's caffeine component
            producerTemplate.sendBodyAndHeaders(
                "caffeine-cache://" + CACHE_NAME + "?evictionType=TIME_BASED&expireAfterWriteTime=3600",
                categoryData,
                Map.of(
                    "CamelCaffeineAction", "PUT",
                    "CamelCaffeineKey", cacheKey
                )
            );

            log.info("Category mappings cached successfully with 1 hour TTL (time-based eviction)");

        } catch (Exception e) {
            log.error("Failed to refresh category mapping cache", e);
            throw new RuntimeException("Failed to refresh category mapping cache", e);
        }
    }

    /**
     * Get all category mappings (loads on first access)
     * Environment is now part of BASE_WEBREPORTS_URL
     */
    public DocumentContext getCategoryMappings() {
        // Get from Camel caffeine cache
        DocumentContext cached = producerTemplate.requestBodyAndHeaders(
            "caffeine-cache://" + CACHE_NAME + "?evictionType=TIME_BASED&expireAfterWriteTime=3600",
            null,
            Map.of(
                "CamelCaffeineAction", "GET",
                "CamelCaffeineKey", CACHE_KEY
            ),
            DocumentContext.class
        );
        
        if (cached == null) {
            log.info("Cache miss. Loading category mappings (first access)...");
            refreshCache(CACHE_KEY);
            cached = producerTemplate.requestBodyAndHeaders(
                "caffeine-cache://" + CACHE_NAME + "?evictionType=TIME_BASED&expireAfterWriteTime=3600",
                null,
                Map.of(
                    "CamelCaffeineAction", "GET",
                    "CamelCaffeineKey", CACHE_KEY
                ),
                DocumentContext.class
            );
        }

        return cached;
    }

    /**
     * Authenticate with OTCS and return ticket value only
     */
    private String authenticate() {
        try {
            // Use existing authentication route
            String authResponse = producerTemplate.requestBody("direct:authenticate-otcs", null, String.class);

            log.debug("Authentication successful. Response: {}...", authResponse.substring(0, Math.min(50, authResponse.length())));

            // Extract ticket from JSON response: {"ticket":"abc123..."}
            DocumentContext json = JsonPath.parse(authResponse);
            String ticket = json.read("$.ticket", String.class);

            log.debug("Extracted ticket: {}...", ticket.substring(0, Math.min(20, ticket.length())));

            return ticket;

        } catch (Exception e) {
            log.error("Authentication failed", e);
            throw new RuntimeException("Authentication failed", e);
        }
    }

    /**
     * Clear cache (useful for testing or manual refresh)
     */
    public void clearCache() {
        producerTemplate.sendBodyAndHeader(
            "caffeine-cache://" + CACHE_NAME + "?evictionType=TIME_BASED&expireAfterWriteTime=3600",
            null,
            "CamelCaffeineAction", "INVALIDATE_ALL"
        );
        log.info("Category mapping cache cleared");
    }

    /**
     * Get cache statistics
     */
    public String getCacheStats() {
        // Note: Camel's Caffeine component doesn't expose detailed stats via producer template
        // Stats are available via JMX or cache component properties
        return "Cache managed by Camel Caffeine component with 1-hour time-based eviction";
    }
}
