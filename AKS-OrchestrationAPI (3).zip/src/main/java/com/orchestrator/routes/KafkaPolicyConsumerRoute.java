package com.orchestrator.routes;

import com.orchestrator.constants.OrchestratorConstants;
import org.apache.camel.LoggingLevel;
import org.apache.camel.builder.RouteBuilder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class KafkaPolicyConsumerRoute extends RouteBuilder {

    @Value("${app.KAFKA_THREAD_POOL_MIN}")
    private int threadPoolMin;
    
    @Value("${app.KAFKA_THREAD_POOL_MAX}")
    private int threadPoolMax;

    @Override
    public void configure() {

      
    from("kafka:{{app.KAFKA_POLICY_TOPIC}}"
                  + "?groupId={{app.KAFKA_POLICY_GROUPID}}"
                 + "&clientId={{app.KAFKA_POLICY_CLIENT_ID}}"
                + "&autoOffsetReset=earliest"
                + "&autoCommitEnable=true"
                + "&maxPollRecords=5")
                .routeId("kafka-Policy-to-OT")
                .threads(threadPoolMin, threadPoolMax, "escapePolicy-to-OT-threadPool")
                .log(LoggingLevel.INFO, "Step 1: Kafka received payload: ${body}")
               .setProperty(OrchestratorConstants.PROP_WORKSPACE_TYPE, constant("Policy"))
               .log(LoggingLevel.INFO, "Step 1.1: Set workspaceType property to fixed value: ${exchangeProperty.workspaceType}")
               .to("direct:orchestrate-business-workspace");
        
    }
}