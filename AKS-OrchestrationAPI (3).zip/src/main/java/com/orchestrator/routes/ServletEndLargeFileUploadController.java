package com.orchestrator.routes;

import com.orchestrator.processor.ServletEndLargeUploadProcessor;
import com.orchestrator.processor.ServletEndLargeUploadProcessor.EndLargeUploadResult;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.camel.ProducerTemplate;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.io.InputStream;

/**
 * Servlet-native endpoint for large binary upload.
 *
 * This avoids Camel platform-http body handling and reads directly from servlet InputStream.
 */
@RestController
@RequiredArgsConstructor
@Slf4j
public class ServletEndLargeFileUploadController {

    private final ServletEndLargeUploadProcessor endLargeUploadProcessor;
    private final ProducerTemplate producerTemplate;

    @PostMapping(value = "/uploadapi/v1/UploadLargeDocument", consumes = MediaType.ALL_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<String> uploadLargeDocument(
            @RequestParam("UploadKey") String uploadKey,
            HttpServletRequest request) throws Exception {

        if (uploadKey == null || uploadKey.isBlank()) {
            throw new IllegalArgumentException("UploadKey query parameter is required");
        }

        log.info("[SERVLET-END-LARGE-UPLOAD] ========== End Large File Upload Request Received ==========");
        log.info("[SERVLET-END-LARGE-UPLOAD] UploadKey: {}", uploadKey);

        try (InputStream inputStream = request.getInputStream()) {
            log.info("[SERVLET-END-LARGE-UPLOAD] Raw servlet InputStream type: {}", inputStream.getClass().getName());

            EndLargeUploadResult result = endLargeUploadProcessor.processUpload(uploadKey, inputStream);

            log.info("[SERVLET-END-LARGE-UPLOAD] File streaming complete: {} bytes", result.getBytesWritten());

            // Continue OTCS orchestration flow (same as EndLargeFileUploadRoute Step 4+)
            Exchange exchange = producerTemplate.request("direct:servlet-end-large-post-process", ex -> {
                ex.setProperty("id", result.getUniqueId());
                ex.setProperty("transactionNumber", result.getTransactionNumber());
                ex.setProperty("payload", result.getMetadataJson());
                ex.setProperty("fileName", result.getFileName());
                ex.setProperty("filePath", result.getFilePath());
                ex.setProperty("requestBody", result.getMetadataJson());
            });

            String responseBody = exchange.getMessage().getBody(String.class);
            Integer statusCode = exchange.getMessage().getHeader(Exchange.HTTP_RESPONSE_CODE, Integer.class);
            if (statusCode == null) {
                statusCode = 200;
            }

            log.info("[SERVLET-END-LARGE-UPLOAD] ========== End Large File Upload Complete ==========");

            return ResponseEntity.status(statusCode)
                    .contentType(MediaType.APPLICATION_JSON)
                    .body(responseBody);
        }
    }
}
