package com.orchestrator.routes;

import com.orchestrator.constants.OrchestratorConstants;
import org.apache.camel.LoggingLevel;
import org.apache.camel.builder.RouteBuilder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class KafkaConsumerRoute extends RouteBuilder {

    @Value("${app.KAFKA_THREAD_POOL_MIN}")
    private int threadPoolMin;
    
    @Value("${app.KAFKA_THREAD_POOL_MAX}")
    private int threadPoolMax;

    @Override
    public void configure() {

                // Real Kafka consumer

        
    from("kafka:{{app.KAFKA_SUBMISSION_TOPIC}}")
                .routeId("kafka-Submission-to-OT")
                //.autoStartup(false)
                .threads(threadPoolMin, threadPoolMax, "escapeSubmission-to-OT-threadPool")
                .log(LoggingLevel.INFO, "Step 1: Kafka received payload: ${body}")
               .setProperty(OrchestratorConstants.PROP_WORKSPACE_TYPE, constant("Submission"))
               .log(LoggingLevel.INFO, "Step 1.1: Set workspaceType property to fixed value: ${exchangeProperty.workspaceType}")
               .to("direct:orchestrate-business-workspace");
        
    }
}