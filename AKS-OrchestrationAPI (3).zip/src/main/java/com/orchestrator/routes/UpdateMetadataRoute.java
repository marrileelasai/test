package com.orchestrator.routes;

import com.orchestrator.config.ResponseLoggingInterceptor;
import com.orchestrator.exception.GlobalExceptionHandler;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.camel.LoggingLevel;
import org.apache.camel.builder.RouteBuilder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * Update Metadata API - Updates workspace categories without uploading documents
 * 
 * Reuses existing routes:
 * - direct:authenticate-otcs
 * - direct:create-bw-for-upload (build payload, gets cached mappings directly)
 * - direct:get-business-workspace-id
 * - direct:update-workspace-categories
 */
@Component
@RequiredArgsConstructor
@Slf4j
public class UpdateMetadataRoute extends RouteBuilder {

    private final GlobalExceptionHandler globalExceptionHandler;
    private final ResponseLoggingInterceptor responseLoggingInterceptor;
    
    @Value("${app.OTCS_BASE_URL}")
    private String otcsBaseUrl;

    @Override
    public void configure() throws Exception {

        // Global error handler - use GlobalExceptionHandler for consistent error formatting
        onException(Exception.class)
            .handled(true)
            .process(globalExceptionHandler)
            .log(LoggingLevel.ERROR, "[UPDATE-METADATA] Exception processed by GlobalExceptionHandler");

        // Main endpoint
        from("platform-http:/api/v1/UpdateMetadata?httpMethodRestrict=POST")
            .routeId("update-metadata-api")
            .process(exchange -> exchange.setProperty("EXPOSED_API_ENDPOINT", "POST /api/v1/UpdateMetadata"))
            .log(LoggingLevel.INFO, "[UPDATE-METADATA] ========== Start UpdateMetadata ==============")
            .log(LoggingLevel.DEBUG, "[UPDATE-METADATA] Request body: ${body}")
            
            // Step 0: Validate request schema
            .to("json-validator:schemas/update-metadata-schema.json")
            .log(LoggingLevel.INFO, "[UPDATE-METADATA] Request validation successful")
            
            // Save request body to exchange property
            .setProperty("requestBody", body())
            
            // Extract TransactionNumber for workspace lookup
            .process(exchange -> {
                com.jayway.jsonpath.DocumentContext json = com.jayway.jsonpath.JsonPath.parse(exchange.getProperty("requestBody", String.class));
                String transactionNumber = json.read("$.Document.WorkspaceInfo.TransactionNumber", String.class);
                exchange.setProperty("transactionNumber", transactionNumber);
                log.info("[UPDATE-METADATA] Transaction Number: {}", transactionNumber);
            })

            // Step 1: Authenticate
            .log(LoggingLevel.INFO, "[UPDATE-METADATA] Step 1: Authenticating with OTCS")
            .to("direct:authenticate-otcs")
            .log(LoggingLevel.INFO, "[UPDATE-METADATA] Authentication successful")

            // Step 2: Get workspace ID first (check if exists)
            .log(LoggingLevel.INFO, "[UPDATE-METADATA] Step 2: Getting workspace ID")
            .to("direct:get-business-workspace-id")
            
            // Check if workspace exists (route sets bwExists property)
            .process(exchange -> {
                Boolean bwExists = exchange.getProperty("bwExists", Boolean.class);
                if (bwExists == null || !bwExists) {
                    log.error("[UPDATE-METADATA] Workspace not found for transaction: {}", 
                        exchange.getProperty("transactionNumber", String.class));
                    throw new IllegalStateException("Business Workspace not found for the given Transaction Number");
                }
                Integer bwId = exchange.getProperty("bwId", Integer.class);
                log.info("[UPDATE-METADATA] Workspace ID: {}", bwId);
            })

            // Step 4: Build payload
            .log(LoggingLevel.INFO, "[UPDATE-METADATA] Step 4: Building payload")
            .to("direct:build-bw-payload")
            .log(LoggingLevel.INFO, "[UPDATE-METADATA] Payload built successfully")
            .setProperty("categoryPayload", body())
            
            // Step 5: Update categories - let GlobalExceptionHandler handle failures
            .log(LoggingLevel.INFO, "[UPDATE-METADATA] Step 5: Updating categories")
            .setBody(exchangeProperty("categoryPayload"))
            .to("direct:update-workspace-categories")
            .log(LoggingLevel.INFO, "[UPDATE-METADATA] All categories updated successfully")
            .setHeader(Exchange.HTTP_RESPONSE_CODE, constant(200))
            .setBody(constant("{\"status\":\"success\",\"message\":\"Metadata updated successfully\"}"))
            
            .log(LoggingLevel.INFO, "[UPDATE-METADATA] ========== UpdateMetadata Complete ==========")            .process(responseLoggingInterceptor)            .setHeader(Exchange.CONTENT_TYPE, constant("application/json"));
    }
}
