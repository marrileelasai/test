package com.orchestrator.routes;

import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.orchestrator.config.ResponseLoggingInterceptor;
import com.orchestrator.exception.GlobalExceptionHandler;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.Part;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.LoggingLevel;
import org.apache.camel.builder.RouteBuilder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

/**
 * Document Upload API - Multipart metadata + file
 *
 * Endpoint: POST /api/v1/UploadDocumentMultipart
 * Content-Type: multipart/form-data
 *
 * Parts:
 * - metadata: JSON payload equivalent to UploadDocument body (without file_content_base64)
 * - file: Binary file
 *
 * Rest of orchestration flow is same as DocumentUploadRoute.
 */
@Component
@RequiredArgsConstructor
@Slf4j
public class MultipartDocumentUploadRoute extends RouteBuilder {

    private final GlobalExceptionHandler globalExceptionHandler;
    private final ResponseLoggingInterceptor responseLoggingInterceptor;

    @Value("${app.FILE_UPLOAD_PATH}")
    private String fileUploadPath;

    @Override
    public void configure() throws Exception {

        // Global exception handling
        onException(Exception.class)
            .handled(true)
            .process(globalExceptionHandler)
            .log(LoggingLevel.ERROR, "[UPLOAD-MULTIPART-API] Exception processed by GlobalExceptionHandler");

        from("platform-http:/api/v1/UploadLargefile?httpMethodRestrict=POST")
            .routeId("document-upload-multipart-api")
            .process(exchange -> exchange.setProperty("EXPOSED_API_ENDPOINT", "POST /api/v1/UploadDocumentMultipart"))
            .log(LoggingLevel.INFO, "[UPLOAD-MULTIPART] ========== Document Upload Request Received (Multipart) ==========")

            // Step 0: Parse multipart (metadata + file) and save file to disk
            .process(exchange -> {
                HttpServletRequest request = exchange.getIn().getHeader("CamelHttpServletRequest", HttpServletRequest.class);
                if (request == null) {
                    throw new IllegalArgumentException("Servlet request is not available");
                }

                String contentType = request.getContentType();
                if (contentType == null || !contentType.toLowerCase().startsWith("multipart/")) {
                    throw new IllegalArgumentException("Content-Type must be multipart/form-data");
                }

                Part metadataPart = null;
                Part filePart = null;
                for (Part part : request.getParts()) {
                    if ("metadata".equalsIgnoreCase(part.getName())) {
                        metadataPart = part;
                    } else if ("file".equalsIgnoreCase(part.getName())) {
                        filePart = part;
                    }
                }

                if (metadataPart == null) {
                    throw new IllegalArgumentException("Missing 'metadata' multipart part");
                }
                if (filePart == null) {
                    throw new IllegalArgumentException("Missing 'file' multipart part");
                }

                String metadataJson;
                try (InputStream metadataStream = metadataPart.getInputStream()) {
                    metadataJson = new String(metadataStream.readAllBytes(), StandardCharsets.UTF_8);
                }

                if (metadataJson.isBlank()) {
                    throw new IllegalArgumentException("'metadata' multipart part is empty");
                }

                DocumentContext json = JsonPath.parse(metadataJson);
                String transactionNumber = json.read("$.Document.WorkspaceInfo.TransactionNumber", String.class);
                String fileNameFromMetadata = json.read("$.Document.documentMetadata.file_name", String.class);

                if (transactionNumber == null || transactionNumber.isBlank()) {
                    throw new IllegalArgumentException("metadata Document.WorkspaceInfo.TransactionNumber is required");
                }

                String submittedFileName = filePart.getSubmittedFileName();
                String fileName = (fileNameFromMetadata != null && !fileNameFromMetadata.isBlank())
                        ? fileNameFromMetadata
                        : submittedFileName;

                if (fileName == null || fileName.isBlank()) {
                    throw new IllegalArgumentException("metadata Document.documentMetadata.file_name or multipart file name is required");
                }

                String timestamp = String.valueOf(System.currentTimeMillis());
                String folderName = transactionNumber + "_" + timestamp;

                Path dirPath = Paths.get(fileUploadPath, folderName);
                Files.createDirectories(dirPath);

                Path filePath = dirPath.resolve(fileName);
                try (InputStream fileStream = filePart.getInputStream()) {
                    Files.copy(fileStream, filePath, StandardCopyOption.REPLACE_EXISTING);
                }

                long fileSize = Files.size(filePath);
                log.info("[UPLOAD-MULTIPART] File saved to disk - Transaction: {}, File: {}, Size: {} bytes", transactionNumber, fileName, fileSize);

                // Keep flow-compatible properties expected by downstream routes/processors
                exchange.getIn().setBody(metadataJson);
                exchange.setProperty("requestBody", metadataJson);
                exchange.setProperty("payload", metadataJson);
                exchange.setProperty("transactionNumber", transactionNumber);
                exchange.setProperty("folderName", folderName);
                exchange.setProperty("fileName", fileName);
                exchange.setProperty("filePath", filePath.toString());
            })

            // Step 1: Validate metadata schema
            .to("json-validator:schemas/upload-multipart-schema.json")
            .log(LoggingLevel.INFO, "[UPLOAD-MULTIPART] Request validation successful")

            // Step 2: Authenticate with OTCS
            .log(LoggingLevel.INFO, "[UPLOAD-MULTIPART] Step 2: Authenticating with OTCS")
            .to("direct:authenticate-otcs")
            .log(LoggingLevel.INFO, "[UPLOAD-MULTIPART] Authentication successful")

            // Step 3: Get workspace ID (sets bwExists property)
            .to("direct:get-business-workspace-id")

            // Prepare request body for workspace create/update routes
            .process(exchange -> {
                String payload = exchange.getProperty("payload", String.class);
                exchange.setProperty("requestBody", payload);
                log.info("[UPLOAD-MULTIPART] requestBody property prepared for workspace operations ({} chars)",
                    payload != null ? payload.length() : 0);
            })

            // Step 4: Create workspace if needed
            .choice()
                .when(exchangeProperty("bwExists").isEqualTo(false))
                    .log(LoggingLevel.WARN, "[UPLOAD-MULTIPART] Workspace not found, creating...")
                    .to("direct:create-bw-for-upload")
                .otherwise()
                    .log(LoggingLevel.INFO, "[UPLOAD-MULTIPART] Workspace exists: ${exchangeProperty.bwId}")
                    .log(LoggingLevel.INFO, "[UPLOAD-MULTIPART] Updating existing workspace categories before document upload")
                    .to("direct:build-bw-payload")
                    .to("direct:put-workspace")
                    .log(LoggingLevel.INFO, "[UPLOAD-MULTIPART] Existing workspace categories updated successfully")
            .end()

            // Step 5: Stream file directly to OTCS /v2/nodes (no multipart byte[] in heap)
            .log(LoggingLevel.INFO, "[UPLOAD-MULTIPART] Uploading to OTCS /v2/nodes (streaming mode)")
            .process("servletStreamingUploadToOtcsProcessor")
            .log(LoggingLevel.INFO, "[UPLOAD-MULTIPART] Upload response status: ${header.CamelHttpResponseCode}")

            // Step 7: Transform response to simplified format
            .to("direct:upload-api-response")

            .process(responseLoggingInterceptor)
            .log(LoggingLevel.INFO, "[UPLOAD-MULTIPART] ========== Upload Complete ==========");
    }
}
