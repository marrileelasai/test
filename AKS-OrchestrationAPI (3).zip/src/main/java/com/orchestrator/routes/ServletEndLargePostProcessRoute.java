package com.orchestrator.routes;

import com.orchestrator.exception.GlobalExceptionHandler;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.camel.LoggingLevel;
import org.apache.camel.builder.RouteBuilder;
import org.springframework.stereotype.Component;

/**
 * Post-processing route for servlet large upload.
 * Reuses existing Camel integrations after the file is streamed by Spring MVC controller.
 */
@Component
@RequiredArgsConstructor
@Slf4j
public class ServletEndLargePostProcessRoute extends RouteBuilder {

    private final GlobalExceptionHandler globalExceptionHandler;

    @Override
    public void configure() throws Exception {

        onException(Exception.class)
            .handled(true)
            .process(globalExceptionHandler)
            .log(LoggingLevel.ERROR, "[SERVLET-END-POST] Exception processed by GlobalExceptionHandler");

        from("direct:servlet-end-large-post-process")
            .routeId("servlet-end-large-post-process")
            .autoStartup(false)
            .log(LoggingLevel.INFO, "[SERVLET-END-POST] Step 4: Authenticating with OTCS")
            .to("direct:authenticate-otcs")
            .log(LoggingLevel.INFO, "[SERVLET-END-POST] Authentication successful")

            // Step 5: Get workspace ID
            .to("direct:get-business-workspace-id")

            // Prepare request body for workspace create/update routes
            .process(exchange -> {
                String payload = exchange.getProperty("payload", String.class);
                exchange.setProperty("requestBody", payload);
                log.info("[SERVLET-END-POST] requestBody property prepared for workspace operations ({} chars)",
                    payload != null ? payload.length() : 0);
            })

            // Step 6: Create workspace if needed
            .choice()
                .when(exchangeProperty("bwExists").isEqualTo(false))
                    .log(LoggingLevel.WARN, "[SERVLET-END-POST] Workspace not found, creating...")
                    .to("direct:create-bw-for-upload")
                .otherwise()
                    .log(LoggingLevel.INFO, "[SERVLET-END-POST] Workspace exists: ${exchangeProperty.bwId}")
                    .log(LoggingLevel.INFO, "[SERVLET-END-POST] Updating existing workspace categories before document upload")
                    .to("direct:build-bw-payload")
                    .to("direct:put-workspace")
                    .log(LoggingLevel.INFO, "[SERVLET-END-POST] Existing workspace categories updated successfully")
            .end()

            // Step 7/8: Stream multipart directly to OTCS /v2/nodes (no byte[] buffering)
            .log(LoggingLevel.INFO, "[SERVLET-END-POST] Step 7/8: Streaming upload to OTCS /v2/nodes")
            .process("servletStreamingUploadToOtcsProcessor")

            // Step 9: Transform response to simplified API
            .to("direct:upload-api-response")

            // Ensure response headers are available to controller
            .process(exchange -> {
                Integer statusCode = exchange.getIn().getHeader(Exchange.HTTP_RESPONSE_CODE, Integer.class);
                if (statusCode == null) {
                    Integer camelHttpStatus = exchange.getIn().getHeader("CamelHttpResponseCode", Integer.class);
                    statusCode = camelHttpStatus != null ? camelHttpStatus : 200;
                }
                exchange.getIn().setHeader(Exchange.HTTP_RESPONSE_CODE, statusCode);
                exchange.getIn().setHeader(Exchange.CONTENT_TYPE, "application/json");
            });
    }
}
