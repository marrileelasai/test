package com.orchestrator.routes;

import com.orchestrator.config.ApiLoggingInterceptor;
import com.orchestrator.config.SslPropertyConfig;
import com.orchestrator.exception.GlobalExceptionHandler;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.camel.LoggingLevel;
import org.apache.camel.builder.RouteBuilder;
import org.springframework.stereotype.Component;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Update Business Workspace Categories (Kafka Update flow)
 * 
 * Instead of PUT /v2/businessworkspaces, uses multiple PUT calls:
 * PUT /v2/nodes/{bwId}/categories/{categoryId}/ with form-urlencoded body
 * 
 * INPUT: Requires exchange property "bwId" and body with nested categories payload
 * PATTERN: Splitter + Parallel Processing (async calls)
 */
@Component
@RequiredArgsConstructor
@Slf4j
public class UpdateCategoriesRoute extends RouteBuilder {

    private final SslPropertyConfig sslPropertyConfig;
    private final GlobalExceptionHandler globalExceptionHandler;
    private final ApiLoggingInterceptor apiLoggingInterceptor;

    @Override
    public void configure() throws Exception {

        // Global exception handling
        onException(Exception.class)
            .handled(true)
            .process(globalExceptionHandler)
            .log(LoggingLevel.ERROR, "[UPDATE-CATEGORIES] Exception processed by GlobalExceptionHandler");

        // Main route to update all categories in parallel
        from("direct:update-workspace-categories")
            .routeId("update-workspace-categories")
            .log(LoggingLevel.INFO, "[UPDATE-CATEGORIES] Updating workspace categories")
            
            // Parse the payload and extract categories
            .process(exchange -> {
                String payloadJson = exchange.getIn().getBody(String.class);
                Integer bwId = exchange.getProperty("bwId", Integer.class);
                
                if (bwId == null) {
                    throw new IllegalStateException("bwId property is required for category updates");
                }
                
                log.info("[UPDATE-CATEGORIES] Workspace ID: {}", bwId);
                log.debug("[UPDATE-CATEGORIES] Payload: {}", payloadJson);
                
                // Parse payload to extract categories
                DocumentContext json = JsonPath.parse(payloadJson);
                Map<String, Map<String, String>> categoriesMap = json.read("$.roles.categories", Map.class);
                
                if (categoriesMap == null || categoriesMap.isEmpty()) {
                    throw new IllegalStateException("No categories found in payload");
                }
                
                log.info("[UPDATE-CATEGORIES] Found {} categories to update", categoriesMap.size());
                
                // Convert categories map to list of CategoryUpdateRequest for splitting
                List<CategoryUpdateRequest> requests = new ArrayList<>();
                for (Map.Entry<String, Map<String, String>> categoryEntry : categoriesMap.entrySet()) {
                    String categoryId = categoryEntry.getKey();
                    Map<String, String> attributes = categoryEntry.getValue();
                    
                    // Filter out invalid category IDs (placeholder/test data)
                    try {
                        int categoryIdInt = Integer.parseInt(categoryId);
                        if (categoryIdInt <= 0) {
                            log.warn("[UPDATE-CATEGORIES] Skipping invalid category ID: {} (must be > 0)", categoryId);
                            continue;
                        }
                    } catch (NumberFormatException e) {
                        log.warn("[UPDATE-CATEGORIES] Skipping non-numeric category ID: {}", categoryId);
                        continue;
                    }
                    
                    CategoryUpdateRequest request = new CategoryUpdateRequest();
                    request.setBwId(bwId);
                    request.setCategoryId(categoryId);
                    request.setAttributes(attributes);
                    requests.add(request);
                    
                    log.debug("[UPDATE-CATEGORIES] Category {}: {} attributes", categoryId, attributes.size());
                }
                
                exchange.getIn().setBody(requests);
            })
            
            // Split categories and process in parallel
            .split(body())
                .parallelProcessing()  // Enable async parallel processing
                .executorService("categoryUpdateExecutor")  // Use custom thread pool
                .to("direct:update-single-category")
            .end()
            
            .log(LoggingLevel.INFO, "[UPDATE-CATEGORIES] All category updates completed");
            
            // Set response body after split completes (only for API testing, not needed for real Kafka)
            /* .process(exchange -> {
                Integer bwId = exchange.getProperty("bwId", Integer.class);
                String response = String.format("{\"status\":\"success\",\"message\":\"Workspace %d updated successfully\"}", bwId);
                exchange.getIn().setBody(response);
            });*/

        // Update a single category
        from("direct:update-single-category")
            .routeId("u build-bw-payload ")
            .process(exchange -> {
                CategoryUpdateRequest request = exchange.getIn().getBody(CategoryUpdateRequest.class);
                
                log.info("[UPDATE-CATEGORY] Updating category {} on workspace {}", 
                    request.getCategoryId(), request.getBwId());
                log.debug("[UPDATE-CATEGORY] Attributes: {}", request.getAttributes());
                
                // Build form-urlencoded body
                String formBody = buildFormUrlencodedBody(request.getAttributes());
                
                log.info("[UPDATE-CATEGORY] Form body being sent: {}", formBody);
                
                exchange.getIn().setBody(formBody);
                exchange.setProperty("currentCategoryId", request.getCategoryId());
                exchange.setProperty("currentBwId", request.getBwId());
            })
            
            // Set headers
            .setHeader(Exchange.HTTP_METHOD, constant("PUT"))
            .setHeader("Content-Type", constant("application/x-www-form-urlencoded"))
            .setHeader("Accept", constant("application/json"))
            .setHeader("OTCSTicket", exchangeProperty("otcsTicket"))
            
            // Call PUT /v2/nodes/{bwId}/categories/{categoryId}/
            .log(LoggingLevel.INFO, "[UPDATE-CATEGORY] Calling PUT /v2/nodes/${exchangeProperty.currentBwId}/categories/${exchangeProperty.currentCategoryId}/ with body: ${body}")
            .process(exchange -> {
                exchange.setProperty("API_START_TIME", System.currentTimeMillis());
                exchange.setProperty("API_ENDPOINT", "PUT /api/v2/nodes/" + exchange.getProperty("currentBwId") + "/categories/" + exchange.getProperty("currentCategoryId"));
            })
            .toD("{{app.OTCS_BASE_URL}}/api/v2/nodes/${exchangeProperty.currentBwId}/categories/${exchangeProperty.currentCategoryId}/?bridgeEndpoint=true&throwExceptionOnFailure=false" + sslPropertyConfig.getSslParam())
            .process(apiLoggingInterceptor)
            .log(LoggingLevel.INFO, "[UPDATE-CATEGORY] Category ${exchangeProperty.currentCategoryId} response status: ${header.CamelHttpResponseCode}")
            .log(LoggingLevel.INFO, "[UPDATE-CATEGORY] Response body: ${body}")
            
            .process(exchange -> {
                Integer responseCode = exchange.getIn().getHeader(Exchange.HTTP_RESPONSE_CODE, Integer.class);
                String responseBody = exchange.getIn().getBody(String.class);
                String categoryId = exchange.getProperty("currentCategoryId", String.class);
                
                if (responseCode == 200 || responseCode == 204) {
                    log.info("[UPDATE-CATEGORY] Category {} updated successfully", categoryId);
                } else {
                    String error = String.format("Category %s update failed with status %d: %s", 
                        categoryId, responseCode, responseBody);
                    log.error("[UPDATE-CATEGORY] {}", error);
                    throw new RuntimeException(error);
                }
            });
    }

    /**
     * Build application/x-www-form-urlencoded body from attributes map
     * Example: {464257_3: "Binder"} → "464257_3=Binder"
     * Note: null values are converted to empty strings
     */
    private String buildFormUrlencodedBody(Map<String, String> attributes) throws UnsupportedEncodingException {
        return attributes.entrySet().stream()
            .map(entry -> {
                try {
                    String value = entry.getValue() != null ? entry.getValue() : "";
                    return URLEncoder.encode(entry.getKey(), StandardCharsets.UTF_8.toString()) + 
                           "=" + 
                           URLEncoder.encode(value, StandardCharsets.UTF_8.toString());
                } catch (UnsupportedEncodingException e) {
                    throw new RuntimeException("Failed to encode form data", e);
                }
            })
            .collect(Collectors.joining("&"));
    }

    /**
     * DTO for category update request
     */
    public static class CategoryUpdateRequest {
        private Integer bwId;
        private String categoryId;
        private Map<String, String> attributes;

        public Integer getBwId() {
            return bwId;
        }

        public void setBwId(Integer bwId) {
            this.bwId = bwId;
        }

        public String getCategoryId() {
            return categoryId;
        }

        public void setCategoryId(String categoryId) {
            this.categoryId = categoryId;
        }

        public Map<String, String> getAttributes() {
            return attributes;
        }

        public void setAttributes(Map<String, String> attributes) {
            this.attributes = attributes;
        }
    }
}
