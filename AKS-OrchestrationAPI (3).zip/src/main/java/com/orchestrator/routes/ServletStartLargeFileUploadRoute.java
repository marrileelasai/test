package com.orchestrator.routes;

import com.orchestrator.config.ResponseLoggingInterceptor;
import com.orchestrator.exception.GlobalExceptionHandler;
import com.orchestrator.processor.ServletStartLargeUploadProcessor;
import com.orchestrator.processor.ServletStartLargeUploadProcessor.StartLargeUploadResult;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.camel.LoggingLevel;
import org.apache.camel.builder.RouteBuilder;
import org.springframework.stereotype.Component;

/**
 * Servlet-based Start Large Document Upload API - Phase 1 of 2-phase upload
 * 
 * Endpoint: POST /servlet/v1/StartLargeDocument
 * Content-Type: application/json
 * 
 * Request: Metadata only (NO file_content_base64)
 * Response: Uniqueid (transactionNumber_timestamp) for file upload in Phase 2
 * 
 * Differences from Netty version:
 * - Uses platform-http (servlet-based, true streaming capable)
 * - Same business logic as StartLargeFileUploadRoute
 * - Parallel implementation (coexists with Netty version)
 */
@Component
@RequiredArgsConstructor
@Slf4j
public class ServletStartLargeFileUploadRoute extends RouteBuilder {

    private final GlobalExceptionHandler globalExceptionHandler;
    private final ResponseLoggingInterceptor responseLoggingInterceptor;
    private final ServletStartLargeUploadProcessor startLargeUploadProcessor;

    @Override
    public void configure() throws Exception {

        // Global exception handling
        onException(Exception.class)
            .handled(true)
            .process(globalExceptionHandler)
            .log(LoggingLevel.ERROR, "[SERVLET-START-LARGE-UPLOAD] Exception processed by GlobalExceptionHandler");

        // Platform-HTTP endpoint (servlet-based)
        from("platform-http:/api/v1/StartLargeDocument?httpMethodRestrict=POST")
            .routeId("servlet-start-large-document-api")
            .autoStartup(false)
            .process(exchange -> {
                exchange.setProperty("EXPOSED_API_ENDPOINT", "POST /api/v1/StartLargeDocument");
                // Disable stream caching for this exchange only
                exchange.getContext().setStreamCaching(false);
            })
            .log(LoggingLevel.INFO, "[SERVLET-START-LARGE-UPLOAD] ========== Start Large File Upload Request Received ==========")
            // CRITICAL: Do NOT log body! It will buffer to memory
            
            // Step 1: Validate request schema
            .to("json-validator:schemas/start-large-upload-schema.json")
            .log(LoggingLevel.INFO, "[SERVLET-START-LARGE-UPLOAD] Request validation successful")
            
            // Step 2: Process request (extract metadata, create folder, save metadata.json)
            // Bean method receives body as String, returns StartLargeUploadResult
            .bean(startLargeUploadProcessor, "processRequest")
            
            // Step 3: Build simplified response from result
            .process(exchange -> {
                StartLargeUploadResult result = exchange.getIn().getBody(StartLargeUploadResult.class);
                exchange.getIn().setBody("{\"Uniqueid\":\"" + result.getUniqueId() + "\"}");
            })
            
            .log(LoggingLevel.INFO, "[SERVLET-START-LARGE-UPLOAD] ========== Start Large File Upload Complete ==========")
            .process(responseLoggingInterceptor)
            
            // Set response headers
            .setHeader(Exchange.HTTP_RESPONSE_CODE, constant(200))
            .setHeader(Exchange.CONTENT_TYPE, constant("application/json"));
    }
}
