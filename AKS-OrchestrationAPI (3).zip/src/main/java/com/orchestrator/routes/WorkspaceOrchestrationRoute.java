package com.orchestrator.routes;

import com.orchestrator.config.SslPropertyConfig;
import com.orchestrator.constants.OrchestratorConstants;
import com.orchestrator.processor.BusinessWorkspaceMapper;
import com.orchestrator.exception.GlobalExceptionHandler;
import lombok.RequiredArgsConstructor;
import org.apache.camel.Exchange;
import org.apache.camel.LoggingLevel;
import org.apache.camel.builder.RouteBuilder;
import org.springframework.stereotype.Component;

@Component
//added @sl4j
@RequiredArgsConstructor
public class WorkspaceOrchestrationRoute extends RouteBuilder {
    
    private final BusinessWorkspaceMapper businessWorkspaceMapper;
    private final GlobalExceptionHandler globalExceptionHandler;
    private final SslPropertyConfig sslPropertyConfig;

    @Override
    public void configure() {
        
        // Global exception handling using custom processor
        // GlobalExceptionHandler Just makes the bean available via dependency injection,
        // Without the onException() block, your GlobalExceptionHandler would never be called, even though it's injected.
        onException(Exception.class)
            .handled(true)
            .process(globalExceptionHandler)
            .log(LoggingLevel.ERROR, "[ORCHESTRATION-ERROR] Exception processed by GlobalExceptionHandler");

        // Main orchestration route - called after receiving ESCAPE event
        from("direct:orchestrate-business-workspace")
            .routeId("orchestrate-business-workspace")
            .log(LoggingLevel.INFO, "[ORCHESTRATION] ========== Starting Business Workspace Orchestration ==========")
            .log(LoggingLevel.DEBUG, "[ORCHESTRATION] ESCAPE event: ${body}")
            
            // Store ESCAPE event and extract eventType in single processor
            .process(exchange -> {
                String escapeEventBody = exchange.getIn().getBody(String.class);
                exchange.setProperty(OrchestratorConstants.PROP_ESCAPE_EVENT, escapeEventBody);
                log.debug("[ORCHESTRATION] Stored ESCAPE event in property, length: {}", 
                    escapeEventBody != null ? escapeEventBody.length() : 0);
                // Extract eventType from the body we just retrieved
                try {
                    String eventType = com.jayway.jsonpath.JsonPath.read(escapeEventBody, "$.eventType");
                    exchange.setProperty("eventType", eventType);
                    log.info("[ORCHESTRATION] Event type: {}", eventType);
                } catch (Exception e) {
                    log.warn("[ORCHESTRATION] Could not extract eventType, defaulting to 'Create'");
                    exchange.setProperty("eventType", "Create");
                }
            })
            
            // Step 1: Authenticate with OTCS (ticket valid for all subsequent calls)
            .log(LoggingLevel.INFO, "[ORCHESTRATION] Step 1/3: Authenticating with OTCS")
            .to("direct:authenticate-otcs")
            .log(LoggingLevel.INFO, "[ORCHESTRATION] Step 1/3: Authentication successful, ticket: ${header.OTCSTicket}")
            
            // Step 2: Map ESCAPE event + category mapping → Business Workspace payload
            .log(LoggingLevel.INFO, "[ORCHESTRATION] Step 2/3: Mapping data to Business Workspace payload")
            .process(businessWorkspaceMapper)
            
            
            .log(LoggingLevel.INFO, "[ORCHESTRATION] Step 2/3: Payload mapping completed")
            .log(LoggingLevel.DEBUG, "[ORCHESTRATION] Business Workspace payload: ${body}")
            
            // Step 3: Create or Update Business Workspace (with validation)
            .log(LoggingLevel.INFO, "[ORCHESTRATION] Step 3/3: Creating or updating Business Workspace")
            .log(LoggingLevel.DEBUG, "[ORCHESTRATION] Verifying escapeEvent property before calling create-or-update-workspace: ${exchangeProperty.escapeEvent}")
            .to("direct:create-or-update-workspace")
            .log(LoggingLevel.INFO, "[ORCHESTRATION] Step 3/3: Business Workspace operation completed successfully")
            
            // Final response
            .log(LoggingLevel.INFO, "[ORCHESTRATION] ========== Orchestration Complete ==========")
            .log(LoggingLevel.DEBUG, "[ORCHESTRATION] Final response: ${body}")
            .setHeader(Exchange.HTTP_RESPONSE_CODE, constant(200))
            .setHeader(Exchange.CONTENT_TYPE, constant("application/json"));

        // Note: Authentication route (direct:authenticate-otcs) is now in OtcsAuthenticationRoute.java
        // It can be reused by any route via: .to("direct:authenticate-otcs")

        // DEPRECATED: Old WebReport route - now using CategoryMappingCacheService instead
        // Kept for reference only - can be deleted after testing
        /* CACHE OPTIMIZATION: This route is no longer used
        from("direct:get-category-mapping")
            .routeId("get-category-mapping")
            .log(LoggingLevel.INFO, "[WEBREPORT] Starting category field mapping retrieval")
            .log(LoggingLevel.DEBUG, "[WEBREPORT] Target URL: {{app.OTCS_BASE_URL}}/api/v1/webreports/GetCategoryFields")
            
            // Clear body for GET request
            .setBody(constant(""))
            
            // Set headers
            .setHeader(Exchange.HTTP_METHOD, constant("GET"))
            .setHeader("Accept", constant("application/json"))
            .log(LoggingLevel.DEBUG, "[WEBREPORT] Using OTCSTicket: ${header.OTCSTicket}")
            .log(LoggingLevel.DEBUG, "[WEBREPORT] Headers set for WebReport request")
            
            // Call WebReport endpoint
            .log(LoggingLevel.INFO, "[WEBREPORT] Sending request to WebReport")
            .toD("{{app.OTCS_BASE_URL}}/api/v1/webreports/GetCategoryFields?format=json&suppress_response_codes=string&ENV=DEV&bridgeEndpoint=true&throwExceptionOnFailure=false" + sslPropertyConfig.getSslParam())
            .log(LoggingLevel.INFO, "[WEBREPORT] WebReport response received, HTTP status: ${header.CamelHttpResponseCode}")
            .log(LoggingLevel.DEBUG, "[WEBREPORT] WebReport response body: ${body}")
            
            // Check response status
            .choice()
                .when(header(Exchange.HTTP_RESPONSE_CODE).isNotEqualTo(200))
                    .log(LoggingLevel.ERROR, "[WEBREPORT] WebReport call failed with status: ${header.CamelHttpResponseCode}")
                    .log(LoggingLevel.ERROR, "[WEBREPORT] Error response: ${body}")
                    .throwException(new RuntimeException("WebReport call failed with status: ${header.CamelHttpResponseCode}"))
                .end()
            
            // Store category mapping in exchange property
            .setProperty(OrchestratorConstants.PROP_CATEGORY_MAPPING, body())
            .log(LoggingLevel.INFO, "[WEBREPORT] Category mapping stored successfully")
            .process(exchange -> {
                String mapping = exchange.getProperty(OrchestratorConstants.PROP_CATEGORY_MAPPING, String.class);
                // Count rows
                int rowCount = 0;
                int pos = 0;
                while ((pos = mapping.indexOf("\"templateid\":", pos + 1)) != -1) {
                    rowCount++;
                }
                log.info("[WEBREPORT] Retrieved {} category field mappings", rowCount);
            })
            .log(LoggingLevel.INFO, "[WEBREPORT] Category mapping retrieval completed");
        */

        // Step 4: Create or Update Business Workspace based on eventType
        from("direct:create-business-workspace")
            .routeId("create-business-workspace")
            .log(LoggingLevel.INFO, "[WORKSPACE] Starting Business Workspace operation")
            .log(LoggingLevel.DEBUG, "[WORKSPACE] Event Type: ${exchangeProperty.eventType}")
            .log(LoggingLevel.DEBUG, "[WORKSPACE] Target URL: {{app.OTCS_BASE_URL}}/api/v2/businessworkspaces")
            .log(LoggingLevel.DEBUG, "[WORKSPACE] Payload: ${body}")
            
            // Determine HTTP method based on eventType
            .choice()
                .when(simple("${exchangeProperty.eventType} == 'Update'"))
                    .log(LoggingLevel.INFO, "[WORKSPACE] Event type is Update - using PUT")
                    .setHeader(Exchange.HTTP_METHOD, constant("PUT"))
                .otherwise()
                    .log(LoggingLevel.INFO, "[WORKSPACE] Event type is Create - using POST")
                    .setHeader(Exchange.HTTP_METHOD, constant("POST"))
            .end()
            
            .setHeader(Exchange.CONTENT_TYPE, constant("application/json"))
            .setHeader("Accept", constant("application/json"))
            .log(LoggingLevel.DEBUG, "[WORKSPACE] Using OTCSTicket: ${header.OTCSTicket}")
            .log(LoggingLevel.DEBUG, "[WORKSPACE] HTTP Method: ${header.CamelHttpMethod}")
            
            // Call Business Workspace endpoint
            .log(LoggingLevel.INFO, "[WORKSPACE] Sending workspace ${header.CamelHttpMethod} request to OTCS")
            .toD("{{app.OTCS_BASE_URL}}/api/v2/businessworkspaces?bridgeEndpoint=true&throwExceptionOnFailure=false" + sslPropertyConfig.getSslParam())
            .log(LoggingLevel.INFO, "[WORKSPACE] Workspace response received, HTTP status: ${header.CamelHttpResponseCode}")
            .log(LoggingLevel.DEBUG, "[WORKSPACE] Workspace response body: ${body}")
            
            // Check response status
            .choice()
                .when(header(Exchange.HTTP_RESPONSE_CODE).in(200, 201, 204))
                    .log(LoggingLevel.INFO, "[WORKSPACE] Business Workspace operation successful")
                    
                // Handle "already exists" error for Create - fallback to PUT
                .when(simple("${header.CamelHttpResponseCode} == 500 && ${header.CamelHttpMethod} == 'POST' && ${body} contains 'already exists'"))
                    .log(LoggingLevel.WARN, "[WORKSPACE] Workspace already exists, retrying with PUT")
                    .setHeader(Exchange.HTTP_METHOD, constant("PUT"))
                    .toD("{{app.OTCS_BASE_URL}}/api/v2/businessworkspaces?bridgeEndpoint=true&throwExceptionOnFailure=false" + sslPropertyConfig.getSslParam())
                    .log(LoggingLevel.INFO, "[WORKSPACE] PUT retry completed with status: ${header.CamelHttpResponseCode}")
                    
                // Other 500 errors
                .when(header(Exchange.HTTP_RESPONSE_CODE).isEqualTo(500))
                    .log(LoggingLevel.ERROR, "[WORKSPACE] Server error (500): ${body}")
                    .throwException(new RuntimeException("Business Workspace operation failed - server error"))
                    
                .when(header(Exchange.HTTP_RESPONSE_CODE).isEqualTo(400))
                    .log(LoggingLevel.ERROR, "[WORKSPACE] Bad request - invalid payload: ${body}")
                    .throwException(new RuntimeException("Business Workspace operation failed - invalid payload"))
                .when(header(Exchange.HTTP_RESPONSE_CODE).isEqualTo(401))
                    .log(LoggingLevel.ERROR, "[WORKSPACE] Unauthorized - ticket invalid or expired")
                    .throwException(new RuntimeException("Business Workspace operation failed - authentication invalid"))
                .when(header(Exchange.HTTP_RESPONSE_CODE).isEqualTo(403))
                    .log(LoggingLevel.ERROR, "[WORKSPACE] Forbidden - insufficient permissions")
                    .throwException(new RuntimeException("Business Workspace operation failed - insufficient permissions"))
                .when(header(Exchange.HTTP_RESPONSE_CODE).isEqualTo(422))
                    .log(LoggingLevel.ERROR, "[WORKSPACE] Unprocessable entity - validation error: ${body}")
                    .throwException(new RuntimeException("Business Workspace creation failed - validation error"))
                .otherwise()
                    .log(LoggingLevel.ERROR, "[WORKSPACE] Workspace creation failed with status: ${header.CamelHttpResponseCode}")
                    .log(LoggingLevel.ERROR, "[WORKSPACE] Error response: ${body}")
                    .throwException(new RuntimeException("Business Workspace creation failed with status: ${header.CamelHttpResponseCode}"))
                .end()
            
            .log(LoggingLevel.INFO, "[WORKSPACE] Business Workspace creation completed successfully");
    }
}