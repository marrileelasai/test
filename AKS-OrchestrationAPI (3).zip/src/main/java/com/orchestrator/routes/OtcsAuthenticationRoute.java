package com.orchestrator.routes;

import com.jayway.jsonpath.JsonPath;
import com.orchestrator.config.ApiLoggingInterceptor;
import com.orchestrator.config.SslPropertyConfig;
import com.orchestrator.constants.OrchestratorConstants;
import com.orchestrator.exception.GlobalExceptionHandler;
import lombok.RequiredArgsConstructor;
import org.apache.camel.Exchange;
import org.apache.camel.LoggingLevel;
import org.apache.camel.builder.RouteBuilder;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class OtcsAuthenticationRoute extends RouteBuilder {

    private final GlobalExceptionHandler globalExceptionHandler;
    private final SslPropertyConfig sslPropertyConfig;
    private final ApiLoggingInterceptor apiLoggingInterceptor;

    @Override
    public void configure() {
        
        // Global exception handling using custom processor
        onException(Exception.class)
            .handled(true)
            .process(globalExceptionHandler)
            .log(LoggingLevel.ERROR, "[AUTH-ERROR] Exception processed by GlobalExceptionHandler");
        
        // Authentication route - can be called from any route via direct:authenticate-otcs
        from("direct:authenticate-otcs")
            .routeId("authenticate-otcs")
            .log(LoggingLevel.INFO, "[AUTH] Starting authentication with OTCS")
            .log(LoggingLevel.DEBUG, "[AUTH] Target URL: {{app.OTCS_BASE_URL}}/api/v1/auth")

            // IMPORTANT: clear inbound HTTP transport headers from caller route.
            // EndLargeFileUpload carries query param Id, which can leak to outbound auth call as HTTP query.
            .removeHeaders("CamelHttp*")
            .removeHeader(Exchange.HTTP_QUERY)
            .removeHeader(Exchange.HTTP_PATH)
            .removeHeader(Exchange.HTTP_URI)
            .removeHeader(Exchange.HTTP_URL)
            
            // Build authentication payload
            .setBody(simple("username={{app.OTCS_USERNAME}}&password={{app.OTCS_PASSWORD}}"))
            .log(LoggingLevel.DEBUG, "[AUTH] Authentication payload prepared")
            
            // Set headers
            .setHeader(Exchange.HTTP_METHOD, constant("POST"))
            .setHeader(Exchange.CONTENT_TYPE, constant("application/x-www-form-urlencoded"))
            .setHeader("Accept", constant("application/json"))
            .log(LoggingLevel.DEBUG, "[AUTH] Headers set for authentication request")
            
            // Call OTCS auth endpoint
            // Use .to() with SSL params AFTER ? so they're parsed as Camel options at startup
            .log(LoggingLevel.INFO, "[AUTH] Sending authentication request to OTCS")
            .process(exchange -> {
                exchange.setProperty("API_START_TIME", System.currentTimeMillis());
                exchange.setProperty("API_ENDPOINT", "POST /api/v1/auth");
            })
            .to("{{app.OTCS_BASE_URL}}/api/v1/auth?bridgeEndpoint=true&throwExceptionOnFailure=false" + sslPropertyConfig.getSslParam())
            .process(apiLoggingInterceptor)
            .log(LoggingLevel.INFO, "[AUTH] Authentication response received, HTTP status: ${header.CamelHttpResponseCode}")
            .log(LoggingLevel.DEBUG, "[AUTH] Authentication response body: ${body}")
            
            // Check response status - let GlobalExceptionHandler handle errors
            .process(exchange -> {
                Integer responseCode = exchange.getIn().getHeader(Exchange.HTTP_RESPONSE_CODE, Integer.class);
                if (responseCode == null || responseCode != 200) {
                    log.error("[AUTH] Authentication failed with status: {}, body: {}", 
                        responseCode, exchange.getIn().getBody(String.class));
                    throw new RuntimeException("Authentication failed with status: " + responseCode);
                }
            })
            
            // Extract ticket from response using JsonPath (consistent with rest of codebase)
            .log(LoggingLevel.DEBUG, "[AUTH] Extracting ticket from response")
            .process(exchange -> {
                String responseBody = exchange.getIn().getBody(String.class);
                
                // Extract ticket using JsonPath (single value read)
                String ticket = JsonPath.read(responseBody, "$.ticket");
                
                if (ticket == null || ticket.isEmpty()) {
                    throw new RuntimeException("Ticket not found in authentication response");
                }
                
                // Store ticket in header and exchange property for subsequent API calls
                exchange.getIn().setHeader(OrchestratorConstants.OTCS_TICKET_HEADER, ticket);
                exchange.setProperty(OrchestratorConstants.PROP_OTCS_TICKET, ticket);
                
                log.info("[AUTH] Ticket extracted successfully: {}", ticket.substring(0, Math.min(20, ticket.length())) + "...");
            })
            .log(LoggingLevel.INFO, "[AUTH] Authentication completed successfully");
    }
}
