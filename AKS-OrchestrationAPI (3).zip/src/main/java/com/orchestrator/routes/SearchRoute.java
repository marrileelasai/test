package com.orchestrator.routes;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.orchestrator.config.ApiLoggingInterceptor;
import com.orchestrator.config.ResponseLoggingInterceptor;
import com.orchestrator.config.SslPropertyConfig;
import com.orchestrator.exception.GlobalExceptionHandler;
import com.orchestrator.service.CategoryMappingCacheService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.camel.LoggingLevel;
import org.apache.camel.builder.RouteBuilder;
import org.springframework.stereotype.Component;

import java.util.*;

/**
* Search API Route
* POST /Search
* 
* Searches OTCS for documents and transforms the response
*/
@Component
@RequiredArgsConstructor
@Slf4j
public class SearchRoute extends RouteBuilder {

    private final ObjectMapper objectMapper;
    private final CategoryMappingCacheService categoryMappingCacheService;
    private final SslPropertyConfig sslPropertyConfig;
    private final GlobalExceptionHandler globalExceptionHandler;
    private final ApiLoggingInterceptor apiLoggingInterceptor;
    private final ResponseLoggingInterceptor responseLoggingInterceptor;
    
    @org.springframework.beans.factory.annotation.Value("${app.OTCS_DOCUMENT_SUBTYPE}")
    private String otcsDocumentSubType;

    @org.springframework.beans.factory.annotation.Value("${app.OTCS_DOCUMENT_SUBTYPE_ALT}")
    private String otcsDocumentSubTypeAlt;

    @Override
    public void configure() throws Exception {

        // Global exception handling
        onException(Exception.class)
            .handled(true)
            .process(globalExceptionHandler)
            .log(LoggingLevel.ERROR, "[SEARCH-API] Exception processed by GlobalExceptionHandler");

        // Main search endpoint - Platform HTTP
        from("platform-http:/api/v1/SearchDocuments?httpMethodRestrict=POST")
            .routeId("search-api")
            .process(exchange -> exchange.setProperty("EXPOSED_API_ENDPOINT", "POST /api/v1/SearchDocuments"))
            .log(LoggingLevel.INFO, "[SEARCH-API] ========== Search Request Received ==========")
            .log(LoggingLevel.DEBUG, "[SEARCH-API] Request body: ${body}")

            // Step 0: Validate request schema
            .to("json-validator:schemas/search-schema.json")
            .log(LoggingLevel.INFO, "[SEARCH-API] Request validation successful")

            // Parse JSON request body
            .to("direct:parse-search-json-body")

            // Step 1: Authenticate with OTCS
            .log(LoggingLevel.INFO, "[SEARCH-API] Step 1: Authenticating with OTCS")
            .to("direct:authenticate-otcs")
            .log(LoggingLevel.INFO, "[SEARCH-API] Authentication successful, ticket: ${exchangeProperty.otcsTicket}")

            // Step 2: Build dynamic WHERE clause from SearchInfo
            .log(LoggingLevel.INFO, "[SEARCH-API] Step 2: Building dynamic WHERE clause")
            .to("direct:build-dynamic-where-clause")

            // Step 3: Call OTCS search API
            .log(LoggingLevel.INFO, "[SEARCH-API] Step 3: Calling OTCS search API")
            .to("direct:call-otcs-search")

            // Step 3: Transform response
            .log(LoggingLevel.INFO, "[SEARCH-API] Step 3: Transforming search results")
            .to("direct:transform-search-response")

            .process(responseLoggingInterceptor)
            .log(LoggingLevel.INFO, "[SEARCH-API] ========== Search Request Completed ==========")

            // Set response headers
            .setHeader(Exchange.HTTP_RESPONSE_CODE, constant(200))
            .setHeader(Exchange.CONTENT_TYPE, constant("application/json"))

            .onException(Exception.class)
                .handled(true)
                .log(LoggingLevel.ERROR, "[SEARCH-API] Error: ${exception.message}")
                .process(exchange -> {
                    Exception cause = exchange.getProperty(Exchange.EXCEPTION_CAUGHT, Exception.class);
                    Map<String, Object> errorResponse = new LinkedHashMap<>();
                    errorResponse.put("status", "error");
                    errorResponse.put("message", cause.getMessage());
                    errorResponse.put("timestamp", java.time.Instant.now().toString());

                    String jsonError = objectMapper.writeValueAsString(errorResponse);
                    exchange.getIn().setBody(jsonError);
                    exchange.getIn().setHeader(Exchange.HTTP_RESPONSE_CODE, 500);
                    exchange.getIn().setHeader(Exchange.CONTENT_TYPE, "application/json");
                })
            .end();


        // Parse JSON request body
        from("direct:parse-search-json-body")
            .routeId("parse-search-json-body")
            .process(exchange -> {
                String body = exchange.getIn().getBody(String.class);
                log.info("[SEARCH-JSON] Parsing JSON request body");
                log.debug("[SEARCH-JSON] Raw body: {}", body);

                // Parse JSON using JsonPath
                com.jayway.jsonpath.DocumentContext json = com.jayway.jsonpath.JsonPath.parse(body);

                // Extract fields
                String applicationName = json.read("$.Document.ApplicationName", String.class);
                String workspaceType = json.read("$.Document.WorkspaceType", String.class);

                // Extract SearchInfo
                Map<String, Object> searchInfo = json.read("$.Document.SearchInfo", Map.class);

                log.info("[SEARCH-JSON] ApplicationName: {}", applicationName);
                log.info("[SEARCH-JSON] WorkspaceType: {}", workspaceType);
                log.info("[SEARCH-JSON] SearchInfo fields: {}", searchInfo.keySet());

                // Store in exchange properties
                exchange.setProperty("requestBody", body);
                exchange.setProperty("applicationName", applicationName);
                exchange.setProperty("workspaceType", workspaceType);
                exchange.setProperty("searchInfo", searchInfo);

                log.info("[SEARCH-JSON] JSON parsed successfully");
            });


        // Build dynamic WHERE clause from SearchInfo
        from("direct:build-dynamic-where-clause")
            .routeId("build-dynamic-where-clause")
            .process(exchange -> {
                @SuppressWarnings("unchecked")
                Map<String, Object> searchInfo = exchange.getProperty("searchInfo", Map.class);

                log.info("[WHERE-CLAUSE] Building dynamic WHERE clause from SearchInfo");
                log.debug("[WHERE-CLAUSE] SearchInfo: {}", searchInfo);

                // Get category mappings from cache
                com.jayway.jsonpath.DocumentContext categoryData = categoryMappingCacheService.getCategoryMappings();

                // Start with OTSubType OR clause from configuration
                List<String> whereParts = new ArrayList<>();
                String otSubTypeClause = String.format("OTSubType:\\\"%s\\\" OR OTSubType:\\\"%s\\\"",
                    otcsDocumentSubType,
                    otcsDocumentSubTypeAlt);
                whereParts.add(otSubTypeClause);
                log.info("[WHERE-CLAUSE] Using subtype clause: {}", otSubTypeClause);

                // Build WHERE clause dynamically
                for (Map.Entry<String, Object> entry : searchInfo.entrySet()) {
                    String fieldName = entry.getKey();
                    Object fieldValue = entry.getValue();

                    // Skip empty values
                    if (fieldValue == null || fieldValue.toString().trim().isEmpty()) {
                        log.debug("[WHERE-CLAUSE] Skipping empty field: {}", fieldName);
                        continue;
                    }

                    log.debug("[WHERE-CLAUSE] Processing field: {} = {}", fieldName, fieldValue);

                    // Look up otattributename in cache
                    try {
                        List<Map<String, Object>> rows = categoryData.read(
                            "$.myRows[?(@.otattributename == '" + fieldName + "')]"
                        );

                        if (!rows.isEmpty()) {
                            Map<String, Object> row = rows.get(0);
                            String categoryId = String.valueOf(row.get("categoryid"));
                            String metadataId = String.valueOf(row.get("metadataid"));
                            String attrField = "Attr_" + categoryId + "_" + metadataId;

                            // Add to WHERE clause
                            String wherePart = String.format("{%s:\\\"%s\\\"}", attrField, fieldValue.toString());
                            whereParts.add(wherePart);

                            log.info("[WHERE-CLAUSE] Mapped {} -> {} = {}", fieldName, attrField, fieldValue);
                        } else {
                            log.warn("[WHERE-CLAUSE] No mapping found for field: {}", fieldName);
                        }
                    } catch (Exception e) {
                        log.error("[WHERE-CLAUSE] Error looking up field {}: {}", fieldName, e.getMessage());
                    }
                }

                // Combine with AND and keep each clause wrapped in {}
                String whereClause = whereParts.stream()
                    .map(part -> "{" + part + "}")
                    .collect(java.util.stream.Collectors.joining(" AND "));

                exchange.setProperty("whereClause", whereClause);

                log.info("[WHERE-CLAUSE] Final WHERE clause: {}", whereClause);
            });


        // Parse form-data search parameters (DEPRECATED - kept for backward compatibility)
        from("direct:parse-search-parameters")
            .routeId("parse-search-parameters")
            .process(exchange -> {
                String body = exchange.getIn().getBody(String.class);
                log.debug("[SEARCH-PARAMS] Raw body: {}", body);

                // Parse form-data (application/x-www-form-urlencoded)
                Map<String, String> params = new HashMap<>();
                if (body != null && !body.isEmpty()) {
                    String[] pairs = body.split("&");
                    for (String pair : pairs) {
                        String[] keyValue = pair.split("=", 2);
                        if (keyValue.length == 2) {
                            String key = java.net.URLDecoder.decode(keyValue[0], "UTF-8");
                            String value = java.net.URLDecoder.decode(keyValue[1], "UTF-8");
                            params.put(key, value);
                        }
                    }
                }

                // Store parameters as properties
                exchange.setProperty("searchWhere", params.getOrDefault("where", ""));
                exchange.setProperty("searchLimit", params.getOrDefault("limit", "1000"));
                exchange.setProperty("searchExpand", params.getOrDefault("expand", "properties"));
                exchange.setProperty("searchFields", params.getOrDefault("fields", "Categories"));

                log.info("[SEARCH-PARAMS] Parsed - where: {}, limit: {}, expand: {}, fields: {}", 
                    params.get("where"), params.get("limit"), params.get("expand"), params.get("fields"));
            });


        // Call OTCS search API
        from("direct:call-otcs-search")
            .routeId("call-otcs-search")
            .process(exchange -> {
                String whereClause = exchange.getProperty("whereClause", String.class);
                String otcsTicket = exchange.getProperty("otcsTicket", String.class);

                log.info("[SEARCH-OTCS] Calling search API");
                log.info("[SEARCH-OTCS] WHERE clause: {}", whereClause);

                // Build form-data body - remove encoding 
                String formData = String.format(
                    "where=%s&limit=%s&expand=%s&fields=%s",
                    java.net.URLEncoder.encode(whereClause, "UTF-8"),
                    java.net.URLEncoder.encode("1000", "UTF-8"),
                    java.net.URLEncoder.encode("properties", "UTF-8"),
                    java.net.URLEncoder.encode("Categories", "UTF-8")
                );

                log.debug("[SEARCH-OTCS] Form data: {}", formData);

                exchange.getIn().setBody(formData);
                exchange.getIn().setHeader(Exchange.HTTP_METHOD, "POST");
                exchange.getIn().setHeader("Content-Type", "application/x-www-form-urlencoded");
                exchange.getIn().setHeader("Accept", "application/json");
                exchange.getIn().setHeader("OTCSTicket", otcsTicket);
            })

            // Call OTCS search endpoint
            .process(exchange -> {
                exchange.setProperty("API_START_TIME", System.currentTimeMillis());
                exchange.setProperty("API_ENDPOINT", "POST /api/v2/search");
            })
            .toD("{{app.OTCS_BASE_URL}}/api/v2/search?bridgeEndpoint=true&throwExceptionOnFailure=false" + sslPropertyConfig.getSslParam())
            .process(apiLoggingInterceptor)

            .process(exchange -> {
                Integer statusCode = exchange.getIn().getHeader(Exchange.HTTP_RESPONSE_CODE, Integer.class);
                String responseBody = exchange.getIn().getBody(String.class);

                log.info("[SEARCH-OTCS] Response status: {}", statusCode);
                log.debug("[SEARCH-OTCS] Response body length: {} characters", responseBody != null ? responseBody.length() : 0);

                if (statusCode != 200) {
                    log.error("[SEARCH-OTCS] Search failed with status: {}", statusCode);
                    log.error("[SEARCH-OTCS] Error response: {}", responseBody);
                    throw new RuntimeException("OTCS search API failed with status: " + statusCode);
                }

                log.info("[SEARCH-OTCS] Search completed successfully");

                // Store raw response
                exchange.setProperty("otcsSearchResponse", responseBody);
            });


        // Transform OTCS search response to our format
        from("direct:transform-search-response")
            .routeId("transform-search-response")
            .process(exchange -> {
                String rawResponse = exchange.getProperty("otcsSearchResponse", String.class);
                String workspaceType = exchange.getProperty("workspaceType", String.class);
                @SuppressWarnings("unchecked")
                Map<String, Object> searchInfo = exchange.getProperty("searchInfo", Map.class);
                String transactionNumber = searchInfo != null ? (String) searchInfo.get("TransactionNumber") : "";

                log.info("[SEARCH-TRANSFORM] Transforming search response");
                log.debug("[SEARCH-TRANSFORM] Raw response length: {} characters", rawResponse.length());

                // Parse OTCS response using ObjectMapper (efficient for large responses)
                @SuppressWarnings("unchecked")
                Map<String, Object> otcsResponse = objectMapper.readValue(rawResponse, Map.class);
                @SuppressWarnings("unchecked")
                List<Map<String, Object>> results = (List<Map<String, Object>>) otcsResponse.get("results");

                if (results == null) {
                    results = new ArrayList<>();
                }

                log.info("[SEARCH-TRANSFORM] Found {} results", results.size());

                // Build DocumentInfo array
                List<Map<String, Object>> documentInfoList = new ArrayList<>();
                int successCount = 0;
                int errorCount = 0;

                for (int i = 0; i < results.size(); i++) {
                    try {
                        Map<String, Object> result = results.get(i);
                        log.debug("[SEARCH-TRANSFORM] Processing result {}/{}", i + 1, results.size());

                        Map<String, Object> docInfo = transformResultToDocumentInfo(result, transactionNumber);
                        if (docInfo != null) {
                            documentInfoList.add(docInfo);
                            successCount++;
                            log.debug("[SEARCH-TRANSFORM] Result {} transformed: DocumentID={}", 
                                i + 1, docInfo.get("DocumentID"));
                        }
                    } catch (Exception e) {
                        errorCount++;
                        log.error("[SEARCH-TRANSFORM] Error transforming result {}: {}", i + 1, e.getMessage(), e);
                    }
                }

                log.info("[SEARCH-TRANSFORM] Successfully transformed {}/{} documents", successCount, results.size());
                if (errorCount > 0) {
                    log.warn("[SEARCH-TRANSFORM] Failed to transform {} documents", errorCount);
                }

                // Build final response
                Map<String, Object> documentsMap = new LinkedHashMap<>();
                documentsMap.put("WorkspaceType", workspaceType != null ? workspaceType : "");
                documentsMap.put("DocumentInfo", documentInfoList);

                Map<String, Object> finalResponse = new LinkedHashMap<>();
                finalResponse.put("Documents", documentsMap);

                String jsonResponse = objectMapper.writeValueAsString(finalResponse);
                exchange.getIn().setBody(jsonResponse);

                log.info("[SEARCH-TRANSFORM] Final response generated: {} documents", documentInfoList.size());
                log.debug("[SEARCH-TRANSFORM] Response: {}", jsonResponse);
            });
    }

    /**
     * Transform a single OTCS search result to DocumentInfo format using Map navigation
     */
    private Map<String, Object> transformResultToDocumentInfo(Map<String, Object> result, String transactionNumber) {
        Map<String, Object> docInfo = new LinkedHashMap<>();

        try {
            // Navigate to data.properties
            @SuppressWarnings("unchecked")
            Map<String, Object> data = (Map<String, Object>) result.get("data");
            if (data == null) {
                log.warn("[TRANSFORM] No data found in result");
                return null;
            }

            log.debug("[TRANSFORM] Processing result data");

            @SuppressWarnings("unchecked")
            Map<String, Object> properties = (Map<String, Object>) data.get("properties");
            if (properties == null) {
                log.warn("[TRANSFORM] No properties found in data");
                return null;
            }

            // 1. TransactionNumber - from request
            docInfo.put("TransactionNumber", transactionNumber != null ? transactionNumber : "");

            // 2. DocumentID - from properties.id
            Object documentId = properties.get("id");
            docInfo.put("DocumentID", documentId);
            log.debug("[TRANSFORM] DocumentID: {}", documentId);

            // 3. FileName - from properties.name
            String fileName = (String) properties.get("name");
            docInfo.put("FileName", fileName != null ? fileName : "");
            log.debug("[TRANSFORM] FileName: {}", fileName);

            // 4. FileSize - from properties.size
            Object fileSize = properties.get("size");
            docInfo.put("FileSize", fileSize != null ? fileSize.toString() : "");
            log.debug("[TRANSFORM] FileSize: {}", fileSize);

            // 5. DateCreated - from properties.create_date
            String dateCreated = (String) properties.get("create_date");
            docInfo.put("DateCreated", dateCreated != null ? dateCreated : "");
            log.debug("[TRANSFORM] DateCreated: {}", dateCreated);

            // 6. DateLastModified - from properties.modify_date
            String dateModified = (String) properties.get("modify_date");
            docInfo.put("DateLastModified", dateModified != null ? dateModified : "");
            log.debug("[TRANSFORM] DateLastModified: {}", dateModified);

            // 7. FolderName - from properties.parent_id_expand.name
            String folderName = "";
            @SuppressWarnings("unchecked")
            Map<String, Object> parentIdExpand = (Map<String, Object>) properties.get("parent_id_expand");
            if (parentIdExpand != null) {
                folderName = (String) parentIdExpand.get("name");
            }
            docInfo.put("FolderName", folderName != null ? folderName : "");
            log.debug("[TRANSFORM] FolderName: {}", folderName);

            // 8. DocumentType - from categories with lookup
            String documentType = extractDocumentType(data);
            docInfo.put("DocumentType", documentType);
            log.debug("[TRANSFORM] DocumentType: {}", documentType);

            // 9. DocumentDesc - from categories.email_subject (only for emails)
            String documentDesc = extractDocumentDesc(data);
            docInfo.put("DocumentDesc", documentDesc);
            log.debug("[TRANSFORM] DocumentDesc: {}", documentDesc);

            log.info("[TRANSFORM] Transformed document: ID={}, Name={}, Type={}, Folder={}", 
                documentId, fileName, documentType, folderName);

            return docInfo;

        } catch (Exception e) {
            log.error("[TRANSFORM] Error extracting document info: {}", e.getMessage(), e);
            return null;
        }
    }

    /**
     * Extract DocumentType from categories and lookup in cache
     */
    @SuppressWarnings("unchecked")
    private String extractDocumentType(Map<String, Object> data) {
        try {
            log.info("[TRANSFORM-DOCTYPE] Extracting DocumentType from categories");

            // Get categories - could be array or map
            Object categoriesObj = data.get("categories");
            if (categoriesObj == null) {
                log.warn("[TRANSFORM-DOCTYPE] No categories found in OTCS result");
                return "";
            }

            Map<String, Object> categories = new LinkedHashMap<>();

            // Handle categories as array
            if (categoriesObj instanceof List) {
                List<Map<String, Object>> categoryList = (List<Map<String, Object>>) categoriesObj;
                if (!categoryList.isEmpty()) {
                    // Merge all category maps into one
                    for (Map<String, Object> catMap : categoryList) {
                        categories.putAll(catMap);
                    }
                }
            } else if (categoriesObj instanceof Map) {
                categories = (Map<String, Object>) categoriesObj;
            }

            if (categories.isEmpty()) {
                log.warn("[TRANSFORM-DOCTYPE] Categories is empty after normalization");
                return "";
            }

            log.info("[TRANSFORM-DOCTYPE] Category fields discovered: {}", categories.keySet());

            // Get category mappings from cache
            com.jayway.jsonpath.DocumentContext categoryData = categoryMappingCacheService.getCategoryMappings();
            if (categoryData == null) {
                log.warn("[TRANSFORM-DOCTYPE] No category mappings available in cache");
                return "";
            }

            List<Map<String, Object>> allRows = categoryData.read("$.myRows[*]");
            log.info("[TRANSFORM-DOCTYPE] Loaded {} category mapping rows from cache", allRows != null ? allRows.size() : 0);

            // Look for category fields that contain DocumentType
            for (Map.Entry<String, Object> entry : categories.entrySet()) {
                String fieldKey = entry.getKey();
                Object fieldValue = entry.getValue();

                log.info("[TRANSFORM-DOCTYPE] Checking category field: {} = {}", fieldKey, fieldValue);

                // Check if this is a category field with pattern like "57575_3"
                if (fieldKey.matches("\\d+_\\d+")) {
                    String[] parts = fieldKey.split("_", 2);
                    String categoryId = parts[0];
                    String metadataId = parts[1];

                    List<Map<String, Object>> matchedRows = new ArrayList<>();
                    for (Map<String, Object> row : allRows) {
                        String rowField = String.valueOf(row.get("field"));
                        String rowCategoryId = String.valueOf(row.get("categoryid"));
                        String rowMetadataId = String.valueOf(row.get("metadataid"));

                        boolean fieldMatch = rowField != null && rowField.equals(fieldKey);
                        boolean idMatch = rowCategoryId.equals(categoryId) && rowMetadataId.equals(metadataId);

                        if (fieldMatch || idMatch) {
                            matchedRows.add(row);
                        }
                    }

                    if (matchedRows.isEmpty()) {
                        log.warn("[TRANSFORM-DOCTYPE] No mapping row found for key {} (categoryId={}, metadataId={})", fieldKey, categoryId, metadataId);
                        continue;
                    }

                    log.info("[TRANSFORM-DOCTYPE] Found {} mapping row(s) for key {}", matchedRows.size(), fieldKey);

                    for (Map<String, Object> row : matchedRows) {
                        String mappedField = String.valueOf(row.get("field"));
                        String mappedCategoryName = row.get("categoryname") != null ? String.valueOf(row.get("categoryname")) : "";
                        String mappedOtAttribute = row.get("otattributename") != null ? String.valueOf(row.get("otattributename")) : "";

                        log.info("[TRANSFORM-DOCTYPE] Mapping candidate -> field={}, categoryname={}, otattributename={}",
                            mappedField, mappedCategoryName, mappedOtAttribute);

                        if (isDocumentTypeMapping(mappedCategoryName, mappedOtAttribute)) {
                            String docTypeValue = fieldValue != null ? fieldValue.toString() : "";
                            log.info("[TRANSFORM-DOCTYPE] DocumentType resolved from key {} as '{}'", fieldKey, docTypeValue);
                            return docTypeValue;
                        }
                    }
                } else {
                    log.debug("[TRANSFORM-DOCTYPE] Skipping non category-key field: {}", fieldKey);
                }
            }

            log.warn("[TRANSFORM-DOCTYPE] No DocumentType mapping matched for any category field");
            return "";

        } catch (Exception e) {
            log.error("[TRANSFORM-DOCTYPE] Error extracting DocumentType: {}", e.getMessage(), e);
            return "";
        }
    }

    private boolean isDocumentTypeMapping(String categoryName, String otAttributeName) {
        String normalizedCategory = categoryName == null ? "" : categoryName.toLowerCase().replaceAll("[^a-z0-9]", "");
        String normalizedAttribute = otAttributeName == null ? "" : otAttributeName.toLowerCase().replaceAll("[^a-z0-9]", "");

        return normalizedCategory.contains("documenttype")
            || normalizedAttribute.equals("documenttype");
    }

    /**
     * Extract DocumentDesc from email_subject (only for emails)
     */
    @SuppressWarnings("unchecked")
    private String extractDocumentDesc(Map<String, Object> data) {
        try {
            log.debug("[TRANSFORM-DESC] Extracting DocumentDesc from categories");

            // Get categories
            Object categoriesObj = data.get("categories");
            if (categoriesObj == null) {
                return "";
            }

            Map<String, Object> categories = new LinkedHashMap<>();

            // Handle categories as array
            if (categoriesObj instanceof List) {
                List<Map<String, Object>> categoryList = (List<Map<String, Object>>) categoriesObj;
                if (!categoryList.isEmpty()) {
                    for (Map<String, Object> catMap : categoryList) {
                        categories.putAll(catMap);
                    }
                }
            } else if (categoriesObj instanceof Map) {
                categories = (Map<String, Object>) categoriesObj;
            }

            // Look for email_subject
            Object emailSubject = categories.get("email_subject");
            if (emailSubject != null) {
                String desc = emailSubject.toString();
                log.debug("[TRANSFORM-DESC] Found email_subject: {}", desc);
                return desc;
            }

            return "";

        } catch (Exception e) {
            log.error("[TRANSFORM-DESC] Error extracting DocumentDesc: {}", e.getMessage());
            return "";
        }
    }
}
 