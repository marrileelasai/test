package com.orchestrator.routes;

import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.camel.LoggingLevel;
import org.apache.camel.builder.RouteBuilder;
import org.springframework.stereotype.Component;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Shared route for transforming OTCS upload response to simplified API format
 * Used by: DocumentUploadRoute
 */
@Component
@RequiredArgsConstructor
@Slf4j
public class UploadApiResponseRoute extends RouteBuilder {

    @Override
    public void configure() throws Exception {

        // Transform OTCS response to simplified API response
        from("direct:upload-api-response")
            .routeId("upload-api-response")
            .log(LoggingLevel.INFO, "[UPLOAD-API-RESPONSE] Transforming response to simplified format")
            .process(exchange -> {
                Integer responseCode = exchange.getIn().getHeader(Exchange.HTTP_RESPONSE_CODE, Integer.class);
                String responseBody = exchange.getIn().getBody(String.class);

                if (responseCode == 200 || responseCode == 201) {
                    // Parse OTCS response
                    DocumentContext otcsResponse = JsonPath.parse(responseBody);

                    // Handle different response structures (single upload vs multipart complete)
                    Integer documentId = readFirstInteger(otcsResponse, 
                        "$.results.data.properties.id", "$.results.data.id", "$.data.id", "$.id");
                    String name = readFirstString(otcsResponse, 
                        "$.results.data.properties.name", "$.results.data.name", "$.data.name", "$.name");
                    Integer parentId = readFirstInteger(otcsResponse, 
                        "$.results.data.properties.parent_id", "$.results.data.parent_id", "$.data.parent_id", "$.parent_id");

                    // Build simplified response
                    Map<String, Object> data = new LinkedHashMap<>();
                    data.put("DocumentId", documentId);
                    data.put("name", name);
                    data.put("parent_id", parentId);

                    Map<String, Object> document = new LinkedHashMap<>();
                    document.put("Data", data);

                    Map<String, Object> response = new LinkedHashMap<>();
                    response.put("Document", document);

                    String simplifiedResponse = JsonPath.parse(response).jsonString();
                    exchange.getIn().setBody(simplifiedResponse);

                    log.info("[UPLOAD-API-RESPONSE] Simplified response: {}", simplifiedResponse);
                } else {
                    // Keep error response as-is
                    log.warn("[UPLOAD-API-RESPONSE] Error response, keeping original format");
                }
            });
    }

    /**
     * Try multiple JSON paths and return first non-null Integer value
     */
    private Integer readFirstInteger(DocumentContext json, String... paths) {
        for (String path : paths) {
            try {
                Integer value = json.read(path, Integer.class);
                if (value != null) {
                    return value;
                }
            } catch (Exception e) {
                // Try next path
            }
        }
        return null;
    }

    /**
     * Try multiple JSON paths and return first non-null String value
     */
    private String readFirstString(DocumentContext json, String... paths) {
        for (String path : paths) {
            try {
                String value = json.read(path, String.class);
                if (value != null) {
                    return value;
                }
            } catch (Exception e) {
                // Try next path
            }
        }
        return null;
    }
}
