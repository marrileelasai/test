# Servlet-Based Large File Upload Implementation Plan

## Configuration
- **Target Config:** A (Conservative) with room to scale to B/C
- **CPU:** 500m (scalable to 1000m)
- **Memory:** 2Gi (scalable to 4Gi)
- **JVM Args:** `-Xms1536m -Xmx1536m -XX:MaxDirectMemorySize=256m`
- **Buffer Size:** 128KB (scalable to 256KB for Config B)
- **Max Concurrent:** 2 uploads per pod (scalable to 5 for Config B)

## Architecture
- **Parallel Implementation:** New servlet endpoints alongside existing Netty
- **Netty Endpoints:** `/uploadapi/v1/*` (unchanged, existing clients)
- **Servlet Endpoints:** `/servlet/v1/*` (new implementation)
- **No disruption** to existing functionality

## Files to Create

### 1. Dependency Addition
**File:** `build.gradle`
- Add `camel-platform-http-starter` dependency

### 2. Configuration Bean
**File:** `src/main/java/com/orchestrator/config/UploadExecutorConfig.java`
- Thread pool executor for concurrency control
- Configurable: 2 threads (Config A) → 5 threads (Config B)

### 3. Start Large Document Route (Servlet)
**File:** `src/main/java/com/orchestrator/routes/servlet/ServletStartLargeFileUploadRoute.java`
- Same logic as Netty version
- Uses platform-http component
- Endpoint: `/servlet/v1/StartLargeDocument`

### 4. End Large Document Route (Servlet)
**File:** `src/main/java/com/orchestrator/routes/servlet/ServletEndLargeFileUploadRoute.java`
- Streaming file upload to disk
- 128KB buffer (Config A)
- Direct write to final path (no .tmp)
- Auto-delete on failure
- Endpoint: `/servlet/v1/UploadLargeDocument`

### 5. Cleanup Exception Handler
**File:** `src/main/java/com/orchestrator/exception/FileCleanupExceptionHandler.java`
- Deletes partial files on any failure
- Reusable across routes

### 6. Schema Validation (Optional)
**File:** `src/main/resources/schemas/servlet-large-upload-schema.json`
- Same as start-large-upload-schema.json
- Separate for servlet endpoints

## Key Features
1. ✅ **True Streaming:** Platform-HTTP with streamCaching=false
2. ✅ **Constant Memory:** 128KB buffer (2 concurrent = 256KB total)
3. ✅ **Auto Cleanup:** Delete files on failure (exception handler)
4. ✅ **Direct Write:** No .tmp files (overwrite if exists)
5. ✅ **Scalable:** Easy config change to upgrade to B or C
6. ✅ **Parallel:** Coexists with Netty (zero disruption)

## Exception Handling Strategy
```
onException(Exception.class)
    .handled(true)
    .process(fileCleanupExceptionHandler)  // Delete partial file
    .process(globalExceptionHandler)       // Return error to client
```

## Deployment Strategy
1. Deploy with servlet endpoints `/servlet/v1/*`
2. Keep Netty endpoints `/uploadapi/v1/*` running
3. Test servlet with small subset of clients
4. Gradually migrate traffic
5. Monitor both endpoints for 6 months
6. Optional: Deprecate Netty version

## Resource Scaling Path
**Config A → Config B:**
```yaml
# Change in Helm values
cpu: 500m → 1000m
memory: 2Gi → 4Gi
```

```java
// Change in UploadExecutorConfig
corePoolSize: 2 → 5
```

```java
// Change in ServletEndLargeFileUploadRoute
buffer: 128KB → 256KB
```

**Config B → Config C:**
```yaml
# Change in Helm values (same as B)
cpu: 1000m
memory: 4Gi
```

```bash
# Change JVM args
-Xmx3072m → -Xmx2048m
-XX:MaxDirectMemorySize=512m → -XX:MaxDirectMemorySize=1536m
```

```java
// Change in UploadExecutorConfig
corePoolSize: 5 → 8
```

## Files Created (Checklist)
- [ ] build.gradle (dependency)
- [ ] UploadExecutorConfig.java
- [ ] ServletStartLargeFileUploadRoute.java
- [ ] ServletEndLargeFileUploadRoute.java
- [ ] FileCleanupExceptionHandler.java
- [ ] servlet-large-upload-schema.json (optional, reuse existing)

## Testing Checklist
- [ ] 100MB file upload (success)
- [ ] 1GB file upload (success)
- [ ] 4GB file upload (success)
- [ ] Network drop during upload (file deleted)
- [ ] Pod killed during upload (file deleted on restart)
- [ ] 2 concurrent uploads (both succeed)
- [ ] 3+ concurrent uploads (queued, processed sequentially)

## Current Status
- [x] Plan created
- [ ] Waiting for user to request files one by one

---

**Next Step:** User will request files one at a time for review.
