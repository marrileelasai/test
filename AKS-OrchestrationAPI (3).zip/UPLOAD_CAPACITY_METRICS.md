# Upload Capacity Metrics (1GB files, 2GB JVM, Streaming path)

## Assumptions
- JVM heap budget for uploads: **~1GB** (after reserving ~500-750MB for Kafka consumers + other REST endpoints)
- Disk space: **100GB** (mount-backed)
- Upload path: spool to disk, then stream to OT (`/api/v2/nodes`)
- Double-buffer streaming uses **2 × 10MB direct buffers** (off-heap)

---

## 1) Ingress + Spool (Tomcat multipart → disk)

| Concurrency | File Size each | Est. spool time per request | JVM heap impact (request path) | Disk impact |
|---|---:|---:|---:|---:|
| 1 | 1GB | ~5-30 ms | ~10-20 MB transient | +1GB temp file |
| 5 | 1GB | ~20-120 ms | ~50-100 MB transient total | +5GB temp files |

Notes:
- Spool is mostly container + OS I/O bound.
- Heap impact is small relative to file size.

---

## 2) Move/Copy step (`Files.move`)

| Operation | Typical time (1GB file) | JVM tax | CPU tax | OS tax |
|---|---:|---:|---:|---:|
| `move` same filesystem/mount | ~1-10 ms | negligible | negligible | metadata update (rename) |
| `move` cross-filesystem (degrades to copy+delete) | seconds to tens of seconds | low | moderate | high I/O |

Notes:
- In your logs (`spoolMs`, `moveMs`), move was very small, indicating fast same-mount rename path.

---

## 3) Streaming phase memory model (double buffering)

### Per active upload request
- Direct buffers (off-heap): **20MB**
- Heap overhead (HTTP/Camel/request objects): **~80-120MB**
- Total practical JVM heap footprint per upload: **~100MB** (planning number)

### 5 parallel uploads
- Off-heap direct buffers: **~100MB** total
- Heap for upload requests: **~500MB** total (planning number)

---

## Predicted heap envelope (2GB JVM)

| Component | Estimated heap |
|---|---:|
| Base app + Spring/Camel + Kafka + other APIs (reserved) | 500-750MB |
| Upload path for 5 concurrent requests | ~500MB |
| Total | ~1000-1250MB |
| Remaining headroom (of 2GB) | ~750-1000MB |

Interpretation:
- **5 concurrent uploads is feasible** with your 2GB heap under these assumptions.
- Keep monitoring GC pauses and live set growth under sustained load.

---

## Predicted runtime profile per 1GB request

| Phase | Expected time |
|---|---:|
| Spool to disk | ~0.01-0.12 s |
| Move/rename | ~0.001-0.01 s |
| OT upload stream (dominant) | ~60-210 s (environment dependent) |
| Other orchestration overhead (auth/workspace/category calls) | ~2-30 s |

Key point:
- End-to-end time is dominated by OT upload and OT API behavior, not spool/move.

---

## Validation checklist for pod test

1. Run with concurrency = 1, 3, 5.
2. Capture:
   - heap used (live + peak)
   - GC pause/time
   - upload API response time
   - spool/move timings from logs
3. Confirm:
   - Heap stays below ~1.3GB at 5 concurrency
   - No full-GC thrash
   - No OOM
   - Throughput scales predictably to target

---

## Suggested guardrails
- Keep `app.upload.buffer-size: 10485760` (10MB)
- Keep conservative server thread limits aligned to target concurrency
- Add explicit upload concurrency limiter at 5 (if not already enforced)
- Alert when heap > 75% for sustained intervals
